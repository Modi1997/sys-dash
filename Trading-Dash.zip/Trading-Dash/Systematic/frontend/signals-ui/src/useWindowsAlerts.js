import { useEffect, useRef } from "react";
import { playBeep, speak } from "./audio";

const BASE_URL = "";
const URL_WINDOWS = `${BASE_URL}/api/systematic-signals/latest`;

const POS_LABEL = { 1: "LONG", "-1": "SHORT", 0: "FLAT" };

function londonNow() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/London",
    hour: "2-digit",
    minute: "2-digit",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const get = (type) => parseInt(parts.find((p) => p.type === type)?.value, 10);
  return {
    hour: get("hour"),
    minute: get("minute"),
    dateStr: `${get("year")}-${get("month")}-${get("day")}`,
  };
}

const PRODUCT_SIGNAL_HOURS = {
  brtdub1: [10],
  "35brgcrk1": [16],
};

/**
 * Hook: checks every 30s if we're within 5 minutes before any signal hour.
 * If so, fetches fresh windows data, derives positions, compares, and speaks alerts.
 */
export default function useWindowsAlerts(windowsData) {
  const firedTodayRef = useRef(new Set()); // "{product}_{signalHour}_{dateStr}" → already fired

  
  const speakName = (product) => {
    const map = {
      brtdub1: "Brent Dubai",
      "35brgcrk1": "Barges Crack",
    };
    return map[product] || product;
  };


  useEffect(() => {
    async function checkAndAlert() {
      const { hour, minute, dateStr } = londonNow();

      // Find which product/hour combos are at T-5min right now
      const due = [];
      for (const [product, hours] of Object.entries(PRODUCT_SIGNAL_HOURS)) {
        for (const sigHour of hours) {
          const alertHour = sigHour-1;
          const alertMinute = 55;
          // Match: London time is between HH:55 and HH:59 (the 5-min window before signal hour)
          if (hour === alertHour && minute >= alertMinute && minute <= 59) {
            const key = `${product}_${sigHour}_${dateStr}`;
            if (!firedTodayRef.current.has(key)) {
              due.push({ product, sigHour, key });
            }
          }
        }
      }


      if (due.length > 0) {
        // Fetch fresh data
        let windowsData;
        try {
          const res = await fetch(URL_WINDOWS, { cache: "no-store" });
          if (!res.ok) return;
          windowsData = await res.json();
        } catch {
          return;
        }

        const rows = windowsData?.products || [];

        const alerts = [];
        for (const { product, sigHour, key } of due) {
          const row = rows.find((r) => r.product === product && r.signal_hour === sigHour);
          if (!row) continue;

          const currPos = row.position;
          const prevPos = row.prev_position;

          const label = POS_LABEL[currPos] || "FLAT";
          const action = prevPos !== null && prevPos !== currPos ? "FLIP" : "STAY";

          alerts.push({ product, label, action });

          firedTodayRef.current.add(key);
        }

        if ("speechSynthesis" in window) window.speechSynthesis.cancel();
        for (const a of alerts) {
          await playBeep();
          await new Promise((r) => setTimeout(r, 80));
          await speak(`Trade Alert: ${speakName(a.product)} ${a.action} ${a.label}`);
          await new Promise((r) => setTimeout(r, 120));
        }
      }
    }

    checkAndAlert();
    const id = setInterval(checkAndAlert, 30_000);
    return () => clearInterval(id);
  }, [windowsData]);
}
