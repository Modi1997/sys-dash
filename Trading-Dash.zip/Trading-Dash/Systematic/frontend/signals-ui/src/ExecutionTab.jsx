import React, { useMemo, useState, useCallback } from "react";
import { useSignalData } from "./SignalDataContext";
import { DC_GROUPS, PRODUCT_SIGNAL_HOURS, suggestContract, FULL_SIZES, KB_PER_KT, STRATEGY_OVERRIDES, resolveOverride, matchStrategies } from "./constants";
import { signClass, dateStrLondon, londonNow } from "./helpers";
import useWindowsAlerts from "./useWindowsAlerts";

import { isMuted, setMuted } from "./audio";

const KT_PRODUCTS = new Set(["sg380crk1", "35brgcrk1", "sg05crk1"]);

function formatSize(size, product) {
  if (!size) return "—";
  if (KT_PRODUCTS.has(product)) {
    const kt = Math.round(size / KB_PER_KT * 100) / 100;
    return (kt % 1 === 0) ? `${kt} KT` : `${kt} KT`;
  }
  return (size % 1 === 0) ? `${size} KB` : `${size} KB`;
}

function getStrategy(product) {
  for (const g of DC_GROUPS) {
    if (g.products.has(product)) return g.strategy;
  }
  return "Unknown";
}

function getGroupTitle(product) {
  for (const g of DC_GROUPS) {
    if (g.products.has(product)) return g.title;
  }
  return "";
}

function dcStatus(distTrigger, threshold) {
  if (distTrigger == null || threshold == null || threshold === 0) return { label: "—", cls: "", rowCls: "" };
  const pct = distTrigger / threshold;
  if (pct > 0.5) return { label: "Stable", cls: "status-safe", rowCls: "" };
  if (pct > 0.2) return { label: "Watch", cls: "status-watch", rowCls: "dc-row-watch" };
  return { label: "Close", cls: "status-close", rowCls: "dc-row-close" };
}

function findMatchingTrade(product, strategy, openTrades, alsoMatch) {
  return (openTrades || []).find(
    (t) => t.product === product && (t.strategy === strategy || (alsoMatch && alsoMatch.has(t.strategy)))
  );
}

function buildCloseCard({ id, match, prevPos, product, strategy, price, isStop }) {
  if (!match) return null;
  const tradeDir = match.signal === "long" ? 1 : -1;
  if (prevPos != null && tradeDir !== prevPos) return null;
  return {
    id,
    type: "CLOSE",
    tradeId: match._id,
    product,
    strategy,
    direction: match.signal === "long" ? "LONG" : "SHORT",
    size: match.size,
    existingEntryPrice: match.entry_price,
    price,
    ...(isStop ? { isStop: true } : {}),
  };
}

export default function ExecutionTab() {
  const { windowsData, sigLatestData, openTrades, loading, error, refresh, refreshTrades, lastRefreshed } = useSignalData();

  useWindowsAlerts(windowsData);

  const [muted, setMutedState] = useState(isMuted());
  const toggleMute = () => { const next = !muted; setMuted(next); setMutedState(next); };

  // --- STRATEGY OVERRIDES ---
  const [overrides, setOverrides] = useState(() => {
    try { return JSON.parse(localStorage.getItem("strategyOverrides") || "{}"); }
    catch { return {}; }
  });
  const toggleOverride = (product) => {
    setOverrides((prev) => {
      const next = { ...prev, [product]: !prev[product] };
      localStorage.setItem("strategyOverrides", JSON.stringify(next));
      return next;
    });
  };

  // Resolved DC products: maps each DC_GROUPS product to its active signal key + strategy
  const resolvedDC = useMemo(() => {
    if (!sigLatestData) return [];
    const result = [];
    for (const g of DC_GROUPS) {
      for (const product of g.products) {
        const ovr = resolveOverride(product, overrides);
        const signalKey = ovr ? ovr.signalKey : product;
        const strategy = ovr ? ovr.strategy : g.strategy;
        const payload = sigLatestData[signalKey];
        if (payload) {
          result.push({ product, signalKey, strategy, payload });
        }
      }
    }
    return result;
  }, [sigLatestData, overrides]);

  const todayLondon = useMemo(() => dateStrLondon(new Date()), []);

  // --- DISMISSED CARDS ---
  const [dismissed, setDismissed] = useState(() => {
    try { const v = JSON.parse(localStorage.getItem("dismissedCards") || "[]"); return new Set(v); }
    catch { return new Set(); }
  });
  const dismiss = (cardId) => {
    setDismissed((prev) => {
      const next = new Set(prev).add(cardId);
      localStorage.setItem("dismissedCards", JSON.stringify([...next]));
      return next;
    });
  };

  // --- PER-CARD INPUT STATE ---
  const [cardInputs, setCardInputs] = useState({});

  function getInput(cardId) {
    return cardInputs[cardId] || { exitPrice: "", exitSpread: "", exitFees: "", entryPrice: "", entrySpread: "", entryFees: "", contract: "", sizeOverride: "" };
  }

  function updateInput(cardId, field, value) {
    setCardInputs((prev) => ({
      ...prev,
      [cardId]: { ...getInput(cardId), [field]: value },
    }));
  }

  // --- DC FLIP DETECTION ---
  const flipCards = useMemo(() => {
    if (!resolvedDC.length) return [];
    const cards = [];
    for (const { product, strategy, payload } of resolvedDC) {
      const live = payload?.latest;
      if (!live) continue;
      const currPos = live.pos_desired;
      const prevPos = payload.prev_pos_desired;
      if (prevPos == null || currPos == null || prevPos === currPos) continue;
      if (live.stop_triggered) continue;
      const alsoMatch = matchStrategies(product);
      const match = findMatchingTrade(product, strategy, openTrades, alsoMatch);
      const closeCard = buildCloseCard({ id: `dc_close_${product}_${currPos}`, match, prevPos, product, strategy, price: live.close });
      if (closeCard) cards.push(closeCard);
      if (currPos !== 0) {
        cards.push({ id: `dc_open_${product}_${currPos}`, type: "OPEN", product, strategy, direction: currPos === 1 ? "LONG" : "SHORT", price: live.close, stopLevel: payload.stop_level, distTrigger: payload.dist_trigger, threshold: payload.threshold, timestamp: live.timestamp });
      }
    }
    return cards;
  }, [resolvedDC, openTrades]);

  // --- MA FLIP DETECTION ---
  const maFlipCards = useMemo(() => {
    if (!windowsData?.products) return [];
    const cards = [];
    for (const p of windowsData.products) {
      if (p.prev_position == null || p.position === p.prev_position) continue;
      const match = findMatchingTrade(p.product, "ACF MA", openTrades);
      const closeCard = buildCloseCard({ id: `ma_close_${p.product}_${p.position}`, match, prevPos: p.prev_position, product: p.product, strategy: "ACF MA", price: p.signal_close });
      if (closeCard) cards.push(closeCard);
      if (p.position !== 0) {
        cards.push({ id: `ma_open_${p.product}_${p.position}`, type: "OPEN", product: p.product, strategy: "ACF MA", direction: p.position === 1 ? "LONG" : "SHORT", price: p.signal_close, stopLevel: null, distTrigger: null, threshold: null, timestamp: p.timestamp });
      }
    }
    return cards;
  }, [windowsData, openTrades]);

  // --- STOP CARDS ---
  const stopCards = useMemo(() => {
    if (!resolvedDC.length) return [];
    const cards = [];
    for (const { product, strategy, payload } of resolvedDC) {
      const live = payload?.latest;
      if (!live || !live.stop_triggered) continue;
      if (dateStrLondon(live.timestamp) !== todayLondon) continue;
      const alsoMatch = matchStrategies(product);
      const match = findMatchingTrade(product, strategy, openTrades, alsoMatch);
      const closeCard = buildCloseCard({ id: `stop_close_${product}`, match, prevPos: payload.prev_pos_desired, product, strategy, price: live.close, isStop: true });
      if (closeCard) cards.push(closeCard);
    }
    return cards;
  }, [resolvedDC, todayLondon, openTrades]);

  const allActionCards = useMemo(() => {
    return [...flipCards, ...maFlipCards, ...stopCards].filter((c) => {
      if (dismissed.has(c.id)) return false;
      if (c.type === "CLOSE" && c.tradeId) {
        const tradeExists = (openTrades || []).some((t) => t._id === c.tradeId);
        if (!tradeExists) return false;
      }
      if (c.type === "OPEN") {
        const alsoMatch = matchStrategies(c.product);
        const alreadyOpen = findMatchingTrade(c.product, c.strategy, openTrades, alsoMatch);
        if (alreadyOpen) return false;
      }
      return true;
    });
  }, [flipCards, maFlipCards, stopCards, dismissed, openTrades]);

  function handleDismiss(cardId) {
    dismiss(cardId);
  }

  const handleConfirmClose = useCallback(async (card) => {
    const input = getInput(card.id);
    if (!input.exitPrice || isNaN(parseFloat(input.exitPrice))) return;
    try {
      const res = await fetch(`/api/trades/${card.tradeId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ exit_date: new Date().toISOString(), exit_price: parseFloat(input.exitPrice), exit_spread: input.exitSpread ? parseFloat(input.exitSpread) : 0, exit_fees: input.exitFees ? parseFloat(input.exitFees) : 0, exit_type: "Internal" }),
      });
      if (res.ok) { dismiss(card.id); refreshTrades(); }
    } catch (_) { /* network error */ }
  }, [cardInputs, refreshTrades]);

  const handleConfirmOpen = useCallback(async (card) => {
    const input = getInput(card.id);
    const size = parseFloat(input.sizeOverride);
    if (!input.entryPrice || isNaN(parseFloat(input.entryPrice))) return;
    if (isNaN(size) || size <= 0) return;
    const signal = card.direction === "LONG" ? "long" : "short";
    try {
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entry_date: new Date().toISOString(), product: card.product, signal, strategy: card.strategy, entry_type: "Internal", size, entry_price: parseFloat(input.entryPrice), entry_spread: input.entrySpread ? parseFloat(input.entrySpread) : 0, entry_fees: input.entryFees ? parseFloat(input.entryFees) : 0, contract: input.contract || suggestContract(card.product) }),
      });
      if (res.ok) { dismiss(card.id); refreshTrades(); }
    } catch (_) { /* network error */ }
  }, [cardInputs, refreshTrades]);

  // --- DC MONITORING TABLE ---
  const dcRows = useMemo(() => {
    if (!sigLatestData) return [];
    const rows = [];
    // Active rows from resolvedDC
    for (const { product, strategy, payload } of resolvedDC) {
      const live = payload?.latest;
      if (!live) continue;
      const alsoMatch = matchStrategies(product);
      const stratMatch = findMatchingTrade(product, strategy, openTrades, alsoMatch);
      rows.push({ product, signalKey: product, strategy, groupTitle: getGroupTitle(product), posDesired: live.pos_desired, currentPos: stratMatch ? stratMatch.signal : null, price: live.close, stopLevel: payload.stop_level, distTrigger: payload.dist_trigger, threshold: payload.threshold, stopTriggered: live.stop_triggered, isInHours: payload.is_in_hours ?? false, stopLoss: payload.stop_loss ?? null, contract: stratMatch?.contract || "—", isActive: true });
    }
    // Inactive rows for togglable products
    for (const product of Object.keys(STRATEGY_OVERRIDES)) {
      const cfg = STRATEGY_OVERRIDES[product];
      const inactive = overrides[product] ? cfg.default : cfg.alt;
      const payload = sigLatestData[inactive.signalKey];
      if (!payload?.latest) continue;
      const live = payload.latest;
      rows.push({ product, signalKey: inactive.signalKey, strategy: inactive.strategy, groupTitle: getGroupTitle(product), posDesired: live.pos_desired, currentPos: null, price: live.close, stopLevel: payload.stop_level, distTrigger: payload.dist_trigger, threshold: payload.threshold, stopTriggered: live.stop_triggered, isInHours: payload.is_in_hours ?? false, stopLoss: payload.stop_loss ?? null, contract: "—", isActive: false });
    }
    const groupIndex = (p) => DC_GROUPS.findIndex((g) => g.products.has(p));
    return rows.sort((a, b) => {
      const gi = groupIndex(a.product) - groupIndex(b.product);
      if (gi !== 0) return gi;
      const pi = a.product.localeCompare(b.product);
      if (pi !== 0) return pi;
      return a.isActive ? -1 : 1; // active first
    });
  }, [sigLatestData, openTrades, resolvedDC, overrides]);

  // --- MA MONITORING TABLE ---
  const maRows = useMemo(() => {
    if (!windowsData) return [];
    return (windowsData.products || [])
      .filter((p) => p.product in PRODUCT_SIGNAL_HOURS)
      .map((p) => {
        const ma = p.ma_signals || {};
        const vals = Object.values(ma);
        const total = vals.length;
        const agree = vals.filter((v) => v === vals[0]).length;
        const allAgree = total > 0 && agree === total;
        const hours = PRODUCT_SIGNAL_HOURS[p.product] || [];
        const { hour: nowHour, minute: nowMin } = londonNow();
        const nowMins = nowHour * 60 + nowMin;
        let nextSig = null;
        for (const h of hours) {
          const sigMins = h * 60;
          if (sigMins > nowMins) { const diff = sigMins - nowMins; const hLeft = Math.floor(diff / 60); const mLeft = diff % 60; nextSig = `${String(h).padStart(2, "0")}:00 (${hLeft}h ${mLeft}m)`; break; }
        }
        if (!nextSig && hours.length > 0) nextSig = `${String(hours[0]).padStart(2, "0")}:00 (tomorrow)`;
        const stratMatch = findMatchingTrade(p.product, "ACF MA", openTrades);
        return { product: p.product, cumDelta: p.cum_delta_signal, posLabel: p.position === 1 ? "LONG" : p.position === -1 ? "SHORT" : "FLAT", currentPos: stratMatch ? stratMatch.signal : null, agreement: `${agree}/${total} agree`, allAgree, nextSignal: nextSig, signalHour: p.signal_hour, contract: stratMatch?.contract || "—" };
      })
      .sort((a, b) => (a.signalHour ?? 0) - (b.signalHour ?? 0));
  }, [windowsData, openTrades]);

  // --- CURRENT PORTFOLIO POSITION ---
  const portfolioData = useMemo(() => {
    const maProducts = Object.keys(PRODUCT_SIGNAL_HOURS);
    const maProds = (windowsData?.products || []);
    const sumSize = (product, strategies) => (openTrades || []).filter((t) => t.product === product && (Array.isArray(strategies) ? strategies.includes(t.strategy) : t.strategy === strategies)).reduce((sum, t) => sum + (t.size || 0), 0);
    const ma = maProducts.map((p) => {
      const match = findMatchingTrade(p, "ACF MA", openTrades);
      const wRow = maProds.find((r) => r.product === p);
      const posDesired = wRow?.position === 1 ? "LONG" : wRow?.position === -1 ? "SHORT" : "FLAT";
      const size = sumSize(p, "ACF MA");
      return { product: p, contract: match?.contract || "—", size, position: match ? match.signal?.toUpperCase() : "FLAT", posDesired };
    });
    const dc = resolvedDC.map(({ product, strategy, payload }) => {
      const alsoMatch = matchStrategies(product);
      const match = findMatchingTrade(product, strategy, openTrades, alsoMatch);
      const pd = payload?.latest?.pos_desired;
      const posDesired = pd === 1 ? "LONG" : pd === -1 ? "SHORT" : "FLAT";
      const allStrategies = alsoMatch ? [...alsoMatch] : [strategy];
      const size = sumSize(product, allStrategies);
      return { product, strategy, contract: match?.contract || "—", size, position: match ? match.signal?.toUpperCase() : "FLAT", posDesired };
    });
    return { ma, dc };
  }, [openTrades, windowsData, resolvedDC]);

  return (
    <div style={{ padding: 16 }}>
      {/* HEADER */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
        <button
          onClick={refresh}
          disabled={loading}
          style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid var(--border-button)", background: loading ? "var(--bg-disabled)" : "var(--bg-card)", cursor: loading ? "not-allowed" : "pointer", fontWeight: 600, color: "var(--text-primary)" }}
        >
          {loading ? "Refreshing..." : "Refresh"}
        </button>
        <div style={{ fontSize: 13, color: "var(--text-muted)" }}>
          {lastRefreshed ? (<>Last updated: <b>{lastRefreshed}</b></>) : <>—</>}
        </div>
        {error ? (
          <div style={{ marginLeft: "auto", color: "var(--text-error)", fontSize: 13 }}><b>Error:</b> {error}</div>
        ) : null}
        <button
          onClick={toggleMute}
          style={{ marginLeft: error ? 12 : "auto", padding: "6px 14px", borderRadius: 10, border: "1px solid var(--border-button)", background: muted ? "var(--bg-muted-button)" : "var(--bg-green-button)", cursor: "pointer", fontWeight: 600, fontSize: 13, color: "var(--text-primary)" }}
        >
          {muted ? "Unmute" : "Mute"}
        </button>
      </div>

      {/* PRE-ACTION WARNINGS — products approaching trigger */}
      {dcRows.filter((r) => {
        if (!r.isActive) return false;
        if (r.distTrigger == null || r.threshold == null || r.threshold === 0) return false;
        return r.distTrigger / r.threshold <= 0.5;
      }).length > 0 && (
        <div style={{ marginBottom: 12 }}>
          {dcRows.filter((r) => {
            if (!r.isActive) return false;
            if (r.distTrigger == null || r.threshold == null || r.threshold === 0) return false;
            return r.distTrigger / r.threshold <= 0.5;
          }).map((r) => {
            const pct = r.distTrigger / r.threshold;
            const isClose = pct <= 0.2;
            const oppositeLabel = r.posDesired === 1 ? "SHORT" : r.posDesired === -1 ? "LONG" : "FLAT";
            return (
              <div key={`warn-${r.product}`} className={isClose ? "banner-close" : "banner-watch"}>
                <b>{r.product}</b>: {Number(r.distTrigger).toFixed(2)} from DC <b>{oppositeLabel}</b> event trigger — check lookback · <b>{r.isInHours ? "on" : "off"} trading hours</b>
              </div>
            );
          })}
        </div>
      )}

      {/* PRE-ACTION WARNINGS — positions approaching stop */}
      {dcRows.filter((r) => {
        if (!r.isActive) return false;
        if (r.posDesired === 0 || r.stopLevel == null || r.stopLoss == null || r.stopLoss === 0) return false;
        const distToStop = r.posDesired === 1 ? r.price - r.stopLevel : r.stopLevel - r.price;
        return distToStop >= 0 && distToStop / r.stopLoss <= 0.5;
      }).length > 0 && (
        <div style={{ marginBottom: 12 }}>
          {dcRows.filter((r) => {
            if (!r.isActive) return false;
            if (r.posDesired === 0 || r.stopLevel == null || r.stopLoss == null || r.stopLoss === 0) return false;
            const distToStop = r.posDesired === 1 ? r.price - r.stopLevel : r.stopLevel - r.price;
            return distToStop >= 0 && distToStop / r.stopLoss <= 0.5;
          }).map((r) => {
            const distToStop = r.posDesired === 1 ? r.price - r.stopLevel : r.stopLevel - r.price;
            const pct = distToStop / r.stopLoss;
            const isClose = pct <= 0.2;
            const posLabel = r.posDesired === 1 ? "LONG" : "SHORT";
            return (
              <div key={`stop-warn-${r.product}`} className={isClose ? "banner-close" : "banner-watch"}>
                <b>{r.product}</b>: {Number(distToStop).toFixed(2)} from stop — <b>{posLabel}</b> position at risk · <b>{r.isInHours ? "on" : "off"} trading hours</b>
              </div>
            );
          })}
        </div>
      )}

      {/* ACTION REQUIRED SECTION */}
      <h3 className="exec-section-header">Action Required</h3>

      {allActionCards.length === 0 ? (
        <div className="banner-stable">All positions stable — no action required</div>
      ) : (
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
          {allActionCards.map((card) => {
            const input = getInput(card.id);

            if (card.type === "CLOSE") {
              const isStop = card.isStop;
              const borderColor = isStop ? "var(--sig-short)" : "var(--sig-warn)";
              const bgColor = isStop ? "var(--bg-red-tint)" : "var(--bg-yellow-tint)";
              const labelColor = isStop ? "var(--sig-short)" : "var(--bg-yellow-text)";
              const label = isStop ? `STOP — CLOSE ${card.direction}` : `CLOSE ${card.direction}`;
              const exitValid = input.exitPrice && !isNaN(parseFloat(input.exitPrice));

              return (
                <div key={card.id} className="action-card" style={{ borderLeft: `4px solid ${borderColor}`, background: bgColor, minWidth: 280 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: labelColor, marginBottom: 4 }}>{label}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 10 }}>{card.product} · {card.strategy}</div>
                  <div className="action-card-details">
                    <div><span className="action-card-label">Size</span><span style={{ fontWeight: 600 }}>{card.size} KB</span></div>
                    <div><span className="action-card-label">Entry Price</span><span>{card.existingEntryPrice != null ? Number(card.existingEntryPrice).toFixed(2) : "—"}</span></div>
                    <div><span className="action-card-label">Current Price</span><span>{card.price != null ? Number(card.price).toFixed(2) : "—"}</span></div>
                  </div>
                  <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                    <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                      Exit Price
                      <input type="number" step="any" value={input.exitPrice} onChange={(e) => updateInput(card.id, "exitPrice", e.target.value)}
                        style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                    </label>
                    <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                      Exit Spread
                      <input type="number" step="any" value={input.exitSpread} onChange={(e) => updateInput(card.id, "exitSpread", e.target.value)}
                        style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                    </label>
                    <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                      Exit Fees
                      <input type="number" step="any" value={input.exitFees} onChange={(e) => updateInput(card.id, "exitFees", e.target.value)}
                        style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                    </label>
                  </div>
                  <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                    <button onClick={() => handleDismiss(card.id)} style={{ padding: "4px 12px", fontSize: 12, borderRadius: 6, border: "1px solid var(--border-input)", background: "var(--bg-card)", cursor: "pointer", color: "var(--text-primary)" }}>Dismiss</button>
                    <button onClick={() => handleConfirmClose(card)} disabled={!exitValid}
                      style={{ padding: "4px 12px", fontSize: 12, borderRadius: 6, border: "1px solid var(--border-input)", background: exitValid ? "var(--accent)" : "var(--bg-disabled)", color: "var(--text-on-accent)", cursor: exitValid ? "pointer" : "not-allowed", fontWeight: 600 }}>
                      Confirm Close
                    </button>
                  </div>
                </div>
              );
            }

            // --- OPEN CARD ---
            const isLong = card.direction === "LONG";
            const borderColor = isLong ? "var(--sig-long)" : "var(--sig-short)";
            const bgColor = isLong ? "var(--bg-green-tint)" : "var(--bg-red-tint)";
            const labelColor = isLong ? "var(--sig-long)" : "var(--sig-short)";
            const contractVal = input.contract || suggestContract(card.product);
            const entryValid = input.entryPrice && !isNaN(parseFloat(input.entryPrice));
            const sizeValid = input.sizeOverride && !isNaN(parseFloat(input.sizeOverride)) && parseFloat(input.sizeOverride) > 0;
            const canConfirm = entryValid && sizeValid;

            return (
              <div key={card.id} className="action-card" style={{ borderLeft: `4px solid ${borderColor}`, background: bgColor, minWidth: 280 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: labelColor, marginBottom: 4 }}>OPEN {card.direction}</div>
                <div style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 10 }}>{card.product} · {card.strategy}</div>
                <div className="action-card-details">
                  <div>
                    <span className="action-card-label">Contract</span>
                    <input type="text" value={contractVal} onChange={(e) => updateInput(card.id, "contract", e.target.value.toUpperCase())}
                      style={{ width: 70, padding: 2, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, fontWeight: 700 }} />
                  </div>
                  <div>
                    <span className="action-card-label">Size</span>
                    <input type="number" step="any" placeholder="KB" value={input.sizeOverride} onChange={(e) => updateInput(card.id, "sizeOverride", e.target.value)}
                      style={{ width: 70, padding: 2, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4 }} />
                  </div>
                  <div><span className="action-card-label">Current Price</span><span>{card.price != null ? Number(card.price).toFixed(2) : "—"}</span></div>
                  {card.stopLevel != null && (<div><span className="action-card-label">Stop Level</span><span>{Number(card.stopLevel).toFixed(2)}</span></div>)}
                  {card.distTrigger != null && (<div><span className="action-card-label">Dist to Trigger</span><span>{Number(card.distTrigger).toFixed(2)}</span></div>)}
                </div>
                <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                  <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                    Entry Price
                    <input type="number" step="any" value={input.entryPrice} onChange={(e) => updateInput(card.id, "entryPrice", e.target.value)}
                      style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                  </label>
                  <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                    Entry Spread
                    <input type="number" step="any" value={input.entrySpread} onChange={(e) => updateInput(card.id, "entrySpread", e.target.value)}
                      style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                  </label>
                  <label style={{ fontSize: 12, fontWeight: 600, flex: 1 }}>
                    Entry Fees
                    <input type="number" step="any" value={input.entryFees} onChange={(e) => updateInput(card.id, "entryFees", e.target.value)}
                      style={{ display: "block", width: "100%", padding: 4, fontSize: 12, border: "1px solid var(--border-input)", borderRadius: 4, marginTop: 2 }} />
                  </label>
                </div>
                <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                  <button onClick={() => handleDismiss(card.id)} style={{ padding: "4px 12px", fontSize: 12, borderRadius: 6, border: "1px solid var(--border-input)", background: "var(--bg-card)", cursor: "pointer", color: "var(--text-primary)" }}>Dismiss</button>
                  <button onClick={() => handleConfirmOpen(card)} disabled={!canConfirm}
                    style={{ padding: "4px 12px", fontSize: 12, borderRadius: 6, border: "1px solid var(--border-input)", background: canConfirm ? "var(--accent)" : "var(--bg-disabled)", color: "var(--text-on-accent)", cursor: canConfirm ? "pointer" : "not-allowed", fontWeight: 600 }}>
                    Confirm Open
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MA MONITORING */}
      <h3 className="exec-section-header">MA Signals</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, marginBottom: 16 }}>
        <table className="dataTable" style={{ minWidth: 600 }}>
          <thead><tr><th>Product</th><th>Pos Desired</th><th>Cum Delta</th><th>MAs Agreement</th><th>Next Signal</th><th>Status</th></tr></thead>
          <tbody>
            {maRows.length === 0 ? (
              <tr><td colSpan={6}>No data</td></tr>
            ) : maRows.map((r) => {
              const posColor = r.posLabel === "FLAT" ? "var(--sig-neutral)" : r.cumDelta === 1 ? "var(--sig-long)" : r.cumDelta === -1 ? "var(--sig-short)" : "var(--sig-neutral)";
              const curLabel = r.currentPos ? r.currentPos.toUpperCase() : "FLAT";
              const mismatch = curLabel !== r.posLabel;
              return (
                <tr key={r.product}>
                  <td className="product">{r.product}</td>
                  <td>
                    <div style={{ color: posColor, fontWeight: 700 }}>{r.posLabel}</div>
                    {mismatch && <div style={{ fontSize: 10, color: "var(--sig-warn)", fontWeight: 600 }}>now: {curLabel}</div>}
                  </td>
                  <td className={signClass(r.cumDelta)}>{r.cumDelta ?? ""}</td>
                  <td>{r.agreement}</td>
                  <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{r.nextSignal}</td>
                  <td><span className={`status-badge ${r.allAgree ? "status-safe" : "status-watch"}`}>{r.allAgree ? "Stable" : "Mixed"}</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* DC MONITORING */}
      <h3 className="exec-section-header">DC Signals</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12 }}>
        <table className="dataTable" style={{ minWidth: 700 }}>
          <thead><tr><th>Product</th><th>Strategy</th><th>Pos Desired</th><th>Price</th><th>Stop</th><th>Distance to Trigger</th><th>Status</th></tr></thead>
          <tbody>
            {dcRows.length === 0 ? (
              <tr><td colSpan={7}>No data</td></tr>
            ) : dcRows.map((r) => {
              const posLabel = r.posDesired === 1 ? "LONG" : r.posDesired === -1 ? "SHORT" : "FLAT";
              const posColor = r.posDesired === 1 ? "var(--sig-long)" : r.posDesired === -1 ? "var(--sig-short)" : "var(--sig-neutral)";
              const curLabel = r.currentPos ? r.currentPos.toUpperCase() : "FLAT";
              const mismatch = r.isActive && curLabel !== posLabel;
              const st = dcStatus(r.distTrigger, r.threshold);
              const dimStyle = r.isActive ? {} : { opacity: 0.4 };
              return (
                <tr key={`${r.product}-${r.strategy}`} className={r.isActive ? st.rowCls : ""} style={dimStyle}>
                  <td className="product">{r.product}</td>
                  <td style={{ fontSize: 11, color: r.isActive ? "var(--text-primary)" : "var(--text-muted)" }}>
                    {STRATEGY_OVERRIDES[r.product] ? (
                      <span onClick={() => toggleOverride(r.product)} style={{ cursor: "pointer", borderBottom: "1px dashed var(--text-muted)" }} title="Click to switch strategy">
                        {r.strategy} &#x21C5;
                      </span>
                    ) : r.strategy}
                  </td>
                  <td>
                    <div style={{ color: posColor, fontWeight: 700 }}>{posLabel}</div>
                    {mismatch && <div style={{ fontSize: 10, color: "var(--sig-warn)", fontWeight: 600 }}>now: {curLabel}</div>}
                  </td>
                  <td>{r.price != null ? Number(r.price).toFixed(2) : ""}</td>
                  <td>{r.stopLevel != null ? Number(r.stopLevel).toFixed(2) : ""}</td>
                  <td>{r.distTrigger != null ? Number(r.distTrigger).toFixed(2) : ""}</td>
                  <td><span className={`status-badge ${st.cls}`}>{st.label}</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* CURRENT PORTFOLIO POSITION */}
      <h3 className="exec-section-header" style={{ marginTop: 24 }}>Current Portfolio Position</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12 }}>
        <table className="dataTable" style={{ minWidth: 500 }}>
          <thead>
            <tr>
              <th style={{ width: 80 }}></th>
              {portfolioData.ma.length > 0 && <th colSpan={portfolioData.ma.length} style={{ textAlign: "center" }}>MA Signals</th>}
              <th colSpan={portfolioData.dc.length} style={{ textAlign: "center" }}>DC Signals</th>
            </tr>
            <tr>
              <th></th>
              {portfolioData.ma.map((p) => <th key={`ma-${p.product}`} style={{ fontSize: 11, textAlign: "center" }}>{p.product}</th>)}
              {portfolioData.dc.map((p) => <th key={`dc-${p.product}`} style={{ fontSize: 11, textAlign: "center" }}>{p.product}{p.strategy && <div style={{ fontSize: 9, fontWeight: 400, color: "var(--text-muted)" }}>{p.strategy}</div>}</th>)}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ fontWeight: 700 }}>Contract</td>
              {portfolioData.ma.map((p) => <td key={`ma-c-${p.product}`} style={{ textAlign: "center", fontWeight: 600 }}>{p.contract}</td>)}
              {portfolioData.dc.map((p) => <td key={`dc-c-${p.product}`} style={{ textAlign: "center", fontWeight: 600 }}>{p.contract}</td>)}
            </tr>
            <tr>
              <td style={{ fontWeight: 700 }}>Size</td>
              {[...portfolioData.ma, ...portfolioData.dc].map((p, i) => {
                const prefix = i < portfolioData.ma.length ? "ma" : "dc";
                const full = FULL_SIZES[p.product];
                const isFull = p.size && full && p.size >= full;
                return (
                  <td key={`${prefix}-s-${p.product}`} style={{ textAlign: "center", fontWeight: 600, fontSize: 13 }}>
                    {formatSize(p.size, p.product)}
                    {p.size > 0 && full && (
                      <div style={{ fontSize: 10, fontWeight: 400, color: isFull ? "var(--sig-long)" : "var(--sig-warn)" }}>
                        {isFull ? "Full" : `of ${formatSize(full, p.product)}`}
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
            <tr>
              <td style={{ fontWeight: 700 }}>Position</td>
              {[...portfolioData.ma, ...portfolioData.dc].map((p, i) => {
                const prefix = i < portfolioData.ma.length ? "ma" : "dc";
                const color = p.position === "LONG" ? "var(--sig-long)" : p.position === "SHORT" ? "var(--sig-short)" : "var(--sig-neutral)";
                const mismatch = p.position !== p.posDesired;
                return (
                  <td key={`${prefix}-p-${p.product}`} style={{ textAlign: "center", fontWeight: 700, color }}>
                    {p.position}
                    {mismatch && <div style={{ fontSize: 10, color: "var(--sig-warn)", fontWeight: 400 }}>signal: {p.posDesired}</div>}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
