import React, { useMemo, useState } from "react";
import { useSignalData } from "./SignalDataContext";
import { DC_GROUPS_SIGNALS as DC_GROUPS, rawProduct } from "./constants";
import { signClass, formatTimestampNoTZ, formatLondonNoTZ, dateStrLondon } from "./helpers";

function getStatusStyle(group, posDesired) {
  if (group === "A") {
    return posDesired === 1
      ? { color: "var(--st-a-long-text)", background: "var(--st-a-long-bg)" }
      : { color: "var(--st-a-short-text)", background: "var(--st-a-short-bg)" };
  }
  if (group === "E") return { color: "var(--st-e-text)", background: "var(--st-e-bg)" };
  if (group === "B") return { color: "var(--st-b-text)", background: "var(--st-b-bg)" };
  if (group === "D") return { color: "var(--st-d-text)", background: "var(--st-d-bg)" };
  return { color: "var(--st-default-text)", background: "var(--st-default-bg)" };
}

function historyLabelColor(label) {
  if (!label) return "var(--text-secondary)";
  if (label.startsWith("●") && label.includes("LONG")) return "var(--st-a-long-text)";
  if (label.startsWith("●") && label.includes("SHORT")) return "var(--st-a-short-text)";
  if (label.startsWith("✗")) return "var(--st-b-text)";
  return "var(--text-secondary)";
}

function formatHistoryTs(isoStr) {
  try {
    const d = new Date(isoStr);
    return d.toLocaleString("en-GB", { timeZone: "Europe/London", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch { return isoStr ? isoStr.substring(0, 16) : ""; }
}

function formatRelativeTime(isoStr) {
  try {
    const diff = Date.now() - new Date(isoStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 2) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  } catch { return ""; }
}

export default function SystematicSignalsDashboard() {
  const { windowsData, sigLatestData, loading, error, refresh } = useSignalData();
  const [expandedLogs, setExpandedLogs] = useState({});
  const [expandedDetails, setExpandedDetails] = useState({});
  const [openHistory, setOpenHistory] = useState(null);

  const todayLondon = useMemo(() => dateStrLondon(new Date()), []);

  const maKeys = useMemo(() => {
    const keys = new Set();
    for (const p of windowsData?.products || []) {
      for (const k of Object.keys(p?.ma_signals || {})) keys.add(k);
    }
    return Array.from(keys).sort((a, b) => Number(a) - Number(b));
  }, [windowsData]);

  const dcSummaryRows = useMemo(() => {
    if (!sigLatestData) return [];
    return DC_GROUPS.flatMap((g) =>
      [...g.products].map((product) => {
        const payload = sigLatestData[product];
        if (!payload) return null;
        return { product, strategy: g.title, signalStatus: payload.signal_status || "—", signalStatusGroup: payload.signal_status_group || "C", posDesired: payload.latest?.pos_desired ?? 0, statusHistory: payload.status_history || [] };
      }).filter(Boolean)
    );
  }, [sigLatestData]);

  const windowsRows = useMemo(() => {
    return [...(windowsData?.products || [])].sort((a, b) => (a.signal_hour ?? 0) - (b.signal_hour ?? 0));
  }, [windowsData]);

  const sigGroups = useMemo(() => {
    if (!sigLatestData) return DC_GROUPS.map((g) => ({ title: g.title, rows: [] }));
    const typeRank = { LIVE: 0, "EVENT LOG": 1, "LAST EVENT": 2, "LAST STOP": 3 };
    const sortRows = (rows) => rows.sort((a, b) => {
      if (a.product !== b.product) return a.product.localeCompare(b.product);
      const t = (typeRank[a.type] ?? 99) - (typeRank[b.type] ?? 99);
      if (t !== 0) return t;
      return new Date(b.timestamp) - new Date(a.timestamp);
    });
    return DC_GROUPS.map((g) => {
      const out = [];
      for (const [product, payload] of Object.entries(sigLatestData)) {
        if (!g.products.has(product)) continue;
        if (payload?.latest) out.push({ product, type: "LIVE", threshold: payload.threshold, stop_level: payload.stop_level, dist_trigger: payload.dist_trigger, lookback_step: payload.lookback, prev_pos_desired: payload.prev_pos_desired, ...payload.latest });
        for (const eb of payload?.events_between || []) out.push({ product, type: "EVENT LOG", trade_hours: payload.trade_hours, ...eb });
        if (payload?.last_event) out.push({ product, type: "LAST EVENT", threshold: payload.threshold, stop_level: payload.stop_level, dist_trigger: payload.dist_trigger, lookback_step: payload.lookback, ...payload.last_event });
      }
      return { title: g.title, rows: sortRows(out) };
    });
  }, [sigLatestData]);

  function rowStyleForSig(row) {
    const isToday = dateStrLondon(row.timestamp) === todayLondon;
    if (row.type === "EVENT LOG") return { background: "var(--bg-event-log)", fontSize: 12, color: "var(--text-event-log)" };
    if (row.type === "LAST EVENT" && isToday) return { background: "var(--bg-row-today)" };
    if (row.stop_triggered && isToday) return { background: "var(--bg-row-stop)" };
    return {};
  }

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
        <button onClick={refresh} disabled={loading}
          style={{ padding: "8px 12px", borderRadius: 10, border: "1px solid var(--border-button)", background: loading ? "var(--bg-disabled)" : "var(--bg-card)", cursor: loading ? "not-allowed" : "pointer", fontWeight: 600, color: "var(--text-primary)" }}>
          {loading ? "Refreshing..." : "Refresh"}
        </button>
        <div style={{ fontSize: 13, color: "var(--text-muted)" }}>
          {windowsData?.last_updated ? (<>Last updated: <b>{formatLondonNoTZ(windowsData.last_updated)}</b></>) : <>—</>}
        </div>
        {error ? (<div style={{ marginLeft: "auto", color: "var(--text-error)", fontSize: 13 }}><b>Error:</b> {error}</div>) : null}
      </div>

      {/* WINDOWS */}
      <h3 style={{ margin: "12px 0 8px" }}>ACF & MAs</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, maxHeight: 360 }}>
        <table className="dataTable">
          <colgroup>
            <col className="col-product" /><col className="col-hour" /><col className="col-ts" /><col className="col-price" /><col className="col-cd" />
            {maKeys.map((k) => <col key={k} className="col-ma" />)}
          </colgroup>
          <thead><tr><th>Product</th><th>Signal Hour</th><th>Timestamp</th><th>ACF Last Price</th><th>Cum Delta</th>{maKeys.map((k) => <th key={k}>MA {k}</th>)}</tr></thead>
          <tbody>
            {windowsRows.length === 0 ? (
              <tr><td colSpan={5 + maKeys.length}>No data</td></tr>
            ) : windowsRows.map((p, idx) => {
              const ma = p?.ma_signals || {};
              return (
                <tr key={`${p.product}-${p.timestamp}-${idx}`}>
                  <td className="product">{p.product}</td>
                  <td>{p.signal_hour ?? ""}</td>
                  <td>{p.timestamp}</td>
                  <td>{p.signal_close ?? ""}</td>
                  <td className={signClass(p.cum_delta_signal)}>{p.cum_delta_signal ?? ""}</td>
                  {maKeys.map((k) => <td key={k} className={signClass(ma[k])}>{ma[k] ?? ""}</td>)}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* DC LEGEND */}
      <div style={{ margin: "18px 0 8px", fontSize: 12, color: "var(--text-muted)" }}>
        <span style={{ display: "inline-block", padding: "2px 8px", borderRadius: 999, background: "var(--bg-legend-yellow)", marginRight: 8 }}>Last event is today</span>
        <span style={{ display: "inline-block", padding: "2px 8px", borderRadius: 999, background: "var(--bg-legend-red)" }}>Stop triggered today</span>
      </div>

      {/* DC STATUS SUMMARY */}
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, marginBottom: 16 }}>
        <table className="dataTable" style={{ minWidth: 560 }}>
          <thead><tr><th>Product</th><th>Strategy</th><th>Status</th><th style={{ width: 64, textAlign: "center" }}>History</th></tr></thead>
          <tbody>
            {dcSummaryRows.length === 0 ? (
              <tr><td colSpan={4}>No data</td></tr>
            ) : dcSummaryRows.map((r) => {
              const style = getStatusStyle(r.signalStatusGroup, r.posDesired);
              const isOpen = openHistory === r.product;
              return (
                <React.Fragment key={`${r.product}_${r.strategy}`}>
                  <tr>
                    <td className="product">{rawProduct(r.product)}</td>
                    <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{r.strategy}</td>
                    <td>
                      <span style={{ display: "inline-block", padding: "2px 8px", borderRadius: 5, fontSize: 12, fontWeight: 600, ...style }}>{r.signalStatus}</span>
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <button onClick={() => setOpenHistory(isOpen ? null : r.product)}
                        style={{ padding: "3px 8px", fontSize: 11, borderRadius: 5, border: "1px solid var(--border-button)", background: isOpen ? "var(--accent)" : "var(--bg-card)", color: isOpen ? "var(--text-on-accent)" : "var(--text-secondary)", cursor: "pointer", fontWeight: 600 }}>
                        ⏱ {isOpen ? "▴" : "▾"}
                      </button>
                    </td>
                  </tr>
                  {isOpen && (
                    <tr style={{ background: "var(--bg-expanded)" }}>
                      <td colSpan={4} style={{ padding: "10px 20px" }}>
                        {r.statusHistory.length === 0 ? (
                          <span style={{ fontSize: 12, color: "var(--text-faded)" }}>No history available</span>
                        ) : (
                          <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
                            {r.statusHistory.map((h, i) => {
                              const dotColor = historyLabelColor(h.label);
                              const isLast = i === r.statusHistory.length - 1;
                              return (
                                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 16, flexShrink: 0 }}>
                                    <div style={{ width: 10, height: 10, borderRadius: "50%", marginTop: 3, background: dotColor, flexShrink: 0, boxShadow: `0 0 0 2px var(--timeline-dot-shadow), 0 0 0 3px ${dotColor}` }} />
                                    {!isLast && <div style={{ width: 2, flex: 1, background: "var(--timeline-line)", minHeight: 14 }} />}
                                  </div>
                                  <div style={{ paddingBottom: isLast ? 0 : 10 }}>
                                    <div style={{ fontSize: 12, fontWeight: 600, color: dotColor, lineHeight: 1.3 }}>{h.label}</div>
                                    <div style={{ fontSize: 10, color: "var(--text-faded)", marginTop: 1 }}>
                                      {formatHistoryTs(h.timestamp)}
                                      <span style={{ marginLeft: 6, color: "var(--text-faded)" }}>·</span>
                                      <span style={{ marginLeft: 6 }}>{formatRelativeTime(h.timestamp)}</span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* DC TABLES */}
      {sigGroups.map((group) => (
        <React.Fragment key={group.title}>
          <h3 style={{ margin: "14px 0 8px" }}>{group.title}</h3>
          <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, maxHeight: 600, overflowY: "auto" }}>
            <table className="dataTable">
              <colgroup>
                <col style={{ width: 90 }} /><col style={{ width: 110 }} /><col style={{ width: 70 }} /><col style={{ width: 80 }} />
                <col style={{ width: 50 }} /><col style={{ width: 80 }} /><col style={{ width: 95 }} /><col style={{ width: 95 }} /><col style={{ width: 90 }} />
              </colgroup>
              <thead><tr><th>Product</th><th>Timestamp</th><th>Open</th><th>Current Value</th><th>Event</th><th>Pos Desired</th><th>Lookback Step</th><th>Lookback</th><th>Type</th></tr></thead>
              <tbody>
                {group.rows.length === 0 ? (
                  <tr><td colSpan={9}>No data</td></tr>
                ) : group.rows.map((r, idx) => {
                  const prev = group.rows[idx - 1];
                  const isNewProduct = !prev || prev.product !== r.product;
                  const hasEventLog = r.type === "LIVE" && group.rows.some((x) => x.product === r.product && x.type === "EVENT LOG");
                  const logKey = r.product;
                  const isExpanded = !!expandedLogs[logKey];
                  if (r.type === "EVENT LOG" && !expandedLogs[r.product]) return null;

                  return (
                    <React.Fragment key={`${r.product}-${r.type}-${r.timestamp}-${idx}`}>
                      {!isNewProduct ? null : idx !== 0 ? <tr><td colSpan={9} style={{ height: 8, background: "var(--bg-spacer)" }} /></tr> : null}
                      <tr
                        style={{ ...rowStyleForSig(r), cursor: r.type === "LIVE" ? "pointer" : undefined }}
                        onClick={() => { if (r.type === "LIVE") setExpandedDetails((prev) => ({ ...prev, [r.product]: !prev[r.product] })); }}
                      >
                        <td className="product">
                          {rawProduct(r.product)}
                          {hasEventLog && (
                            <span onClick={(e) => { e.stopPropagation(); setExpandedLogs((prev) => ({ ...prev, [logKey]: !prev[logKey] })); }}
                              style={{ cursor: "pointer", marginLeft: 6, fontSize: 10, userSelect: "none" }} title="Toggle event log">
                              {isExpanded ? "\u25B2" : "\u25BC"}
                            </span>
                          )}
                        </td>
                        <td>{formatTimestampNoTZ(r.timestamp)}</td>
                        <td>{r.open ?? ""}</td>
                        <td>{r.close ?? ""}</td>
                        <td className={signClass(r.event)}>{r.event ?? ""}</td>
                        <td className={signClass(r.pos_desired)}>{r.pos_desired ?? ""}</td>
                        <td>{r.type === "LIVE" && r.lookback_step != null ? r.lookback_step
                          : r.type === "EVENT LOG" && r.close_lookback != null && r.close != null
                            ? <span style={{ color: (r.event === 1 && r.close > r.close_lookback) || (r.event === -1 && r.close < r.close_lookback) ? "var(--lookback-pass)" : "var(--lookback-fail)", fontWeight: 600 }}>
                                {(r.event === 1 && r.close > r.close_lookback) || (r.event === -1 && r.close < r.close_lookback) ? "\u2713" : "\u2717"}
                              </span>
                          : ""}</td>
                        <td>{r.type === "LIVE" && r.close_lookback != null ? r.close_lookback.toFixed(2)
                          : r.type === "EVENT LOG" && r.trade_hours && r.timestamp
                            ? (() => {
                                const h = new Date(r.timestamp).getUTCHours();
                                const inH = h >= r.trade_hours[0] && h <= r.trade_hours[1];
                                return <span style={{ color: inH ? "var(--lookback-pass)" : "var(--lookback-fail)", fontWeight: 600 }}>{inH ? "IN HOURS" : "OFF HOURS"}</span>;
                              })()
                          : ""}</td>
                        <td>{r.type === "LIVE" && r.pos_desired === 0 && r.prev_pos_desired != null
                          ? <span style={{ color: "var(--sig-warn)", fontWeight: 700, fontSize: 11 }}>WAIT FOR A {r.prev_pos_desired === 1 ? "SHORT" : "LONG"} SIGNAL</span>
                          : r.type}</td>
                      </tr>
                      {r.type === "LIVE" && expandedDetails[r.product] && (
                        <tr style={{ background: "var(--bg-expanded)" }}>
                          <td colSpan={9} style={{ padding: "6px 16px", fontSize: 12 }}>
                            <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
                              <span><b style={{ color: "var(--text-muted)" }}>Stop Level:</b> {r.stop_level != null ? r.stop_level.toFixed(2) : "—"}</span>
                              <span><b style={{ color: "var(--text-muted)" }}>Extreme:</b> {r.price_extreme != null ? r.price_extreme.toFixed(2) : "—"}</span>
                              <span><b style={{ color: "var(--text-muted)" }}>Dist Trigger:</b> {r.dist_trigger != null ? r.dist_trigger.toFixed(2) : "—"}</span>
                              <span><b style={{ color: "var(--text-muted)" }}>Threshold:</b> {r.threshold ?? "—"}</span>
                              <span><b style={{ color: "var(--text-muted)" }}>Stop Triggered:</b> <span style={{ color: r.stop_triggered ? "var(--sig-short)" : undefined, fontWeight: 700 }}>{String(!!r.stop_triggered).toUpperCase()}</span></span>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
