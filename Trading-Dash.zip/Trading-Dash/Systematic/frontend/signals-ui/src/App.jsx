import { useState, useEffect } from "react";
import { SignalDataProvider, useSignalData } from "./SignalDataContext";
import ExecutionTab from "./ExecutionTab";
import SignalsTable from "./SignalsTable";
import TradeBlotter from "./TradeBlotter";
import RiskTab from "./RiskTab";
import SlippageTab from "./SlippageTab";
import useDCAlerts from "./useDCAlerts";

function GlobalAlerts() {
  const { sigLatestData, windowsData } = useSignalData();
  useDCAlerts(sigLatestData, windowsData);
  return null;
}

const TABS = [
  { id: "execution", label: "Execution" },
  { id: "signals", label: "Signals" },
  { id: "blotter", label: "Trade Blotter" },
  { id: "risk", label: "Risk" },
  { id: "slippage", label: "Slippage" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState(() => localStorage.getItem("activeTab") || "execution");
  const changeTab = (id) => { setActiveTab(id); localStorage.setItem("activeTab", id); };

  const [theme, setTheme] = useState(() => localStorage.getItem("theme") || "light");
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);

  return (
    <SignalDataProvider>
      <GlobalAlerts />
      <div className="page">
        <div style={{ display: "flex", gap: 0, marginBottom: 16, alignItems: "center" }}>
          {TABS.map((tab, idx) => {
            const isFirst = idx === 0;
            const isLast = idx === TABS.length - 1;
            return (
              <button
                key={tab.id}
                onClick={() => !tab.disabled && changeTab(tab.id)}
                disabled={tab.disabled}
                style={{
                  padding: "8px 20px",
                  border: "1px solid var(--border-button)",
                  background: tab.disabled
                    ? "var(--bg-disabled)"
                    : activeTab === tab.id
                    ? "var(--accent)"
                    : "var(--bg-disabled)",
                  color: tab.disabled
                    ? "var(--text-faded)"
                    : activeTab === tab.id
                    ? "var(--text-on-accent)"
                    : "var(--text-secondary)",
                  fontWeight: activeTab === tab.id ? 700 : 400,
                  cursor: tab.disabled ? "not-allowed" : "pointer",
                  borderRadius: isFirst
                    ? "8px 0 0 8px"
                    : isLast
                    ? "0 8px 8px 0"
                    : "0",
                }}
              >
                {tab.label}
              </button>
            );
          })}
          <button
            className="theme-toggle"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            style={{ marginLeft: "auto" }}
            title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          >
            {theme === "dark" ? "\u2600\uFE0F" : "\uD83C\uDF19"}
          </button>
        </div>

        {activeTab === "execution" && <ExecutionTab />}
        {activeTab === "blotter" && <TradeBlotter />}
        {activeTab === "signals" && <SignalsTable />}
        {activeTab === "risk" && <RiskTab />}
        {activeTab === "slippage" && <SlippageTab />}
      </div>
    </SignalDataProvider>
  );
}
