import { useState, useEffect, useMemo } from "react";
import {
  LineChart, AreaChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";

const BASE_URL = "";

function maxDrawdown(curve) {
  let peak = -Infinity, maxDD = 0;
  for (const pt of curve) {
    peak = Math.max(peak, pt.cumulative_pnl);
    maxDD = Math.min(maxDD, pt.cumulative_pnl - peak);
  }
  return maxDD;
}

export default function RiskTab() {
  const [allCurves, setAllCurves] = useState({});
  const [portfolio, setPortfolio] = useState([]);
  const [combos, setCombos] = useState([]);
  const [fees, setFees] = useState({});
  const [realized, setRealized] = useState({});
  const [unrealized, setUnrealized] = useState({});
  const [winRate, setWinRate] = useState({});
  const [selected, setSelected] = useState(new Set(["Portfolio"]));
  const [loading, setLoading] = useState(false);

  useEffect(() => { fetchAll(); }, []);

  async function fetchAll() {
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/risk/all`);
      const data = await res.json();
      setAllCurves(data.curves || {});
      setPortfolio(data.portfolio || []);
      setCombos(data.available_combos || []);
      setFees(data.fees || {});
      setRealized(data.realized || {});
      setUnrealized(data.unrealized || {});
      setWinRate(data.win_rate || {});
    } catch (e) { console.error("Failed to fetch risk data", e); }
    setLoading(false);
  }

  function toggleSelection(label) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (label === "Portfolio") {
        if (next.has("Portfolio")) next.delete("Portfolio"); else { next.clear(); next.add("Portfolio"); }
      } else {
        next.delete("Portfolio");
        if (next.has(label)) next.delete(label); else next.add(label);
        if (next.size === 0) next.add("Portfolio");
      }
      return next;
    });
  }

  const grouped = useMemo(() => {
    const map = {};
    for (const c of combos) { const [product, strategy] = c.split(" / "); if (!map[product]) map[product] = []; map[product].push({ label: c, strategy }); }
    return map;
  }, [combos]);

  const curve = useMemo(() => {
    if (selected.has("Portfolio")) return portfolio;
    const selectedCurves = [];
    for (const label of selected) { if (allCurves[label]) selectedCurves.push(allCurves[label]); }
    if (selectedCurves.length === 0) return [];
    if (selectedCurves.length === 1) return selectedCurves[0];
    const byDate = {};
    for (const c of selectedCurves) for (const pt of c) { if (!byDate[pt.date]) byDate[pt.date] = 0; byDate[pt.date] += pt.daily_pnl; }
    const dates = Object.keys(byDate).sort();
    let cumulative = 0;
    return dates.map((d) => { cumulative += byDate[d]; return { date: d, daily_pnl: Math.round(byDate[d] * 100) / 100, cumulative_pnl: Math.round(cumulative * 100) / 100 }; });
  }, [selected, allCurves, portfolio]);

  const lastPnl = curve.length > 0 ? curve[curve.length - 1].cumulative_pnl : 0;
  const dd = useMemo(() => maxDrawdown(curve), [curve]);
  const ddSeries = useMemo(() => {
    let peak = -Infinity;
    return curve.map((pt) => { peak = Math.max(peak, pt.cumulative_pnl); return { date: pt.date, drawdown: Math.round((pt.cumulative_pnl - peak) * 100) / 100 }; });
  }, [curve]);

  const sumForSelected = (dict) => { if (selected.has("Portfolio")) return dict["Portfolio"] || 0; let sum = 0; for (const label of selected) sum += dict[label] || 0; return sum; };
  const totalFees = useMemo(() => sumForSelected(fees), [selected, fees]);
  const totalRealized = useMemo(() => sumForSelected(realized), [selected, realized]);
  const totalUnrealized = useMemo(() => sumForSelected(unrealized), [selected, unrealized]);

  const selectedWinRate = useMemo(() => {
    if (selected.has("Portfolio")) return winRate["Portfolio"] ?? null;
    const labels = [...selected];
    if (labels.length === 1) return winRate[labels[0]] ?? null;
    const rates = labels.map((l) => winRate[l]).filter((r) => r != null);
    if (rates.length === 0) return null;
    return Math.round((rates.reduce((a, b) => a + b, 0) / rates.length) * 10) / 10;
  }, [selected, winRate]);

  const selectionLabel = selected.has("Portfolio") ? "Portfolio" : [...selected].join(" + ");
  const formatNum = (v) => v != null ? v.toLocaleString("en-US", { maximumFractionDigits: 0 }) : "";

  return (
    <div>
      {/* Chip selector */}
      <div style={{ maxWidth: 920, margin: "0 auto 10px" }}>
        <div style={{ marginBottom: 6 }}>
          <Chip label="Portfolio" active={selected.has("Portfolio")} onClick={() => toggleSelection("Portfolio")} />
          {loading && <span style={{ color: "var(--text-faded)", fontSize: 11, marginLeft: 8 }}>Loading...</span>}
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center" }}>
          {Object.entries(grouped).map(([product, items]) => (
            <div key={product} style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <span style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 600 }}>{product}</span>
              {items.map((item) => <Chip key={item.label} label={item.strategy} active={selected.has(item.label)} onClick={() => toggleSelection(item.label)} />)}
            </div>
          ))}
        </div>
      </div>

      {/* Chart card */}
      <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 8, padding: "16px 20px", maxWidth: 920, margin: "0 auto" }}>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>{selectionLabel}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8, marginBottom: 12 }}>
          <StatBox label="Realized PnL" value={totalRealized} color={totalRealized >= 0 ? "var(--sig-long)" : "var(--sig-short)"} formatNum={formatNum} />
          <StatBox label="Unrealized PnL" value={totalUnrealized} color={totalUnrealized >= 0 ? "var(--sig-long)" : "var(--sig-short)"} formatNum={formatNum} />
          <StatBox label="Cumulative PnL" value={lastPnl} color={lastPnl >= 0 ? "var(--sig-long)" : "var(--sig-short)"} formatNum={formatNum} />
          <StatBox label="Max Drawdown" value={dd} color={dd < 0 ? "var(--sig-short)" : "var(--text-secondary)"} formatNum={formatNum} />
          <StatBox label="Total Fees" value={totalFees} color="var(--text-secondary)" formatNum={formatNum} />
          <StatBox label="Win Rate" value={selectedWinRate}
            color={selectedWinRate == null ? "var(--text-faded)" : selectedWinRate >= 55 ? "var(--sig-long)" : selectedWinRate >= 45 ? "var(--sig-warn)" : "var(--sig-short)"}
            formatNum={(v) => v != null ? `${v.toFixed(1)}%` : "—"} />
        </div>

        {curve.length > 0 ? (
          <>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={curve} margin={{ top: 4, right: 12, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--chart-grid)" />
                <XAxis dataKey="date" hide />
                <YAxis tick={{ fontSize: 11, fill: "var(--text-muted)" }} tickFormatter={formatNum} width={65} />
                <Tooltip formatter={(v) => [formatNum(v), "Cumulative PnL"]} labelFormatter={(d) => d} />
                <ReferenceLine y={0} stroke="var(--chart-ref)" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="cumulative_pnl" stroke="var(--chart-line)" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
            <ResponsiveContainer width="100%" height={80}>
              <AreaChart data={ddSeries} margin={{ top: 0, right: 12, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="ddFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--sig-short)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="var(--sig-short)" stopOpacity={0.08} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: "var(--text-muted)" }} tickFormatter={(d) => { const parts = d.split("-"); return `${parts[1]}/${parts[2]}`; }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis tick={{ fontSize: 10, fill: "var(--text-muted)" }} tickFormatter={formatNum} width={65} />
                <Tooltip formatter={(v) => [formatNum(v), "Drawdown"]} labelFormatter={(d) => d} />
                <ReferenceLine y={0} stroke="var(--chart-ref)" strokeDasharray="3 3" />
                <Area type="monotone" dataKey="drawdown" stroke="var(--sig-short)" strokeWidth={1} fill="url(#ddFill)" dot={false} activeDot={{ r: 3 }} />
              </AreaChart>
            </ResponsiveContainer>
          </>
        ) : (
          <div style={{ color: "var(--text-faded)", padding: 40, textAlign: "center" }}>No data available</div>
        )}
      </div>
    </div>
  );
}

function StatBox({ label, value, color, formatNum }) {
  return (
    <div style={{ border: "1px solid var(--border)", borderRadius: 6, padding: "6px 10px", textAlign: "center" }}>
      <div style={{ fontSize: 10, color: "var(--text-muted)", marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 700, color }}>{formatNum(value)}</div>
    </div>
  );
}

function Chip({ label, active, onClick }) {
  return (
    <button onClick={onClick}
      style={{
        padding: "3px 9px", borderRadius: 12,
        border: active ? "1.5px solid var(--accent)" : "1px solid var(--border-button)",
        background: active ? "var(--accent)" : "var(--bg-card)",
        color: active ? "var(--text-on-accent)" : "var(--text-secondary)",
        fontSize: 11, fontWeight: active ? 600 : 400, cursor: "pointer", whiteSpace: "nowrap", lineHeight: "16px",
      }}>
      {label}
    </button>
  );
}
