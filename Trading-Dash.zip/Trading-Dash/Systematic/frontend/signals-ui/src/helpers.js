export const signClass = (v) => (v === 1 ? "sig sig-pos" : v === -1 ? "sig sig-neg" : "");

export function formatTimestampNoTZ(value) {
  if (!value) return "";
  return value.slice(0, 19);
}

export function formatLondonNoTZ(value) {
  if (!value) return "";
  // Backend stores UTC but pymongo returns naive datetimes (no Z suffix).
  // Append Z so JS parses as UTC, not local time.
  const iso = typeof value === "string" && !value.endsWith("Z") && !value.includes("+") ? value + "Z" : value;
  return new Date(iso)
    .toLocaleString("en-GB", {
      timeZone: "Europe/London",
      hour12: false,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
    .replace(",", "");
}

export function dateStrLondon(value) {
  if (!value) return "";
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/London",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date(value));

  const y = parts.find((p) => p.type === "year")?.value;
  const m = parts.find((p) => p.type === "month")?.value;
  const d = parts.find((p) => p.type === "day")?.value;
  return `${y}-${m}-${d}`;
}

export function londonNow() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/London",
    hour: "2-digit",
    minute: "2-digit",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const get = (type) => parseInt(parts.find((p) => p.type === type)?.value, 10);
  return {
    hour: get("hour"),
    minute: get("minute"),
    dateStr: `${get("year")}-${get("month")}-${get("day")}`,
  };
}
