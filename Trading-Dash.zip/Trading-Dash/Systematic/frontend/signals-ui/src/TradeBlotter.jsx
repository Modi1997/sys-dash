import React, { useState, useEffect } from "react";
import { useSignalData } from "./SignalDataContext";
import { suggestContract } from "./constants";

const API = "/api/trades";

const PRODUCTS = ["brtdub1", "35brgcrk1", "c3lst1", "dubspr1", "ebobcrk1", "sg380crk1", "sg05crk1"];
const STRATEGIES = ["DC Normal", "DC Trailing", "DC Continuous", "ACF MA"];
const TRADE_TYPES = ["Internal", "Broker", "Screen"];
const PAGE_SIZE = 10;

const HOURS = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));

const EMPTY_FORM = {
  entry_date: "",
  entry_hour: "08",
  product: PRODUCTS[0],
  signal: "long",
  strategy: STRATEGIES[0],
  entry_type: TRADE_TYPES[0],
  size: "",
  entry_price: "",
  entry_spread: "",
  entry_fees: "",
  comment: "",
  contract: "",
};

function formatDate(val) {
  if (!val) return "";
  return new Date(val).toLocaleString("en-GB", {
    timeZone: "Europe/London",
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", hour12: false,
  }).replace(",", "");
}

export default function TradeBlotter() {
  const { refreshTrades } = useSignalData();
  const [openTrades, setOpenTrades] = useState([]);
  const [closedTrades, setClosedTrades] = useState([]);
  const [totalClosed, setTotalClosed] = useState(0);
  const [form, setForm] = useState(EMPTY_FORM);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState("");

  const [closingId, setClosingId] = useState(null);
  const [closeForm, setCloseForm] = useState({ exit_date: "", exit_hour: "08", exit_price: "", exit_type: TRADE_TYPES[0], exit_spread: "", exit_fees: "", close_size: "" });

  const [histPage, setHistPage] = useState(0);
  const [groupView, setGroupView] = useState(false);
  const [groupedTrades, setGroupedTrades] = useState([]);
  const [expandedGroups, setExpandedGroups] = useState(new Set());

  async function fetchOpen() {
    const res = await fetch(`${API}?status=open`);
    setOpenTrades(await res.json());
  }

  async function fetchClosed(page = 0) {
    const skip = page * PAGE_SIZE;
    const res = await fetch(`${API}?status=closed&skip=${skip}&limit=${PAGE_SIZE}`);
    const data = await res.json();
    setClosedTrades(data.trades);
    setTotalClosed(data.total);
  }

  async function fetchGroups() {
    const res = await fetch(`${API}/groups?status=closed`);
    setGroupedTrades(await res.json());
  }

  async function fetchTrades() {
    setLoading(true);
    setError("");
    try {
      const tasks = [fetchOpen(), fetchClosed(histPage)];
      if (groupView) tasks.push(fetchGroups());
      await Promise.all(tasks);
      refreshTrades();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function toggleGroupExpand(gid) {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(gid)) next.delete(gid); else next.add(gid);
      return next;
    });
  }

  useEffect(() => { fetchTrades(); }, []);

  useEffect(() => { fetchClosed(histPage); }, [histPage]);

  useEffect(() => { if (groupView) fetchGroups(); }, [groupView]);

  async function handleAdd(e) {
    e.preventDefault();
    setError("");
    const body = {
      ...form,
      entry_date: new Date(`${form.entry_date}T${form.entry_hour}:00:00`).toISOString(),
      size: parseFloat(form.size),
      entry_price: parseFloat(form.entry_price),
      entry_spread: form.entry_spread ? parseFloat(form.entry_spread) : null,
      entry_fees: form.entry_fees ? parseFloat(form.entry_fees) : null,
      contract: form.contract || suggestContract(form.product),
    };
    try {
      const res = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (!res.ok) { const resBody = await res.text(); setError(`POST failed (${res.status}): ${resBody}`); return; }
      setForm(EMPTY_FORM);
      fetchTrades();
    } catch (err) { setError(`Network error: ${err.message}`); }
  }

  function startEdit(id, field, currentValue) {
    setEditingCell({ id, field });
    setEditValue(currentValue ?? "");
  }

  async function saveEdit(id, field) {
    const numFields = ["size", "entry_price", "exit_price", "entry_spread", "exit_spread", "entry_fees", "exit_fees"];
    let value = editValue;
    if (numFields.includes(field)) { value = value === "" ? null : parseFloat(value); }
    else if (field === "entry_date" || field === "exit_date") { value = new Date(value).toISOString(); }
    await fetch(`${API}/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ [field]: value }) });
    setEditingCell(null);
    fetchTrades();
  }

  async function handleClose(trade) {
    const exitBody = {
      exit_date: new Date(`${closeForm.exit_date}T${closeForm.exit_hour}:00:00`).toISOString(),
      exit_price: parseFloat(closeForm.exit_price),
      exit_type: closeForm.exit_type,
      exit_spread: closeForm.exit_spread ? parseFloat(closeForm.exit_spread) : null,
      exit_fees: closeForm.exit_fees ? parseFloat(closeForm.exit_fees) : null,
    };
    const closeSize = closeForm.close_size ? parseFloat(closeForm.close_size) : trade.size;
    const isPartial = closeSize < trade.size;
    if (isPartial) {
      const originalFees = trade.entry_fees || 0;
      const closedFees = Math.round((originalFees * closeSize / trade.size) * 100) / 100;
      const remainderFees = Math.round((originalFees - closedFees) * 100) / 100;
      exitBody.size = closeSize;
      exitBody.entry_fees = closedFees;
      await fetch(`${API}/${trade._id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(exitBody) });
      const remainder = { entry_date: trade.entry_date, product: trade.product, signal: trade.signal, strategy: trade.strategy, entry_type: trade.entry_type, size: trade.size - closeSize, entry_price: trade.entry_price, contract: trade.contract, entry_spread: trade.entry_spread, entry_fees: remainderFees, exit_fees: trade.exit_fees, comment: trade.comment, group_id: trade.group_id };
      await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(remainder) });
    } else {
      await fetch(`${API}/${trade._id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(exitBody) });
    }
    setClosingId(null);
    setCloseForm({ exit_date: "", exit_hour: "08", exit_price: "", exit_type: TRADE_TYPES[0], exit_spread: "", exit_fees: "", close_size: "" });
    fetchTrades();
  }

  async function handleDelete(id) {
    await fetch(`${API}/${id}`, { method: "DELETE" });
    fetchTrades();
  }

  function EditableCell({ trade, field, display }) {
    const isEditing = editingCell?.id === trade._id && editingCell?.field === field;
    if (isEditing) {
      return (
        <input autoFocus value={editValue} onChange={(e) => setEditValue(e.target.value)}
          onBlur={() => saveEdit(trade._id, field)} onKeyDown={(e) => e.key === "Enter" && saveEdit(trade._id, field)}
          style={{ width: "100%", padding: 2, fontSize: 12, background: "var(--bg-yellow-edit)", border: "1px solid var(--bg-yellow-border)", color: "var(--text-primary)" }} />
      );
    }
    return (
      <span onDoubleClick={() => startEdit(trade._id, field, trade[field])} style={{ cursor: "pointer" }} title="Double-click to edit">
        {display ?? trade[field] ?? ""}
      </span>
    );
  }

  const pnlStyle = (v) => {
    if (v == null) return {};
    return { color: v > 0 ? "var(--pnl-pos)" : v < 0 ? "var(--pnl-neg)" : "var(--sig-neutral)", fontWeight: 600 };
  };

  const totalHistPages = Math.max(1, Math.ceil(totalClosed / PAGE_SIZE));

  const inputStyle = { display: "block", padding: 4 };
  const btnStyle = { padding: "4px 10px", borderRadius: 4, border: "1px solid var(--border-button)", cursor: "pointer", color: "var(--text-primary)", background: "var(--bg-card)" };

  return (
    <div style={{ padding: 16 }}>
      <h2 style={{ margin: "0 0 16px" }}>Trade Blotter</h2>

      {error && <div style={{ color: "var(--text-error)", marginBottom: 8 }}>{error}</div>}

      {/* --- ADD TRADE FORM --- */}
      <form onSubmit={handleAdd} style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 20, alignItems: "end" }}>
        <label style={{ fontSize: 12 }}>Entry Date<input type="date" required value={form.entry_date} onChange={(e) => setForm({ ...form, entry_date: e.target.value })} style={inputStyle} /></label>
        <label style={{ fontSize: 12 }}>Hour<select value={form.entry_hour} onChange={(e) => setForm({ ...form, entry_hour: e.target.value })} style={inputStyle}>{HOURS.map((h) => <option key={h} value={h}>{h}:00</option>)}</select></label>
        <label style={{ fontSize: 12 }}>Product<select value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })} style={inputStyle}>{PRODUCTS.map((p) => <option key={p} value={p}>{p}</option>)}</select></label>
        <label style={{ fontSize: 12 }}>Signal<select value={form.signal} onChange={(e) => setForm({ ...form, signal: e.target.value })} style={inputStyle}><option value="long">Long</option><option value="short">Short</option></select></label>
        <label style={{ fontSize: 12 }}>Strategy<select value={form.strategy} onChange={(e) => setForm({ ...form, strategy: e.target.value })} style={inputStyle}>{STRATEGIES.map((s) => <option key={s} value={s}>{s}</option>)}</select></label>
        <label style={{ fontSize: 12 }}>Entry Type<select value={form.entry_type} onChange={(e) => setForm({ ...form, entry_type: e.target.value })} style={inputStyle}>{TRADE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}</select></label>
        <label style={{ fontSize: 12 }}>Size in KB<input type="number" step="any" required value={form.size} onChange={(e) => setForm({ ...form, size: e.target.value })} style={{ ...inputStyle, width: 70 }} /></label>
        <label style={{ fontSize: 12 }}>Entry Price<input type="number" step="any" required value={form.entry_price} onChange={(e) => setForm({ ...form, entry_price: e.target.value })} style={{ ...inputStyle, width: 90 }} /></label>
        <label style={{ fontSize: 12 }}>Entry Spread<input type="number" step="any" value={form.entry_spread} onChange={(e) => setForm({ ...form, entry_spread: e.target.value })} style={{ ...inputStyle, width: 80 }} /></label>
        <label style={{ fontSize: 12 }}>Entry Fees<input type="number" step="any" value={form.entry_fees} onChange={(e) => setForm({ ...form, entry_fees: e.target.value })} style={{ ...inputStyle, width: 80 }} /></label>
        <label style={{ fontSize: 12 }}>Comment<input type="text" value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} style={{ ...inputStyle, width: 140 }} /></label>
        <label style={{ fontSize: 12 }}>Contract<input type="text" value={form.contract || suggestContract(form.product)} onChange={(e) => setForm({ ...form, contract: e.target.value.toUpperCase() })} style={{ ...inputStyle, width: 70, fontWeight: 700 }} placeholder="e.g. H26" /></label>
        <button type="submit" style={{ padding: "6px 16px", fontWeight: 600, borderRadius: 6, border: "1px solid var(--border-button)", background: "var(--bg-green-button)", cursor: "pointer", color: "var(--text-primary)" }}>Add Trade</button>
      </form>

      {/* --- OPEN TRADES --- */}
      <h3 style={{ margin: "12px 0 8px" }}>Open Trades</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, overflowX: "auto" }}>
        <table className="dataTable">
          <thead><tr><th>Entry Date</th><th>Product</th><th>Signal</th><th>Strategy</th><th>Size in KB</th><th>Entry Price</th><th>Entry Spread</th><th>Entry Fees</th><th>Comment</th><th>Contract</th><th>Actions</th></tr></thead>
          <tbody>
            {openTrades.length === 0 ? (
              <tr><td colSpan={11}>No open trades</td></tr>
            ) : openTrades.map((t) => (
              <React.Fragment key={t._id}>
                <tr>
                  <td><EditableCell trade={t} field="entry_date" display={formatDate(t.entry_date)} /></td>
                  <td><EditableCell trade={t} field="product" /></td>
                  <td><EditableCell trade={t} field="signal" /></td>
                  <td><EditableCell trade={t} field="strategy" /></td>
                  <td><EditableCell trade={t} field="size" /></td>
                  <td><EditableCell trade={t} field="entry_price" /></td>
                  <td><EditableCell trade={t} field="entry_spread" /></td>
                  <td><EditableCell trade={t} field="entry_fees" /></td>
                  <td><EditableCell trade={t} field="comment" /></td>
                  <td style={{ fontWeight: 700 }}><EditableCell trade={t} field="contract" /></td>
                  <td style={{ whiteSpace: "nowrap" }}>
                    <button onClick={() => { setClosingId(closingId === t._id ? null : t._id); if (closingId !== t._id) setCloseForm((f) => ({ ...f, close_size: String(t.size) })); }}
                      style={{ fontSize: 11, padding: "2px 8px", background: "var(--bg-orange-tint)", border: "1px solid var(--border-input)", borderRadius: 4, cursor: "pointer", marginRight: 4, color: "var(--text-primary)" }}>Close</button>
                    <button onClick={() => handleDelete(t._id)}
                      style={{ fontSize: 11, padding: "2px 8px", background: "var(--bg-red-tint)", border: "1px solid var(--border-input)", borderRadius: 4, cursor: "pointer", color: "var(--text-primary)" }}>Delete</button>
                  </td>
                </tr>
                {closingId === t._id && (
                  <tr style={{ background: "var(--bg-yellow-row)" }}>
                    <td colSpan={11}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                        <label style={{ fontSize: 11 }}>Exit Date <input type="date" value={closeForm.exit_date} onChange={(e) => setCloseForm({ ...closeForm, exit_date: e.target.value })} style={{ padding: 2, fontSize: 11 }} /></label>
                        <label style={{ fontSize: 11 }}>Hour <select value={closeForm.exit_hour} onChange={(e) => setCloseForm({ ...closeForm, exit_hour: e.target.value })} style={{ padding: 2, fontSize: 11 }}>{HOURS.map((h) => <option key={h} value={h}>{h}:00</option>)}</select></label>
                        <label style={{ fontSize: 11 }}>Exit Price <input type="number" step="any" value={closeForm.exit_price} onChange={(e) => setCloseForm({ ...closeForm, exit_price: e.target.value })} style={{ padding: 2, fontSize: 11, width: 80 }} /></label>
                        <label style={{ fontSize: 11 }}>Exit Type <select value={closeForm.exit_type} onChange={(e) => setCloseForm({ ...closeForm, exit_type: e.target.value })} style={{ padding: 2, fontSize: 11 }}>{TRADE_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}</select></label>
                        <label style={{ fontSize: 11 }}>Exit Spread <input type="number" step="any" value={closeForm.exit_spread} onChange={(e) => setCloseForm({ ...closeForm, exit_spread: e.target.value })} style={{ padding: 2, fontSize: 11, width: 70 }} /></label>
                        <label style={{ fontSize: 11 }}>Exit Fees <input type="number" step="any" value={closeForm.exit_fees} onChange={(e) => setCloseForm({ ...closeForm, exit_fees: e.target.value })} style={{ padding: 2, fontSize: 11, width: 70 }} /></label>
                        <label style={{ fontSize: 11 }}>Close Size <input type="number" step="any" value={closeForm.close_size} onChange={(e) => setCloseForm({ ...closeForm, close_size: e.target.value })} style={{ padding: 2, fontSize: 11, width: 70, fontWeight: 700 }} /></label>
                        <button onClick={() => handleClose(t)} style={{ fontSize: 11, padding: "2px 10px", background: "var(--bg-green-button)", border: "1px solid var(--border-input)", borderRadius: 4, cursor: "pointer", color: "var(--text-primary)" }}>Confirm</button>
                        <button onClick={() => setClosingId(null)} style={{ fontSize: 11, padding: "2px 10px", border: "1px solid var(--border-input)", borderRadius: 4, cursor: "pointer", color: "var(--text-primary)", background: "var(--bg-card)" }}>Cancel</button>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* --- HISTORICAL TRADES --- */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "20px 0 8px" }}>
        <h3 style={{ margin: 0 }}>Historical Trades</h3>
        <label style={{ fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
          <input type="checkbox" checked={groupView} onChange={(e) => setGroupView(e.target.checked)} />
          Group split fills
        </label>
      </div>

      {!groupView ? (
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, overflowX: "auto" }}>
        <table className="dataTable">
          <thead><tr><th>Entry Date</th><th>Exit Date</th><th>Product</th><th>Strategy</th><th>Size in KB</th><th>Entry Price</th><th>Exit Price</th><th>Total Spread</th><th>Entry Fees</th><th>Exit Fees</th><th>P&L</th></tr></thead>
          <tbody>
            {closedTrades.length === 0 ? (
              <tr><td colSpan={11}>No closed trades</td></tr>
            ) : closedTrades.map((t) => (
              <tr key={t._id}>
                <td><EditableCell trade={t} field="entry_date" display={formatDate(t.entry_date)} /></td>
                <td><EditableCell trade={t} field="exit_date" display={formatDate(t.exit_date)} /></td>
                <td><EditableCell trade={t} field="product" /></td>
                <td><EditableCell trade={t} field="strategy" /></td>
                <td><EditableCell trade={t} field="size" /></td>
                <td><EditableCell trade={t} field="entry_price" /></td>
                <td><EditableCell trade={t} field="exit_price" /></td>
                <td><EditableCell trade={t} field="total_spread" /></td>
                <td><EditableCell trade={t} field="entry_fees" /></td>
                <td><EditableCell trade={t} field="exit_fees" /></td>
                <td style={pnlStyle(t.pnl)}>{t.pnl != null ? t.pnl.toFixed(2) : ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      ) : (
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12, overflowX: "auto" }}>
        <table className="dataTable">
          <thead><tr><th></th><th>Entry Date</th><th>Product</th><th>Strategy</th><th>Total Size</th><th>Entry Price</th><th>Avg Exit Price</th><th>Entry Spread</th><th>Avg Exit Spread</th><th>Fills</th><th>Total P&L</th></tr></thead>
          <tbody>
            {groupedTrades.length === 0 ? (
              <tr><td colSpan={11}>No grouped trades</td></tr>
            ) : groupedTrades.map((g) => {
              const isExpanded = expandedGroups.has(g.group_id);
              const canExpand = g.n_fills > 1;
              return (
                <React.Fragment key={g.group_id}>
                  <tr style={{ cursor: canExpand ? "pointer" : "default" }} onClick={() => canExpand && toggleGroupExpand(g.group_id)}>
                    <td style={{ width: 24, textAlign: "center", color: "var(--text-muted)" }}>{canExpand ? (isExpanded ? "\u25BC" : "\u25B6") : ""}</td>
                    <td>{formatDate(g.entry_date)}</td>
                    <td>{g.product}</td>
                    <td>{g.strategy}</td>
                    <td>{g.total_size}</td>
                    <td>{g.entry_price}</td>
                    <td>{g.avg_exit_price ?? ""}</td>
                    <td>{g.entry_spread ?? ""}</td>
                    <td>{g.avg_exit_spread ?? ""}</td>
                    <td style={{ fontSize: 11, color: "var(--text-muted)" }}>{g.n_fills}</td>
                    <td style={pnlStyle(g.total_pnl)}>{g.total_pnl != null ? g.total_pnl.toFixed(2) : ""}</td>
                  </tr>
                  {isExpanded && g.fills.map((f) => (
                    <tr key={f._id} style={{ background: "var(--bg-disabled)", fontSize: 11 }}>
                      <td></td>
                      <td>{formatDate(f.exit_date) || "\u2014"}</td>
                      <td colSpan={2} style={{ color: "var(--text-muted)", fontStyle: "italic" }}>fill</td>
                      <td>{f.size}</td>
                      <td></td>
                      <td>{f.exit_price ?? ""}</td>
                      <td></td>
                      <td>{f.exit_spread ?? ""}</td>
                      <td></td>
                      <td style={pnlStyle(f.pnl)}>{f.pnl != null ? f.pnl.toFixed(2) : ""}</td>
                    </tr>
                  ))}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
      )}
      {!groupView && totalHistPages > 1 && (
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 8 }}>
          <button disabled={histPage === 0} onClick={() => setHistPage(histPage - 1)} style={{ ...btnStyle, cursor: histPage === 0 ? "default" : "pointer" }}>Prev</button>
          <span style={{ fontSize: 12 }}>Page {histPage + 1} of {totalHistPages}</span>
          <button disabled={histPage >= totalHistPages - 1} onClick={() => setHistPage(histPage + 1)} style={{ ...btnStyle, cursor: histPage >= totalHistPages - 1 ? "default" : "pointer" }}>Next</button>
        </div>
      )}

      <button onClick={fetchTrades} disabled={loading} style={{ marginTop: 16, padding: "8px 12px", borderRadius: 8, border: "1px solid var(--border-button)", cursor: "pointer", color: "var(--text-primary)", background: "var(--bg-card)" }}>
        {loading ? "Refreshing..." : "Refresh"}
      </button>
    </div>
  );
}
