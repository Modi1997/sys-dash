import React, { createContext, useContext, useState, useEffect, useCallback } from "react";

const BASE_URL = "";
const URL_WINDOWS = `${BASE_URL}/api/systematic-signals/latest`;
const URL_SIG_LATEST = `${BASE_URL}/api/systematic-signals/sig-latest`;
const URL_OPEN_TRADES = `${BASE_URL}/api/trades?status=open`;

const SignalDataContext = createContext(null);

export function useSignalData() {
  const ctx = useContext(SignalDataContext);
  if (!ctx) throw new Error("useSignalData must be used within SignalDataProvider");
  return ctx;
}

export function SignalDataProvider({ children }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [windowsData, setWindowsData] = useState(null);
  const [sigLatestData, setSigLatestData] = useState(null);
  const [openTrades, setOpenTrades] = useState([]);
  const [lastRefreshed, setLastRefreshed] = useState(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [wRes, sRes, tRes] = await Promise.all([
        fetch(URL_WINDOWS, { cache: "no-store" }),
        fetch(URL_SIG_LATEST, { cache: "no-store" }),
        fetch(URL_OPEN_TRADES, { cache: "no-store" }),
      ]);

      if (!wRes.ok) throw new Error(`Windows fetch failed: ${wRes.status} ${wRes.statusText}`);
      if (!sRes.ok) throw new Error(`Sig-latest fetch failed: ${sRes.status} ${sRes.statusText}`);
      if (!tRes.ok) throw new Error(`Open trades fetch failed: ${tRes.status} ${tRes.statusText}`);

      const [wJson, sJson, tJson] = await Promise.all([wRes.json(), sRes.json(), tRes.json()]);
      setWindowsData(wJson);
      setSigLatestData(sJson);
      setOpenTrades(tJson);
      setLastRefreshed(new Date().toLocaleString("en-GB", { timeZone: "Europe/London", hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).replace(",", ""));
    } catch (e) {
      setError(e?.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  }, []);

  // Lightweight refresh — only fetches open trades (fast)
  const refreshTrades = useCallback(async () => {
    try {
      const res = await fetch(URL_OPEN_TRADES, { cache: "no-store" });
      if (res.ok) setOpenTrades(await res.json());
    } catch (_) { /* silent */ }
  }, []);

  // Initial fetch
  useEffect(() => {
    refresh();
  }, [refresh]);

  return (
    <SignalDataContext.Provider value={{ windowsData, sigLatestData, openTrades, loading, error, refresh, refreshTrades, lastRefreshed }}>
      {children}
    </SignalDataContext.Provider>
  );
}
