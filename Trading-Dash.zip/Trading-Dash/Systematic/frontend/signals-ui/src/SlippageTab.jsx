import { useState, useEffect, useMemo } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ReferenceLine,
} from "recharts";

const BASE_URL = "";

const PRODUCT_COLORS = {
  brtdub:   "#2196F3",
  dubspr:   "#4CAF50",
  ebobcrk:  "#FF9800",
  "35brgcrk": "#9C27B0",
  sg380crk: "#F44336",
  sg05crk:  "#00BCD4",
  lstfp:    "#795548",
};


function fmt(v) {
  if (v == null) return "";
  return Number(v).toFixed(2);
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border-light)", borderRadius: 8, padding: "8px 12px", fontSize: 12 }}>
      <div style={{ fontWeight: 700, marginBottom: 4 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ color: p.color }}>
          {p.name}: {fmt(p.value)}
        </div>
      ))}
    </div>
  );
}

export default function SlippageTab() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState("all"); // "all" | "product"
  const [chartMode, setChartMode] = useState("cumulative"); // "cumulative" | "daily"
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    setLoading(true);
    fetch(`${BASE_URL}/api/slippage`)
      .then((r) => r.json())
      .then((d) => setData(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const products = useMemo(() => data ? Object.keys(data.by_product) : [], [data]);

  // Select chart data based on view
  const chartData = useMemo(() => {
    if (!data) return [];
    if (view === "product" && selectedProduct) return data.by_product[selectedProduct] || [];
    return data.all;
  }, [data, view, selectedProduct]);

  const chartTitle = useMemo(() => {
    if (view === "product" && selectedProduct) return `Cumulative Spread — ${selectedProduct}`;
    return "Cumulative Spread — All";
  }, [view, selectedProduct]);

  if (loading) return <div style={{ padding: 16 }}>Loading slippage data...</div>;
  if (!data) return <div style={{ padding: 16 }}>No data available</div>;

  const summary = data.summary;

  return (
    <div style={{ padding: 16 }}>
      {/* SUMMARY CARDS */}
      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
        <div className="action-card" style={{ minWidth: 160, borderLeft: "4px solid var(--sig-neutral)" }}>
          <div style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 600 }}>Model Spread</div>
          <div style={{ fontSize: 20, fontWeight: 700 }}>{fmt(summary.total_model)}</div>
        </div>
        <div className="action-card" style={{ minWidth: 160, borderLeft: "4px solid var(--sig-warn)" }}>
          <div style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 600 }}>Actual Spread</div>
          <div style={{ fontSize: 20, fontWeight: 700 }}>{fmt(summary.total_actual)}</div>
        </div>
        <div className="action-card" style={{ minWidth: 160, borderLeft: `4px solid ${summary.total_slippage > 0 ? "var(--sig-short)" : "var(--sig-long)"}` }}>
          <div style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 600 }}>Total Slippage</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: summary.total_slippage > 0 ? "var(--sig-short)" : "var(--sig-long)" }}>
            {summary.total_slippage > 0 ? "+" : ""}{fmt(summary.total_slippage)}
          </div>
        </div>
      </div>

      {/* VIEW SELECTOR */}
      <div style={{ display: "flex", gap: 0, marginBottom: 16, alignItems: "center" }}>
        {["all", "product"].map((v, i) => (
          <button key={v} onClick={() => setView(v)}
            style={{
              padding: "6px 16px", border: "1px solid var(--border-button)",
              background: view === v ? "var(--accent)" : "var(--bg-disabled)",
              color: view === v ? "var(--text-on-accent)" : "var(--text-secondary)",
              fontWeight: view === v ? 700 : 400, cursor: "pointer", fontSize: 12,
              borderRadius: i === 0 ? "8px 0 0 8px" : "0 8px 8px 0",
            }}
          >
            {v === "all" ? "All" : "By Product"}
          </button>
        ))}

        {view === "product" && (
          <div style={{ display: "flex", gap: 4, marginLeft: 12 }}>
            {products.map((p) => (
              <button key={p} onClick={() => setSelectedProduct(p)}
                style={{
                  padding: "4px 10px", borderRadius: 8, border: "1px solid var(--border-button)",
                  background: selectedProduct === p ? (PRODUCT_COLORS[p] || "var(--accent)") : "var(--bg-card)",
                  color: selectedProduct === p ? "#fff" : "var(--text-primary)",
                  fontSize: 11, fontWeight: 600, cursor: "pointer",
                }}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* CHART */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
        <h3 className="exec-section-header" style={{ margin: 0 }}>{chartTitle}</h3>
        <div style={{ display: "flex", gap: 0, marginLeft: "auto" }}>
          {["cumulative", "daily"].map((m, i) => (
            <button key={m} onClick={() => setChartMode(m)}
              style={{
                padding: "4px 12px", border: "1px solid var(--border-button)",
                background: chartMode === m ? "var(--accent)" : "var(--bg-disabled)",
                color: chartMode === m ? "var(--text-on-accent)" : "var(--text-secondary)",
                fontWeight: chartMode === m ? 700 : 400, cursor: "pointer", fontSize: 11,
                borderRadius: i === 0 ? "6px 0 0 6px" : "0 6px 6px 0",
              }}
            >
              {m === "cumulative" ? "Cumulative" : "Daily"}
            </button>
          ))}
        </div>
      </div>
      <div style={{ border: "1px solid var(--border-light)", borderRadius: 12, padding: "16px 8px 8px", marginBottom: 20 }}>
        <ResponsiveContainer width="100%" height={360}>
          {chartMode === "cumulative" ? (
            <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-light)" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => d.slice(5)} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => v.toFixed(1)} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line type="monotone" dataKey="model_cumulative" name="Model Spread" stroke="var(--sig-neutral)" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="actual_cumulative" name="Actual Spread" stroke="var(--sig-short)" strokeWidth={2} dot={false} />
            </LineChart>
          ) : (
            <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-light)" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => d.slice(5)} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => v.toFixed(2)} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <ReferenceLine y={0} stroke="var(--text-muted)" />
              <Bar dataKey="model_daily" name="Model" fill="var(--sig-neutral)" />
              <Bar dataKey="actual_daily" name="Actual" fill="var(--sig-short)" opacity={0.8} />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* PER-PRODUCT BREAKDOWN TABLE */}
      <h3 className="exec-section-header">Breakdown by Product</h3>
      <div className="tableWrap" style={{ border: "1px solid var(--border-light)", borderRadius: 12 }}>
        <table className="dataTable" style={{ minWidth: 500 }}>
          <thead>
            <tr>
              <th>Product</th>
              <th style={{ textAlign: "right" }}>Model ($)</th>
              <th style={{ textAlign: "right" }}>Actual ($)</th>
              <th style={{ textAlign: "right" }}>Slippage ($)</th>
              <th style={{ textAlign: "right" }}>Slippage %</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(summary.by_product).map(([product, v]) => {
              const pct = v.model > 0 ? ((v.slippage / v.model) * 100).toFixed(1) : "—";
              const color = v.slippage > 0 ? "var(--sig-short)" : v.slippage < 0 ? "var(--sig-long)" : "var(--text-primary)";
              return (
                <tr key={product}>
                  <td className="product">{product}</td>
                  <td style={{ textAlign: "right" }}>{fmt(v.model)}</td>
                  <td style={{ textAlign: "right" }}>{fmt(v.actual)}</td>
                  <td style={{ textAlign: "right", color, fontWeight: 600 }}>
                    {v.slippage > 0 ? "+" : ""}{fmt(v.slippage)}
                  </td>
                  <td style={{ textAlign: "right", color, fontSize: 12 }}>
                    {v.slippage > 0 ? "+" : ""}{pct}%
                  </td>
                </tr>
              );
            })}
            <tr style={{ fontWeight: 700, borderTop: "2px solid var(--border-light)" }}>
              <td>Total</td>
              <td style={{ textAlign: "right" }}>{fmt(summary.total_model)}</td>
              <td style={{ textAlign: "right" }}>{fmt(summary.total_actual)}</td>
              <td style={{ textAlign: "right", color: summary.total_slippage > 0 ? "var(--sig-short)" : "var(--sig-long)" }}>
                {summary.total_slippage > 0 ? "+" : ""}{fmt(summary.total_slippage)}
              </td>
              <td style={{ textAlign: "right", color: summary.total_slippage > 0 ? "var(--sig-short)" : "var(--sig-long)", fontSize: 12 }}>
                {summary.total_model > 0 ? `${summary.total_slippage > 0 ? "+" : ""}${((summary.total_slippage / summary.total_model) * 100).toFixed(1)}%` : "—"}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
