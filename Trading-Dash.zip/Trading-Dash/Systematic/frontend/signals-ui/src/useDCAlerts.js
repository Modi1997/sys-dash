import { useEffect } from "react";
import { playBeep, playLongBeep, playSiren, speak } from "./audio";
import { STRATEGY_OVERRIDES, resolveOverride, rawProduct } from "./constants";

const SPEAK_NAMES = {
  brtdub1: "Brent Dubai",
  dubspr1: "Dubai Spread",
  ebobcrk1: "E bob crack",
  sg380crk1: "three eighty crack",
  c3lst1: "L S T",
  sg05crk1: "Sing .5",
};

const POS_LABEL = { 1: "long", "-1": "short", 0: "flat" };

function posLabel(pos) {
  return POS_LABEL[pos] ?? "flat";
}

function formatPrice(x) {
  const n = Number(x);
  if (!Number.isFinite(n)) return "";
  return n.toFixed(2);
}

function buildFlipPhrase(name, prevPos, currPos, px) {
  const closePart = prevPos && prevPos !== 0 ? `close ${posLabel(prevPos)}, ` : "";
  const openPart = currPos !== 0 ? `open ${posLabel(currPos)}` : "go flat";
  const pricePart = px ? ` at ${px}` : "";
  return `${name}: ${closePart}${openPart}${pricePart}`;
}

function londonNow() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/London",
    hour: "2-digit",
    minute: "2-digit",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const get = (type) => parseInt(parts.find((p) => p.type === type)?.value, 10);
  return {
    hour: get("hour"),
    minute: get("minute"),
    dateStr: `${get("year")}-${get("month")}-${get("day")}`,
  };
}

// Module-level sets survive HMR re-mounts
const _firedLevels = new Set();
const _prevPos = {};
const _prevStop = {};

/** Build a Set of inactive signal keys based on current overrides in localStorage. */
function _inactiveKeys() {
  let overrides = {};
  try { overrides = JSON.parse(localStorage.getItem("strategyOverrides") || "{}"); } catch {}
  const inactive = new Set();
  for (const product of Object.keys(STRATEGY_OVERRIDES)) {
    const cfg = STRATEGY_OVERRIDES[product];
    const inactiveCfg = overrides[product] ? cfg.default : cfg.alt;
    inactive.add(inactiveCfg.signalKey);
  }
  return inactive;
}


/**
 * Hook: monitors DC signal data.
 * 1) Position-change alerts: "<product>: close <old>, open <new> at <price>"
 * 2) Stop alerts: "<product>: stop hit, close <pos>"
 * 3) Proximity alerts (hourly): only fires when dist_trigger < 50% of threshold
 * 4) MA level alerts at configured signal hours
 */
export default function useDCAlerts(sigLatestData, windowsData) {

  // --- Position-change alerts (on data update) ---
  useEffect(() => {
    if (!sigLatestData) return;

    const inactive = _inactiveKeys();
    const trades = [];

    for (const [product, payload] of Object.entries(sigLatestData)) {
      if (inactive.has(product)) continue;
      const live = payload?.latest;
      if (!live) continue;

      const currPos = live.pos_desired;
      const prevPos = _prevPos[product];

      if (prevPos !== undefined && currPos !== undefined && prevPos !== currPos) {
        trades.push({ product, close: live.close, prevPos, currPos });
      }

      _prevPos[product] = currPos;
    }

    const stops = [];
    for (const [product, payload] of Object.entries(sigLatestData)) {
      if (inactive.has(product)) continue;
      const live = payload?.latest;
      if (!live) continue;
      const currStop = !!live.stop_triggered;
      const prevStop = _prevStop[product];
      if (prevStop === false && currStop === true) {
        stops.push({ product, stoppedPos: _prevPos[product] });
      }
      _prevStop[product] = currStop;
    }

    if (trades.length === 0 && stops.length === 0) return;

    (async () => {
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();

      for (const t of trades) {
        await playSiren();
        await new Promise((r) => setTimeout(r, 80));

        const name = SPEAK_NAMES[rawProduct(t.product)] || rawProduct(t.product);
        const px = formatPrice(t.close);
        const phrase = buildFlipPhrase(name, t.prevPos, t.currPos, px);
        await speak(phrase);

        await new Promise((r) => setTimeout(r, 120));
      }

      for (const s of stops) {
        await playSiren();
        await new Promise((r) => setTimeout(r, 80));
        const name = SPEAK_NAMES[rawProduct(s.product)] || rawProduct(s.product);
        const closePart = s.stoppedPos && s.stoppedPos !== 0 ? `, close ${posLabel(s.stoppedPos)}` : "";
        await speak(`${name}: stop hit${closePart}`);
        await new Promise((r) => setTimeout(r, 120));
      }
  
    })();
  }, [sigLatestData]);

  // --- Reminder beep at :55 of every hour (stable, mount-only) ---
  useEffect(() => {
    async function hourlyReminder() {
      const { hour, minute, dateStr } = londonNow();
      if (!((minute >= 50 && minute <= 52) || (minute >= 55 && minute <= 57))) return;

      const slot = minute >= 55 ? "h" : "early";
      const key = `dc_reminder_${slot}_${hour}_${dateStr}`;
      if (_firedLevels.has(key)) return;
      _firedLevels.add(key);

      await playLongBeep(1200, 1000, 0.5);
    }

    hourlyReminder();
    const id = setInterval(hourlyReminder, 15_000);
    return () => clearInterval(id);
  }, []);
}
