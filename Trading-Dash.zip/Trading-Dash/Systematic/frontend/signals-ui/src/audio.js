/**
 * Global mute flag — checked by all audio functions.
 */
let _muted = localStorage.getItem("muted") === "true";
export function setMuted(v) { _muted = !!v; localStorage.setItem("muted", _muted); }
export function isMuted() { return _muted; }

/**
 * Shared AudioContext — created lazily on first user gesture.
 * Reused by all alert hooks to avoid Chrome's autoplay restrictions.
 */
let _ctx = null;

function getAudioContext() {
  if (!_ctx) {
    _ctx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (_ctx.state === "suspended") {
    _ctx.resume().catch(() => {});
  }
  return _ctx;
}

// Unlock audio on first user interaction
function unlockAudio() {
  getAudioContext();
  document.removeEventListener("click", unlockAudio);
  document.removeEventListener("keydown", unlockAudio);
}
document.addEventListener("click", unlockAudio);
document.addEventListener("keydown", unlockAudio);

export function playBeep(freq = 660) {
  return new Promise((resolve) => {
    if (_muted) return resolve();
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        resolve();
      }, 160);
    } catch {
      resolve();
    }
  });
}

export function playLongBeep(freq = 1200, duration = 2000, volume = 0.15) {
  return new Promise((resolve) => {
    if (_muted) return resolve();
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.value = volume;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        resolve();
      }, duration);
    } catch {
      resolve();
    }
  });
}

export function playSiren() {
  return new Promise(async (resolve) => {
    if (_muted) return resolve();
    try {
      const ctx = getAudioContext();
      for (let i = 0; i < 2; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "square";
        osc.frequency.value = 880;
        gain.gain.value = 0.15;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        await new Promise((r) => setTimeout(r, 120));
        osc.stop();
        await new Promise((r) => setTimeout(r, 80));
      }
      resolve();
    } catch {
      resolve();
    }
  });
}

export function speak(text) {
  return new Promise((resolve) => {
    if (_muted) return resolve();
    if (!("speechSynthesis" in window)) return resolve();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1;
    u.pitch = 1;
    u.volume = 1;
    u.onend = resolve;
    u.onerror = resolve;
    window.speechSynthesis.speak(u);
  });
}
