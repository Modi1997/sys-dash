export const DC_GROUPS = [
  { title: "DC Normal", strategy: "DC Normal", products: new Set(["brtdub1", "ebobcrk1", "sg05crk1", "sg380crk1", "dubspr1:dc_classic"]) },
  { title: "DC Continuous Event", strategy: "DC Continuous", products: new Set(["dubspr1"]) },
];

/** Extract raw product symbol from a compound key (e.g. "dubspr1:dc_classic" → "dubspr1") */
export function rawProduct(key) {
  return key.includes(":") ? key.split(":")[0] : key;
}

/** Extended groups for Signals tab — includes signal-only (non-traded) products */
export const DC_GROUPS_SIGNALS = [
  { title: "DC Normal", strategy: "DC Normal", products: new Set(["brtdub1", "ebobcrk1", "sg05crk1", "sg380crk1", "dubspr1:dc_classic"]) },
  { title: "DC Continuous Event", strategy: "DC Continuous", products: new Set(["dubspr1"]) },
];

// --- Strategy override toggle ---
// Products that support switching between two DC strategy variants.
export const STRATEGY_OVERRIDES = {};

/** Resolve the active signal key + strategy for a product given current overrides state. */
export function resolveOverride(product, overrides) {
  const cfg = STRATEGY_OVERRIDES[product];
  if (!cfg) return null;
  return (overrides && overrides[product]) ? cfg.alt : cfg.default;
}

/** Return a Set of all equivalent strategy display names for a product (for trade matching). */
export function matchStrategies(product) {
  const cfg = STRATEGY_OVERRIDES[product];
  if (!cfg) return null;
  return new Set([cfg.default.strategy, cfg.alt.strategy]);
}

export const PRODUCT_SIGNAL_HOURS = {
  brtdub1: [10],
  "35brgcrk1": [16],
};

export const PRODUCTS = ["brtdub1", "35brgcrk1", "c3lst1", "dubspr1", "ebobcrk1", "sg380crk1", "sg05crk1"];
export const STRATEGIES = ["DC Normal", "DC Trailing", "DC Continuous", "ACF MA"];

// --- Contract mapping ---
export const MONTH_CODES = ["F","G","H","J","K","M","N","Q","U","V","X","Z"];

const TIME_SPREAD_BASES = new Set(["dubspr"]);

/**
 * Suggest the default contract code for a new trade opened today.
 * Returns e.g. "J26" (single month) or "J26K26" (time spread).
 * User can override in the form.
 */
// --- Unit conversion ---
export const KB_PER_KT = 6.35;

// Full target sizes per product (in KB)
export const FULL_SIZES = {
  brtdub1: 40,
  "35brgcrk1": 5 * KB_PER_KT,   // 5 KT
  dubspr1: 40,
  c3lst1: 10,
  ebobcrk1: 10,
  sg380crk1: 3 * KB_PER_KT,     // 3 KT
  sg05crk1: 2 * KB_PER_KT,      // 2 KT
};

export function suggestContract(product) {
  const now = new Date();
  let frontMonth = now.getMonth() + 1; // +1 = M1 offset (all products)
  let frontYear = now.getFullYear();
  if (frontMonth > 11) {
    frontMonth -= 12;
    frontYear += 1;
  }
  const code1 = MONTH_CODES[frontMonth];
  const yr1 = String(frontYear).slice(-2);

  const base = product.replace(/\d+$/, "");
  if (TIME_SPREAD_BASES.has(base)) {
    let backMonth = frontMonth + 1;
    let backYear = frontYear;
    if (backMonth > 11) {
      backMonth -= 12;
      backYear += 1;
    }
    const code2 = MONTH_CODES[backMonth];
    const yr2 = String(backYear).slice(-2);
    return `${code1}${yr1}${code2}${yr2}`;
  }

  return `${code1}${yr1}`;
}
