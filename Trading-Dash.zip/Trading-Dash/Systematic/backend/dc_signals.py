import pandas as pd
import numpy as np
from typing import Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from Systematic.backend.sys_utils import get_data, compute_delta
from Helpers.log_helper import Logger
pd.set_option('display.max_columns', 20)
pd.set_option('display.width', 2000)

log = Logger()

def directional_change_events(series, delta, price_series, include_overshoots=False):
    s = series.astype(float).values
    p = price_series.astype(float).values

    events = np.zeros(len(s), dtype=int)
    extremes = np.full(len(s), np.nan)

    mode = "up"
    S_ext = s[0]
    S_IE  = s[0]
    P_ext = p[0]

    for i in range(1, len(s)):
        St = s[i]

        if mode == "up":
            if St - S_ext >= delta:
                mode = "down"
                S_ext = S_IE = St
                P_ext = p[i]
                events[i] = 1
            elif St < S_ext:
                S_ext = St
                if S_IE - S_ext >= delta:
                    S_IE = St
                    if include_overshoots:
                        events[i] = -1
                if p[i] < P_ext:
                    P_ext = p[i]

        else:  # mode == "down"
            if S_ext - St >= delta:
                mode = "up"
                S_ext = S_IE = St
                P_ext = p[i]
                events[i] = -1
            elif St > S_ext:
                S_ext = St
                if S_ext - S_IE >= delta:
                    S_IE = St
                    if include_overshoots:
                        events[i] = 1
                if p[i] > P_ext:
                    P_ext = p[i]
        
        extremes[i] = P_ext

    return (
        pd.Series(events, index=series.index, name="event"),
        pd.Series(extremes, index=series.index, name="extreme"),
    )


def forward_fill_events(events: pd.Series) -> pd.Series:
    return events.replace(0, np.nan).ffill().fillna(0).astype(int)


def dc_signal_from_events(events, cum_delta, lookback):
    cd_shift = cum_delta.shift(lookback)
    pos = pd.Series(np.nan, index=events.index, dtype=float)
    long_mask  = (events == 1)  & (cum_delta > cd_shift)
    short_mask = (events == -1) & (cum_delta < cd_shift)
    pos[long_mask] = 1
    pos[short_mask] = -1
    return pos.ffill().fillna(0).astype(int)


def generate_exec_signal(df, pos_raw, trade_hours, stop_loss, dc_delta):
    out = df.copy()

    ev, extreme = directional_change_events(out["cum_delta"], delta=dc_delta, price_series=out["close"])
    out = out.join(ev, how="left")
    out = out.join(extreme, how="left")

    out = out.join(pos_raw.rename("pos_raw"), how="left")
    out["pos_raw"] = out["pos_raw"].fillna(0).astype(int)

    start_h, end_h = trade_hours
    hours = out.index.hour
    in_hours = (hours >= start_h) & (hours <= end_h)

    stop_px = out["cum_delta"].astype(float)
    raw = out["pos_raw"].astype(int)

    desired = raw.copy()
    stop_trigger = pd.Series(False, index=out.index)

    entry_px = np.nan
    entry_close = np.nan
    eff_pos = 0          # effective (hours-filtered) position for stop tracking
    px_ext = np.nan      # price extreme since position change

    blocked = False
    blocked_dir = 0

    price_extreme = pd.Series(np.nan, index=out.index)
    stop_level_s = pd.Series(np.nan, index=out.index)

    for t in out.index:
        p_raw = int(raw.loc[t])
        ih = start_h <= t.hour <= end_h

        if blocked:
            desired.loc[t] = 0
            if ih and p_raw == -blocked_dir and p_raw != 0:
                blocked = False
                blocked_dir = 0
                desired.loc[t] = p_raw
        else:
            desired.loc[t] = p_raw

        p_des = int(desired.loc[t])
        close_val = float(out["close"].loc[t])

        # Effective position only updates during trade hours
        new_eff = p_des if ih else eff_pos

        # Reset stop anchor when effective position changes
        if new_eff != eff_pos:
            entry_px = float(stop_px.loc[t]) if new_eff != 0 else np.nan
            entry_close = close_val if new_eff != 0 else np.nan
            px_ext = close_val if new_eff != 0 else np.nan

        eff_pos = new_eff

        # Track extremes on every bar (including off-hours)
        if eff_pos == 1:
            px_ext = max(px_ext, close_val)
        elif eff_pos == -1:
            px_ext = min(px_ext, close_val)

        # Check stops on every bar (including outside trade hours)
        # if ih:
        if True:
            if eff_pos != 0 and not np.isnan(entry_px):
                cur_px = float(stop_px.loc[t])
                unreal = eff_pos * (cur_px - entry_px)
                if unreal < -stop_loss:
                    stop_trigger.loc[t] = True
                    desired.loc[t] = 0
                    blocked = True
                    blocked_dir = eff_pos
                    eff_pos = 0
                    entry_px = np.nan
                    entry_close = np.nan
                    px_ext = np.nan

        price_extreme.loc[t] = px_ext

        # Stop level: fixed at entry_close ± stop_loss
        if eff_pos == 1:
            stop_level_s.loc[t] = entry_close - stop_loss
        elif eff_pos == -1:
            stop_level_s.loc[t] = entry_close + stop_loss

    out["stop_triggered"] = stop_trigger
    out["price_extreme"] = price_extreme
    out["stop_level"] = stop_level_s
    out["pos_desired_raw"] = desired.astype(int)

    exec_pos = out["pos_desired_raw"].astype(float)
    exec_pos.loc[~in_hours] = np.nan
    out["pos_desired"] = exec_pos.ffill().fillna(0).astype(int)

    out["blocked"] = int(blocked)
    out["blocked_dir"] = int(blocked_dir)

    cols = []
    for c in ["open", "close"]:
        if c in out.columns:
            cols.append(c)
    if "cum_delta" in out.columns:
        cols.append("cum_delta")

    cols += ["event", "extreme", "price_extreme", "stop_level", "pos_raw", "pos_desired", "stop_triggered", "blocked", "blocked_dir"]
    return out[cols]


def generate_exec_signal_trailing(df, pos_raw, trade_hours, stop_loss, dc_delta, include_overshoots=False):
    out = df.copy()

    ev, extreme_price = directional_change_events(out["cum_delta"], delta=dc_delta, price_series=out["close"], include_overshoots=include_overshoots)
    out = out.join(ev, how="left")
    out = out.join(extreme_price, how="left")

    out = out.join(pos_raw.rename("pos_raw"), how="left")
    out["pos_raw"] = out["pos_raw"].fillna(0).astype(int)

    start_h, end_h = trade_hours
    hours = out.index.hour
    in_hours = (hours >= start_h) & (hours <= end_h)

    stop_px = out["cum_delta"].astype(float)
    raw = out["pos_raw"].astype(int)

    desired = raw.copy()
    stop_trigger = pd.Series(False, index=out.index)

    eff_pos = 0          # effective (hours-filtered) position for stop tracking
    track_pos = 0        # desired position (incl. off-hours) for extreme tracking
    extreme = np.nan     # cum_delta extreme for trailing stop
    px_ext = np.nan      # close price extreme since position change
    blocked = False
    blocked_dir = 0

    price_extreme = pd.Series(np.nan, index=out.index)
    stop_level_s = pd.Series(np.nan, index=out.index)

    for t in out.index:
        p_raw = int(raw.loc[t])
        ih = start_h <= t.hour <= end_h

        if blocked:
            desired.loc[t] = 0
            if ih and p_raw == -blocked_dir and p_raw != 0:
                blocked = False
                blocked_dir = 0
                desired.loc[t] = p_raw
        else:
            desired.loc[t] = p_raw

        p_des = int(desired.loc[t])
        cur_px = float(stop_px.loc[t])
        close_val = float(out["close"].loc[t])

        # Effective position only updates during trade hours
        new_eff = p_des if ih else eff_pos

        # Track extremes based on desired position (includes off-hours)
        if p_des != track_pos:
            extreme = cur_px if p_des != 0 else np.nan
            px_ext = close_val if p_des != 0 else np.nan
        track_pos = p_des

        eff_pos = new_eff

        # Track extremes on every bar (including off-hours)
        if track_pos == 1:
            extreme = max(extreme, cur_px)
            px_ext = max(px_ext, close_val)
        elif track_pos == -1:
            extreme = min(extreme, cur_px)
            px_ext = min(px_ext, close_val)

        # Check trailing stops on every bar (including outside trade hours)
        if True:
            if eff_pos == 1:
                if cur_px <= extreme - stop_loss:
                    stop_trigger.loc[t] = True
                    desired.loc[t] = 0
                    blocked = True
                    blocked_dir = 1
                    eff_pos = 0
                    track_pos = 0
                    extreme = np.nan
                    px_ext = np.nan

            elif eff_pos == -1:
                if cur_px >= extreme + stop_loss:
                    stop_trigger.loc[t] = True
                    desired.loc[t] = 0
                    blocked = True
                    blocked_dir = -1
                    eff_pos = 0
                    track_pos = 0
                    extreme = np.nan
                    px_ext = np.nan

        price_extreme.loc[t] = px_ext

        # Trailing stop level: ratchets with price_extreme
        if track_pos == 1:
            stop_level_s.loc[t] = px_ext - stop_loss
        elif track_pos == -1:
            stop_level_s.loc[t] = px_ext + stop_loss

    out["stop_triggered"] = stop_trigger
    out["price_extreme"] = price_extreme
    out["stop_level"] = stop_level_s
    out["pos_desired_raw"] = desired.astype(int)

    exec_pos = out["pos_desired_raw"].astype(float)
    exec_pos.loc[~in_hours] = np.nan
    out["pos_desired"] = exec_pos.ffill().fillna(0).astype(int)

    out["blocked"] = int(blocked)
    out["blocked_dir"] = int(blocked_dir)

    cols = []
    for c in ["open", "close"]:
        if c in out.columns:
            cols.append(c)
    if "cum_delta" in out.columns:
        cols.append("cum_delta")

    cols += ["event", "extreme", "price_extreme", "stop_level", "pos_raw", "pos_desired", "stop_triggered", "blocked", "blocked_dir"]
    return out[cols]



@dataclass(frozen=True)
class ProductSigConfig:
    symbol: str
    threshold: float
    lookback: int
    trade_hours: Tuple[int, int]
    stop_loss: float
    strategy: str = "dc_classic"
    key: str = ""

    def __post_init__(self):
        if not self.key:
            object.__setattr__(self, "key", self.symbol)


def _load_ohlc(symbol, start_str, end_str):
    df = (get_data([symbol], start_str, end_str, "1h").set_index("timestamp")[["open", "close"]].sort_index())
    idx = pd.to_datetime(df.index, utc=True).tz_convert("Europe/London")
    return df.set_index(idx)


# ---- Strategy functions ----
# Each returns (sig, last_event_row)

def _origin_flip_event(sig: pd.DataFrame, trade_hours: tuple):
    """First causal in-hours event in the current pos_desired regime.

    For long/short: the first in-hours bar where event == pos_desired (the DC
    event that actually initiated the direction).
    For flat (stopped out): the first in-hours bar where stop_triggered == True.

    Returns (origin_row: DataFrame, prev_pos_desired: int | None).
    """
    if len(sig) < 2:
        return sig.iloc[0:0], None

    pos = sig["pos_desired"]
    current = pos.iloc[-1]

    # Find the start of the current pos_desired regime
    diff_mask = pos != current
    if not diff_mask.any():
        return sig.iloc[0:0], None

    last_diff_idx = sig.index[diff_mask][-1]
    prev_pos = int(pos.loc[last_diff_idx])
    regime = sig.loc[sig.index > last_diff_idx]
    if regime.empty:
        return sig.iloc[0:0], prev_pos

    # Only consider in-hours bars as causal events
    start_h, end_h = trade_hours
    hours = regime.index.hour
    in_hours = regime.loc[(hours >= start_h) & (hours <= end_h)]

    if current == 0:
        # Flat — origin is the stop that caused it
        stops = in_hours.loc[in_hours["stop_triggered"]]
        row = stops.iloc[0:1] if not stops.empty else in_hours.iloc[0:1]
        return row, prev_pos

    # Long/short — find the event that initiated this direction
    match = in_hours.loc[in_hours["event"] == current]
    row = match.iloc[0:1] if not match.empty else in_hours.iloc[0:1]
    return row, prev_pos


def _strategy_dc_classic(delta_df, cfg):
    ev, _ = directional_change_events(delta_df["cum_delta"], delta=cfg.threshold, price_series=delta_df["close"])
    pos = dc_signal_from_events(ev, cum_delta=delta_df["cum_delta"], lookback=cfg.lookback)
    sig = generate_exec_signal(
        df=delta_df, pos_raw=pos,
        trade_hours=cfg.trade_hours, stop_loss=cfg.stop_loss, dc_delta=cfg.threshold,
    ).sort_index()
    last_event_row, prev_pos = _origin_flip_event(sig, cfg.trade_hours)
    return sig, last_event_row, prev_pos


def _strategy_dc_ffill(delta_df, cfg):
    ev, _ = directional_change_events(delta_df["cum_delta"], delta=cfg.threshold, price_series=delta_df["close"])
    ev = forward_fill_events(ev)
    pos = dc_signal_from_events(ev, cum_delta=delta_df["cum_delta"], lookback=cfg.lookback)
    sig = generate_exec_signal(
        df=delta_df, pos_raw=pos,
        trade_hours=cfg.trade_hours, stop_loss=cfg.stop_loss, dc_delta=cfg.threshold,
    ).sort_index()

    sig["event"] = forward_fill_events(sig["event"])
    last_event_row, prev_pos = _origin_flip_event(sig, cfg.trade_hours)

    return sig, last_event_row, prev_pos


def _strategy_dc_trailing(delta_df, cfg):
    ev, _ = directional_change_events(delta_df["cum_delta"], delta=cfg.threshold, price_series=delta_df["close"], include_overshoots=False)
    pos = dc_signal_from_events(ev, cum_delta=delta_df["cum_delta"], lookback=cfg.lookback)
    sig = generate_exec_signal_trailing(
        df=delta_df, pos_raw=pos,
        trade_hours=cfg.trade_hours, stop_loss=cfg.stop_loss, dc_delta=cfg.threshold,
        include_overshoots=False,
    ).sort_index()
    last_event_row, prev_pos = _origin_flip_event(sig, cfg.trade_hours)
    return sig, last_event_row, prev_pos


STRATEGY_REGISTRY = {
    "dc_classic": _strategy_dc_classic,
    "dc_ffill": _strategy_dc_ffill,
    "dc_trailing": _strategy_dc_trailing,
}



def compute_sig_for_product(cfg):
    end_date = datetime.now() + timedelta(days=1)
    start_date = end_date - timedelta(days=40)
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")

    ohlc = _load_ohlc(cfg.symbol, start_str, end_str)
    delta_df = compute_delta(ohlc)

    run = STRATEGY_REGISTRY[cfg.strategy]
    sig, last_event_row, prev_pos = run(delta_df, cfg)

    sig["close_lookback"] = sig["close"].shift(cfg.lookback)

    latest_row = sig.tail(1)

    if not last_event_row.empty and last_event_row.index.equals(latest_row.index):
        out = latest_row
    else:
        out = pd.concat([latest_row, last_event_row], axis=0)

    # All hourly bars between origin flip and latest
    events_between = pd.DataFrame()
    if not last_event_row.empty and not last_event_row.index.equals(latest_row.index):
        events_between = sig.loc[
            (sig.index > last_event_row.index[0])
            & (sig.index < latest_row.index[0])
        ]

    out = out.copy()
    out.insert(0, "symbol", cfg.symbol)
    log.debug(f"[END] Refresh {cfg.symbol} DC signal.")
    return out, events_between, prev_pos, sig
