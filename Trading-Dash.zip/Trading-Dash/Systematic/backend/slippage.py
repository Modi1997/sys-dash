"""
slippage.py  --  Parse trades CSV and compute daily model vs actual spread costs.

Each trade generates two spread events (entry + exit), each attributed to its date.
  - Model spread per leg  = MODEL_SPREAD[product] / 2
  - Actual spread per leg = model_per_leg + excess  (excess from CSV)
  - Spread cost ($)       = spread_per_leg * size
"""
import os, csv, re
from datetime import datetime
from collections import defaultdict
from pathlib import Path

# Full round-trip model spread assumptions ($/bbl or $/mt).
# Per-leg = value / 2.
MODEL_SPREAD = {
    "brtdub":   0.04,
    "dubspr":   0.04,
    "ebobcrk":  0.13,
    "35brgcrk": 0.13,
    "sg380crk": 0.13,
    "sg05crk":  0.13,
    "lstfp":    0.40,
}

CSV_PATH = Path(__file__).parent.parent / "trades(Trades).csv"



def _parse_date(s: str) -> str | None:
    """Parse date string to YYYY-MM-DD.  Returns None if invalid."""
    if not s or not s.strip():
        return None
    s = s.strip()
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            d = datetime.strptime(s, fmt)
            if d.year < 2020:  # filter out 1900-style placeholders
                return None
            return d.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _parse_float(s: str) -> float | None:
    """Parse a float, returning None on failure."""
    if not s or not s.strip():
        return None
    s = s.strip()
    try:
        return float(s)
    except ValueError:
        return None


def _parse_size(s: str) -> float | None:
    """Parse size — may be a plain number or a multi-line split fill description."""
    if not s or not s.strip():
        return None
    s = s.strip()
    # Try plain number first
    try:
        return float(s)
    except ValueError:
        pass
    # Multi-line split fill: sum the quantities (e.g. "6350 @ 14.5\n6350 @ 13.8")
    total = 0.0
    for line in s.split("\n"):
        line = line.strip()
        m = re.match(r"([\d.]+)\s*@", line)
        if m:
            total += float(m.group(1))
    return total if total > 0 else None


def load_trades() -> list[dict]:
    """Load and parse the trades CSV. Returns list of cleaned trade dicts."""
    if not CSV_PATH.exists():
        return []

    trades = []
    with open(CSV_PATH, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        # Skip header row (first cell is "316.8" not a proper header)
        next(reader, None)

        for row in reader:
            if len(row) < 17:
                continue

            entry_date = _parse_date(row[0])
            product = (row[3] or "").strip().lower()
            if not entry_date or not product:
                continue
            if product not in MODEL_SPREAD:
                continue

            size = _parse_float(row[6])
            if not size or size <= 0:
                # Try parsing multi-line size
                size = _parse_size(row[6])
                if not size or size <= 0:
                    continue

            entry_spread_excess = _parse_float(row[9])
            exit_spread_excess = _parse_float(row[10])
            exit_date = _parse_date(row[2])
            signal = (row[4] or "").strip()

            trades.append({
                "entry_date": entry_date,
                "exit_date": exit_date,
                "product": product,
                "signal": signal,
                "size": size,
                "entry_spread_excess": entry_spread_excess,
                "exit_spread_excess": exit_spread_excess,
            })

    return trades


def compute_slippage() -> dict:
    """Compute daily model vs actual spread per unit (not size-weighted)."""
    trades = load_trades()
    if not trades:
        return {"all": [], "by_product": {}, "summary": {}}

    # Collect daily spread events: { date: { "model": val, "actual": val } }
    daily_all = defaultdict(lambda: {"model": 0.0, "actual": 0.0})
    daily_product = defaultdict(lambda: defaultdict(lambda: {"model": 0.0, "actual": 0.0}))

    # Summary accumulators
    summary_product = defaultdict(lambda: {"model": 0.0, "actual": 0.0})

    for t in trades:
        product = t["product"]
        model_per_leg = MODEL_SPREAD[product] / 2

        # Entry event (spread per unit, not multiplied by size)
        if t["entry_date"] is not None and t["entry_spread_excess"] is not None:
            model_spread = model_per_leg
            actual_spread = model_per_leg + t["entry_spread_excess"]
            d = t["entry_date"]
            daily_all[d]["model"] += model_spread
            daily_all[d]["actual"] += actual_spread
            daily_product[product][d]["model"] += model_spread
            daily_product[product][d]["actual"] += actual_spread
            summary_product[product]["model"] += model_spread
            summary_product[product]["actual"] += actual_spread

        # Exit event (spread per unit, not multiplied by size)
        if t["exit_date"] is not None and t["exit_spread_excess"] is not None:
            model_spread = model_per_leg
            actual_spread = model_per_leg + t["exit_spread_excess"]
            d = t["exit_date"]
            daily_all[d]["model"] += model_spread
            daily_all[d]["actual"] += actual_spread
            daily_product[product][d]["model"] += model_spread
            daily_product[product][d]["actual"] += actual_spread
            summary_product[product]["model"] += model_spread
            summary_product[product]["actual"] += actual_spread

    def _build_cumulative(daily: dict) -> list[dict]:
        """Convert daily dict to sorted cumulative list."""
        dates = sorted(daily.keys())
        cum_model = 0.0
        cum_actual = 0.0
        result = []
        for d in dates:
            cum_model += daily[d]["model"]
            cum_actual += daily[d]["actual"]
            result.append({
                "date": d,
                "model_cumulative": round(cum_model, 2),
                "actual_cumulative": round(cum_actual, 2),
                "model_daily": round(daily[d]["model"], 2),
                "actual_daily": round(daily[d]["actual"], 2),
            })
        return result

    # Build outputs
    all_series = _build_cumulative(daily_all)

    by_product = {}
    for product in sorted(daily_product.keys()):
        by_product[product] = _build_cumulative(daily_product[product])

    # Summary
    total_model = sum(v["model"] for v in summary_product.values())
    total_actual = sum(v["actual"] for v in summary_product.values())
    summary = {
        "total_model": round(total_model, 2),
        "total_actual": round(total_actual, 2),
        "total_slippage": round(total_actual - total_model, 2),
        "by_product": {
            p: {
                "model": round(v["model"], 2),
                "actual": round(v["actual"], 2),
                "slippage": round(v["actual"] - v["model"], 2),
            }
            for p, v in sorted(summary_product.items())
        },
    }

    return {
        "all": all_series,
        "by_product": by_product,
        "summary": summary,
    }
