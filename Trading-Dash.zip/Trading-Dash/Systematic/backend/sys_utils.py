import requests, pymongo, time, os, sys, pandas as pd, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT))
from dotenv import load_dotenv
from Helpers.log_helper import Logger

# Debugger
log = Logger()

# dotenv
env_path = Path(__file__).parent / "systematic.env"
load_dotenv(env_path)

# Mongo DB
mongo_client = pymongo.MongoClient(os.getenv("CLIENT"))
db = mongo_client[os.getenv("DB_SIGNALS")]
collection_systematic_signals = db[os.getenv("COLLECTION_SYSTEMATIC_SIGNALS")]

def get_data(contract_symbols, start_time, end_time, time_increment='1h'):
    def process_paginated_data(url, headers, params):
        if params is None:
            params = {}
        all_data = []
        while True:
            response = requests.get(url, headers=headers, params=params)
            if response.status_code == 429:
                time.sleep(60)
                continue
            elif response.status_code != 200:
                return []
            all_data.extend(response.json())
            cursor = response.headers.get("x-cursor")
            if not cursor:
                break
            params["cursor"] = cursor
            time.sleep(3)
        return all_data

    try:
        all_data = []
        for contract_symbol in contract_symbols:
            url = f"{os.getenv('URL')}{contract_symbol}/{time_increment}"
            headers_auth = {"Authorization": f"Bearer {os.getenv('AUTHORIZATION')}"}
            params = {"start": start_time, "end": end_time}
            data = process_paginated_data(url, headers_auth, params)
            if data:
                df = pd.DataFrame(data)
                df['ohlc_symbol'] = contract_symbol
                df['contract_symbol'] = df['symbol']
                df['symbol'] = contract_symbol
                all_data.append(df)
        return pd.concat(all_data, ignore_index=True) if all_data else pd.DataFrame()
    except Exception as e:
        log.error(f"ERROR:::   {e}")
        return pd.DataFrame()


def compute_delta(df: pd.DataFrame, hourly_window: int = 20) -> pd.DataFrame:
    df = df.copy()

    # 1. Prepare timestamp/index to be proper datetime
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df = df.set_index("timestamp")
    else:
        df.index = pd.to_datetime(df.index)

    df = df.sort_index()

    # 2. Calculate basic bar-to-bar price change
    df["delta"] = df["close"].diff()

    # 3. Identify rows that belong to a new month (month boundary detection)
    month_key = df.index.to_series().dt.year * 100 + df.index.to_series().dt.month
    is_new_month_row = month_key != month_key.shift(1)

    # 3b. Also treat the last row as a boundary if it's the last business day of its month
    if len(df) > 0:
        last_ts = df.index[-1]
        next_bday = last_ts + pd.tseries.offsets.BDay(1)
        if next_bday.month != last_ts.month:
            is_new_month_row.iloc[-1] = True

    # 4. Create boolean mask covering ±'hourly_window' rows around each month boundary
    idx = np.flatnonzero(is_new_month_row.fillna(False).to_numpy())
    mask = np.zeros(len(df), dtype=bool)

    for i in idx:
        lo = max(0, i - hourly_window)
        hi = min(len(df), i + hourly_window + 1)
        mask[lo:hi] = True

    # 5. overt np mask back pd series
    month_mask = pd.Series(mask, index=df.index)

    # 6. Override delta for rows near month boundaries (based on 'hourly_window')
    df.loc[month_mask, "delta"] = df.loc[month_mask, "close"] - df.loc[month_mask, "open"]

    # 7. Create cumulative sum of delta
    df["cum_delta"] = df["delta"].fillna(0).cumsum()

    return df[["open", "close", "delta", "cum_delta"]]


def add_rolling_mas(df, windows, column="cum_delta"):
    df = df.copy()
    for w in windows:
        df[f"ma_{w}"] = df[column].rolling(window=w, min_periods=w).mean()
    return df


def keep_hour_open(df, hour):
    df.index = pd.to_datetime(df.index, utc=True)
    df_hour = df[df.index.hour == hour]
    return df_hour.drop(columns=["delta"])
