"""
migrate_group_id.py  --  One-time backfill of `group_id` on existing trades.

Strategy: cluster trades by the split-invariant tuple, then assign a shared
`group_id` to clusters whose entry_fees/size ratio matches (confirming they
were created via the blotter's split logic). Singletons get `group_id = str(_id)`.

Usage:
    python -m Systematic.backend.migrate_group_id --dry-run   # preview clusters
    python -m Systematic.backend.migrate_group_id             # actually write
"""
import sys
import uuid
from collections import defaultdict

from Systematic.backend.blotter_trade import collection_trades

# Fields preserved exactly across splits (per TradeBlotter.jsx handleClose)
SPLIT_KEY_FIELDS = ("product", "strategy", "entry_date", "entry_price",
                    "signal", "contract", "entry_spread")

# Tolerance for entry_fees/size ratio match (fees are pro-rated so ratio should match)
RATIO_TOLERANCE = 0.01


def _cluster_key(t: dict) -> tuple:
    return tuple(t.get(k) for k in SPLIT_KEY_FIELDS)


def _fee_ratios_match(trades: list[dict]) -> bool:
    """Verify entry_fees/size ratio is consistent across a cluster."""
    ratios = []
    for t in trades:
        size = t.get("size")
        fees = t.get("entry_fees") or 0
        if not size or size == 0:
            return False
        ratios.append(fees / size)
    if not ratios:
        return False
    return (max(ratios) - min(ratios)) < RATIO_TOLERANCE


def main(dry_run: bool = False):
    pending = list(collection_trades.find({"group_id": {"$exists": False}}))
    if not pending:
        print("Nothing to migrate — all trades already have group_id.")
        return

    clusters = defaultdict(list)
    for t in pending:
        clusters[_cluster_key(t)].append(t)

    merge_groups = []
    singletons = []
    for key, trades in clusters.items():
        if len(trades) > 1 and _fee_ratios_match(trades):
            merge_groups.append((key, trades))
        else:
            for t in trades:
                singletons.append(t)

    # Report
    print(f"Total pending trades: {len(pending)}")
    print(f"Clusters detected as splits (will share group_id): {len(merge_groups)}")
    print(f"Singletons (each gets own group_id): {len(singletons)}")
    print()

    for i, (key, trades) in enumerate(merge_groups, 1):
        product, strategy, entry_date, entry_price, signal, contract, entry_spread = key
        print(f"  Cluster {i}: {product} / {strategy} / {signal} / {contract} / entry@{entry_price} on {entry_date}")
        for t in trades:
            print(f"    - _id={t['_id']}  size={t.get('size')}  entry_fees={t.get('entry_fees')}  status={t.get('status')}")

    if dry_run:
        print("\n[DRY RUN] No changes written. Re-run without --dry-run to apply.")
        return

    # Apply
    for key, trades in merge_groups:
        gid = str(uuid.uuid4())
        for t in trades:
            collection_trades.update_one({"_id": t["_id"]}, {"$set": {"group_id": gid}})
    for t in singletons:
        collection_trades.update_one({"_id": t["_id"]}, {"$set": {"group_id": str(t["_id"])}})

    print(f"\nDone. Wrote group_id to {len(pending)} trades ({len(merge_groups)} merged clusters + {len(singletons)} singletons).")


if __name__ == "__main__":
    dry = "--dry-run" in sys.argv
    main(dry_run=dry)
