import os
from pathlib import Path
from datetime import datetime
from enum import Enum
from typing import Optional

import pymongo
from dotenv import load_dotenv
from pydantic import BaseModel

# Load env (same pattern as sys_utils.py)
env_path = Path(__file__).parent / "systematic.env"
load_dotenv(env_path)

# MongoDB
mongo_client = pymongo.MongoClient(os.getenv("CLIENT_DEV_BLOTTER"))
db = mongo_client[os.getenv("DB_BLOTTER_DEV")]
collection_trades = db[os.getenv("COLLECTION_SYSTEMATIC_TRADING")]


class SignalEnum(str, Enum):
    long = "long"
    short = "short"


class StrategyEnum(str, Enum):
    dc_normal = "DC Normal"
    dc_trailing = "DC Trailing"
    dc_continuous = "DC Continuous"
    acf_ma = "ACF MA"


class TradeTypeEnum(str, Enum):
    internal = "Internal"
    broker = "Broker"
    screen = "Screen"


# --- Pydantic Models ---
class TradeCreate(BaseModel):
    entry_date: datetime
    product: str
    signal: SignalEnum
    strategy: StrategyEnum
    entry_type: TradeTypeEnum
    size: float
    entry_price: float
    contract: str
    entry_spread: Optional[float] = None
    entry_fees: Optional[float] = None
    exit_fees: Optional[float] = None
    comment: Optional[str] = None
    group_id: Optional[str] = None


class TradeUpdate(BaseModel):
    entry_date: Optional[datetime] = None
    exit_date: Optional[datetime] = None
    product: Optional[str] = None
    signal: Optional[SignalEnum] = None
    strategy: Optional[StrategyEnum] = None
    entry_type: Optional[TradeTypeEnum] = None
    exit_type: Optional[TradeTypeEnum] = None
    size: Optional[float] = None
    entry_price: Optional[float] = None
    exit_price: Optional[float] = None
    entry_spread: Optional[float] = None
    exit_spread: Optional[float] = None
    entry_fees: Optional[float] = None
    exit_fees: Optional[float] = None
    contract: Optional[str] = None
    comment: Optional[str] = None


# --- P&L Logic ---
from Systematic.backend.config import PNL_SCALE

def compute_pnl(trade: dict) -> tuple[Optional[float], Optional[float]]:
    """Compute realized P&L for a closed trade. Returns (net_pnl, gross_pnl)."""
    try:
        entry = trade["entry_price"]
        exit_p = trade["exit_price"]
        size = trade["size"]
        direction = 1 if trade["signal"] == "long" else -1
        scale = PNL_SCALE.get(trade.get("product", ""), 1.0)
        gross = direction * (exit_p - entry) * size * 1000 * scale
        entry_fees = trade.get("entry_fees") or 0
        exit_fees = trade.get("exit_fees") or 0
        return gross - entry_fees - exit_fees, gross
    except (KeyError, TypeError):
        return None, None

def compute_summary(trades: list[dict]) -> dict:
    """Aggregate stats."""
    pnls = [compute_pnl(t)[0] for t in trades if t.get("status") == "closed"]
    pnls = [p for p in pnls if p is not None]
    wins = sum(1 for p in pnls if p > 0)
    total = len(pnls)
    return {
        "total_trades": len(trades),
        "closed_trades": total,
        "total_pnl": round(sum(pnls), 2) if pnls else 0,
        "win_rate": round(wins / total * 100, 1) if total > 0 else 0,
    }
