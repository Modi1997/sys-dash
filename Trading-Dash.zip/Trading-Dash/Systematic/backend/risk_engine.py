"""
risk_engine.py  --  Live risk API logic.

Reads pre-computed equity history from MongoDB, fetches today's close
from Flux, appends a live MTM point, computes metrics, returns JSON.

Called by FastAPI (GET /api/risk).  Lightweight -- no heavy recomputation.
"""

from __future__ import annotations

import os
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Optional

import pandas as pd
import pymongo
import requests
from dotenv import load_dotenv

from Systematic.backend.config import PNL_SCALE
from Helpers.risk_pnl import (
    _group_trades,
    _to_date,
    collect_required_symbols,
    compute_daily_pnl,
    contract_to_ticker,
)
from Systematic.backend.blotter_trade import collection_trades, db

# ---------------------------------------------------------------------------
# Env & MongoDB
# ---------------------------------------------------------------------------

env_path = Path(__file__).parent / "systematic.env"
load_dotenv(env_path)

collection_risk = db[os.getenv("COLLECTION_SYSTEMATIC_RISK", "systematic_risk_pnl")]
collection_risk.create_index(
    [("product", pymongo.ASCENDING), ("strategy", pymongo.ASCENDING), ("date", pymongo.ASCENDING)],
    unique=True,
    background=True,
)

FLUX_URL = os.getenv("URL", "")
FLUX_AUTH_RISK = os.getenv("AUTHORIZATION_RISK", "")

# ---------------------------------------------------------------------------
# Backtest limits  (placeholders -- edit values when available)
# ---------------------------------------------------------------------------

BACKTEST_LIMITS: dict = {
    ("brtdub1", "DC Normal"):    {"max_dd": -5000, "max_day_loss": -2000},
    ("brtdub1", "DC Continuous"): {"max_dd": -5000, "max_day_loss": -2000},
    ("brtdub1", "ACF MA"):       {"max_dd": -5000, "max_day_loss": -2000},
    ("35brgcrk1", "ACF MA"):     {"max_dd": -5000, "max_day_loss": -2000},
    ("c3lst1", "DC Normal"):     {"max_dd": -5000, "max_day_loss": -2000},
    ("dubspr1", "DC Trailing"):  {"max_dd": -5000, "max_day_loss": -2000},
    ("dubspr1", "DC Normal"):    {"max_dd": -5000, "max_day_loss": -2000},
    ("ebobcrk1", "DC Trailing"): {"max_dd": -5000, "max_day_loss": -2000},
    ("sg380crk1", "DC Continuous"): {"max_dd": -5000, "max_day_loss": -2000},
    ("sg05crk1", "DC Normal"):   {"max_dd": -5000, "max_day_loss": -2000},
}
DEFAULT_BT_LIMITS = {"max_dd": -5000, "max_day_loss": -2000}


def _get_bt_limits(product: str, strategy: str) -> dict:
    return BACKTEST_LIMITS.get((product, strategy), DEFAULT_BT_LIMITS)


# ---------------------------------------------------------------------------
# Flux API -- daily close fetcher (uses AUTHORIZATION_RISK)
# ---------------------------------------------------------------------------

def _paginated_get(url: str, headers: dict, params: dict) -> list[dict]:
    """Paginated GET with rate-limit retry (same pattern as sys_utils.get_data)."""
    all_data: list[dict] = []
    while True:
        resp = requests.get(url, headers=headers, params=params)
        if resp.status_code == 429:
            time.sleep(60)
            continue
        if resp.status_code != 200:
            break
        all_data.extend(resp.json())
        cursor = resp.headers.get("x-cursor")
        if not cursor:
            break
        params["cursor"] = cursor
        time.sleep(3)
    return all_data


def fetch_daily_closes(
    symbols: set[str],
    start_date: str,
    end_date: str,
    resolution: str = "1h",
) -> dict[str, pd.Series]:
    """
    Fetch daily close prices from Flux API, keyed by actual contract symbol.

    resolution='1h' (default): fetches hourly bars, takes last close per day.
    resolution='1d': fetches daily bars directly (used for live MTM).

    Returns {contract_symbol: pd.Series(index=date, values=close)}
    """
    headers = {"Authorization": f"Bearer {FLUX_AUTH_RISK}"}
    result: dict[str, pd.Series] = {}

    for symbol in symbols:
        url = f"{FLUX_URL}{symbol}/{resolution}"
        data = _paginated_get(url, headers, {"start": start_date, "end": end_date})
        if not data:
            continue
        df = pd.DataFrame(data)
        if "timestamp" not in df.columns or "close" not in df.columns:
            continue
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["date"] = df["timestamp"].dt.date
        df = df.sort_values("timestamp")

        # Drop weekend rows (Sat=5, Sun=6)
        df = df[df["timestamp"].dt.dayofweek < 5]

        # Split by actual contract symbol and take last close per day
        for contract_sym, group_df in df.groupby("symbol"):
            daily = group_df.groupby("date")["close"].last()
            # Merge with existing data for this contract (in case another
            # generic symbol also returned data for the same contract)
            if contract_sym in result:
                combined = pd.concat([result[contract_sym], daily])
                combined = combined[~combined.index.duplicated(keep="last")]
                result[contract_sym] = combined.sort_index()
            else:
                result[contract_sym] = daily.sort_index()

    return result


# ---------------------------------------------------------------------------
# Live price cache (10-minute TTL)
# ---------------------------------------------------------------------------

_live_cache: dict = {"closes": {}, "fetched_at": 0.0, "symbols": frozenset()}
_CACHE_TTL = 600  # seconds


def _get_cached_closes(symbols: set[str]) -> dict[str, pd.Series]:
    """Fetch recent daily closes with in-memory caching."""
    now = time.time()
    if (
        now - _live_cache["fetched_at"] < _CACHE_TTL
        and symbols <= _live_cache["symbols"]
    ):
        return _live_cache["closes"]

    today = date.today()
    start = today - timedelta(days=5)
    end = today + timedelta(days=1)  # Flux end is exclusive
    closes = fetch_daily_closes(symbols, start.isoformat(), end.isoformat(), resolution="1h")

    _live_cache["closes"] = closes
    _live_cache["fetched_at"] = now
    _live_cache["symbols"] = frozenset(symbols)
    return closes


def _append_live_points(
    curves: dict[str, list[dict]],
    portfolio: list[dict],
) -> None:
    """Compute today's live MTM for open trades and append to curves + portfolio."""
    today = date.today()
    today_str = today.isoformat()

    # Also include trades closed today (batch hasn't stored their exit-day PnL)
    today_dt = datetime.combine(today, datetime.min.time())
    live_trades = list(collection_trades.find({
        "$or": [
            {"status": "open"},
            {"status": "closed", "exit_date": {"$gte": today_dt}},
        ]
    }))
    if not live_trades:
        print(f"[risk_engine] Live PnL: no open/today-closed trades found")
        return

    for t in live_trades:
        t["_id"] = str(t["_id"])

    symbols = collect_required_symbols(live_trades)
    print(f"[risk_engine] Live PnL: {len(live_trades)} trades, symbols={symbols}")
    daily_closes = _get_cached_closes(symbols)
    if not daily_closes:
        print(f"[risk_engine] Live PnL: Flux returned no closes")
        return

    # Find today's and previous day's closes
    all_dates: set[date] = set()
    for series in daily_closes.values():
        all_dates.update(series.index)

    prev_dates = sorted(d for d in all_dates if d < today)
    prev_date = prev_dates[-1] if prev_dates else None

    close_today: dict[str, float] = {}
    close_yesterday: dict[str, float] = {}
    for ticker, series in daily_closes.items():
        if today in series.index:
            close_today[ticker] = float(series[today])
        if prev_date and prev_date in series.index:
            close_yesterday[ticker] = float(series[prev_date])

    print(f"[risk_engine] Live PnL: close_today keys={list(close_today.keys())}, close_yesterday keys={list(close_yesterday.keys())}")
    if not close_today:
        print(f"[risk_engine] Live PnL: no close prices for today ({today_str}), dates in Flux={sorted(all_dates)}")
        return

    groups = _group_trades(live_trades)
    portfolio_live_pnl = 0.0

    for (product, strategy), group_trades in groups.items():
        daily_pnl, details = compute_daily_pnl(
            group_trades, today, close_today, close_yesterday, product,
        )
        if not details:
            continue

        label = f"{product} / {strategy}"
        last_cum = curves[label][-1]["cumulative_pnl"] if label in curves and curves[label] else 0.0

        curves.setdefault(label, []).append({
            "date": today_str,
            "daily_pnl": round(daily_pnl, 2),
            "cumulative_pnl": round(last_cum + daily_pnl, 2),
            "is_live": True,
        })
        portfolio_live_pnl += daily_pnl

    if portfolio_live_pnl != 0.0:
        last_portfolio_cum = portfolio[-1]["cumulative_pnl"] if portfolio else 0.0
        portfolio.append({
            "date": today_str,
            "daily_pnl": round(portfolio_live_pnl, 2),
            "cumulative_pnl": round(last_portfolio_cum + portfolio_live_pnl, 2),
            "is_live": True,
        })


# ---------------------------------------------------------------------------
# Metrics computation
# ---------------------------------------------------------------------------

def _compute_metrics(
    curve: list[dict],
    bt_limits: dict,
) -> dict:
    """Derive risk metrics from an equity curve."""
    if not curve:
        return {
            "total_pnl": 0.0,
            "live_daily_pnl": 0.0,
            "max_dd_backtest": bt_limits.get("max_dd", 0),
            "max_day_loss_backtest": bt_limits.get("max_day_loss", 0),
            "live_dd": 0.0,
            "live_max_day_loss": 0.0,
            "peak_equity": 0.0,
            "current_equity": 0.0,
        }

    equities = [r["cumulative_pnl"] for r in curve]
    daily_pnls = [r.get("daily_pnl", 0.0) for r in curve]

    current = equities[-1]
    peak = max(equities)

    return {
        "total_pnl": round(current, 2),
        "live_daily_pnl": round(daily_pnls[-1], 2) if daily_pnls else 0.0,
        "max_dd_backtest": bt_limits.get("max_dd", 0),
        "max_day_loss_backtest": bt_limits.get("max_day_loss", 0),
        "live_dd": round(current - peak, 2),
        "live_max_day_loss": round(min(daily_pnls), 2) if daily_pnls else 0.0,
        "peak_equity": round(peak, 2),
        "current_equity": round(current, 2),
    }


# ---------------------------------------------------------------------------
# Main entry point -- called by FastAPI
# ---------------------------------------------------------------------------

def get_risk_data(
    product: Optional[str] = None,
    strategy: Optional[str] = None,
) -> dict:
    """
    Build the full risk response:
      1. Available combos from MongoDB
      2. Historical equity curve
      3. Today's live MTM point
      4. Metrics
    """
    # -- 1. Available combos ------------------------------------------------
    pipeline = [
        {"$match": {"product": {"$ne": "Portfolio"}}},
        {"$group": {"_id": {"product": "$product", "strategy": "$strategy"}}},
        {"$sort": {"_id.product": 1, "_id.strategy": 1}},
    ]
    raw_combos = list(collection_risk.aggregate(pipeline))
    combo_pairs = [(r["_id"]["product"], r["_id"]["strategy"]) for r in raw_combos]
    available = ["Portfolio"] + [f"{p} / {s}" for p, s in combo_pairs]

    # -- 2. Historical curve from MongoDB -----------------------------------
    is_portfolio = product is None and strategy is None

    if is_portfolio:
        selection = "Portfolio"
        query = {"product": "Portfolio", "strategy": "All"}
    else:
        selection = f"{product} / {strategy}"
        query = {"product": product, "strategy": strategy}

    history_docs = list(collection_risk.find(query, {"_id": 0}).sort("date", 1))

    curve = []
    for doc in history_docs:
        d = doc["date"].date() if isinstance(doc["date"], datetime) else doc["date"]
        curve.append({
            "date": d,
            "cumulative_pnl": doc.get("cumulative_pnl", 0.0),
            "daily_pnl": doc.get("daily_pnl", 0.0),
        })

    # -- 3. Today's live MTM (placeholder — will be reworked later) --------

    # -- 4. Metrics ---------------------------------------------------------
    if is_portfolio:
        bt = DEFAULT_BT_LIMITS
    else:
        bt = _get_bt_limits(product or "", strategy or "")

    metrics = _compute_metrics(curve, bt)

    # -- 5. Serialize dates for JSON ----------------------------------------
    equity_curve_json = []
    for r in curve:
        d = r["date"]
        equity_curve_json.append({
            "date": d.isoformat() if isinstance(d, date) else str(d),
            "cumulative_pnl": round(r["cumulative_pnl"], 2),
            "daily_pnl": round(r["daily_pnl"], 2),
        })

    return {
        "selection": selection,
        "equity_curve": equity_curve_json,
        "metrics": metrics,
        "available_combos": available,
    }


def get_risk_all_curves() -> dict:
    """
    Return all per-(product, strategy) curves + portfolio in one call.
    Frontend uses this for multi-select client-side aggregation.
    """
    # Available combos
    pipeline = [
        {"$match": {"product": {"$ne": "Portfolio"}}},
        {"$group": {"_id": {"product": "$product", "strategy": "$strategy"}}},
        {"$sort": {"_id.product": 1, "_id.strategy": 1}},
    ]
    raw_combos = list(collection_risk.aggregate(pipeline))
    combo_labels = [f"{r['_id']['product']} / {r['_id']['strategy']}" for r in raw_combos]

    # Fetch all non-portfolio docs in one query
    all_docs = list(
        collection_risk.find({"product": {"$ne": "Portfolio"}}, {"_id": 0})
        .sort("date", 1)
    )

    # Group by "product / strategy"
    curves: dict[str, list[dict]] = {}
    for doc in all_docs:
        label = f"{doc['product']} / {doc['strategy']}"
        d = doc["date"].date() if isinstance(doc["date"], datetime) else doc["date"]
        curves.setdefault(label, []).append({
            "date": d.isoformat() if isinstance(d, date) else str(d),
            "daily_pnl": round(doc.get("daily_pnl", 0.0), 2),
            "cumulative_pnl": round(doc.get("cumulative_pnl", 0.0), 2),
        })

    # Portfolio curve (pre-stored)
    portfolio_docs = list(
        collection_risk.find(
            {"product": "Portfolio", "strategy": "All"}, {"_id": 0}
        ).sort("date", 1)
    )
    portfolio = []
    for doc in portfolio_docs:
        d = doc["date"].date() if isinstance(doc["date"], datetime) else doc["date"]
        portfolio.append({
            "date": d.isoformat() if isinstance(d, date) else str(d),
            "daily_pnl": round(doc.get("daily_pnl", 0.0), 2),
            "cumulative_pnl": round(doc.get("cumulative_pnl", 0.0), 2),
        })

    # Append today's live MTM points
    try:
        _append_live_points(curves, portfolio)
    except Exception as e:
        print(f"[risk_engine] Live PnL failed (non-fatal): {e}")

    # Trade-level aggregations: fees, realized PnL, unrealized PnL, win rate
    all_trades = list(collection_trades.find())
    fees: dict[str, float] = {}
    realized: dict[str, float] = {}
    unrealized: dict[str, float] = {}
    portfolio_fees = 0.0
    portfolio_realized = 0.0

    # Win-rate counters per label
    wins: dict[str, int] = {}
    losses: dict[str, int] = {}
    portfolio_wins = 0
    portfolio_losses = 0
    open_trades: list[dict] = []

    for t in all_trades:
        label = f"{t.get('product', '')} / {t.get('strategy', '')}"

        # Fees
        trade_fees = (t.get("entry_fees") or 0) + (t.get("exit_fees") or 0)
        fees[label] = fees.get(label, 0.0) + trade_fees
        portfolio_fees += trade_fees

        # Realized PnL (closed trades with stored pnl)
        if t.get("status") == "closed" and t.get("pnl") is not None:
            realized[label] = realized.get(label, 0.0) + t["pnl"]
            portfolio_realized += t["pnl"]
            # Win/loss counting (breakeven excluded)
            if t["pnl"] > 0:
                wins[label] = wins.get(label, 0) + 1
                portfolio_wins += 1
            elif t["pnl"] < 0:
                losses[label] = losses.get(label, 0) + 1
                portfolio_losses += 1
        # Collect open trades for unrealized calc
        if t.get("status") == "open":
            t["_id"] = str(t["_id"])
            open_trades.append(t)

    fees = {k: round(v, 2) for k, v in fees.items()}
    fees["Portfolio"] = round(portfolio_fees, 2)
    realized = {k: round(v, 2) for k, v in realized.items()}
    realized["Portfolio"] = round(portfolio_realized, 2)

    # Unrealized PnL for open trades (using latest close prices)
    portfolio_unrealized = 0.0
    if open_trades:
        try:
            symbols = collect_required_symbols(open_trades)
            closes = _get_cached_closes(symbols)
            # Find latest close per ticker
            latest: dict[str, float] = {}
            for ticker, series in closes.items():
                if len(series) > 0:
                    latest[ticker] = float(series.iloc[-1])

            for t in open_trades:
                label = f"{t.get('product', '')} / {t.get('strategy', '')}"
                ticker = contract_to_ticker(t["product"], t.get("contract", ""))
                price = latest.get(ticker)
                if price is None:
                    continue
                direction = 1 if t["signal"] == "long" else -1
                scale = PNL_SCALE.get(t["product"], 1.0)
                gross = direction * (price - t["entry_price"]) * t["size"] * 1000 * scale
                net = gross - (t.get("entry_fees") or 0)
                unrealized[label] = unrealized.get(label, 0.0) + net
                portfolio_unrealized += net
        except Exception as e:
            print(f"[risk_engine] Unrealized PnL failed (non-fatal): {e}")

    unrealized = {k: round(v, 2) for k, v in unrealized.items()}
    unrealized["Portfolio"] = round(portfolio_unrealized, 2)

    # Win rate per label + Portfolio
    def _win_rate(w: int, l: int) -> float | None:
        total = w + l
        return round(w / total * 100, 1) if total > 0 else None

    win_rate: dict[str, float | None] = {}
    for label in set(list(wins.keys()) + list(losses.keys())):
        win_rate[label] = _win_rate(wins.get(label, 0), losses.get(label, 0))
    win_rate["Portfolio"] = _win_rate(portfolio_wins, portfolio_losses)

    return {
        "curves": curves,
        "portfolio": portfolio,
        "available_combos": combo_labels,
        "fees": fees,
        "realized": realized,
        "unrealized": unrealized,
        "win_rate": win_rate,
    }
