"""
risk_batch.py  --  Historical daily-strategy PnL builder.

Computes daily PnL for every (product, strategy) combo from trades + close
prices and persists to the systematic_risk_pnl MongoDB collection.

Usage:
    python -m Systematic.backend.risk_batch           # incremental
    python -m Systematic.backend.risk_batch --full     # full recompute
"""

from __future__ import annotations

import argparse
from datetime import date, datetime, timedelta

import pandas as pd
from pymongo import UpdateOne

from Helpers.risk_pnl import (
    _group_trades,
    _to_date,
    collect_required_symbols,
    compute_daily_pnl,
    contract_to_ticker,
)
from Systematic.backend.blotter_trade import collection_trades
from Systematic.backend.risk_engine import collection_risk, fetch_daily_closes


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_all_trades() -> list[dict]:
    """Read every trade from MongoDB."""
    trades = list(collection_trades.find())
    for t in trades:
        t["_id"] = str(t["_id"])
    return trades


def _build_close_maps(
    daily_close_map: dict[str, pd.Series],
    target_date: date,
    prev_date: date | None,
) -> tuple[dict[str, float], dict[str, float]]:
    """Extract {ticker: close} for target_date and prev_date from full series."""
    close_today: dict[str, float] = {}
    close_yesterday: dict[str, float] = {}

    for ticker, series in daily_close_map.items():
        if target_date in series.index:
            close_today[ticker] = float(series[target_date])
        if prev_date is not None and prev_date in series.index:
            close_yesterday[ticker] = float(series[prev_date])

    return close_today, close_yesterday


def _collect_dates(
    group_trades: list[dict],
    group_closes: dict[str, pd.Series],
    cutoff: date,
) -> list[date]:
    """Build sorted list of dates to iterate over for a (product, strategy).

    Uses price-data dates (business days) as the base calendar, then adds
    trade entry/exit dates only if they fall on a day with price data.
    This prevents weekend/holiday dates from poisoning the prev-date chain.
    """
    # Business days from price data — the authoritative calendar
    price_dates: set[date] = set()
    for series in group_closes.values():
        price_dates.update(series.index)

    # Start with all business days
    all_dates: set[date] = set(price_dates)

    # Add entry/exit dates only if price data exists for that day
    # (same-day entry+exit trades use entry/exit prices directly, so
    # they work even without a close — but only if the day is a real
    # trading day, not a weekend/holiday typo)
    for t in group_trades:
        d = _to_date(t.get("entry_date"))
        if d and d in price_dates:
            all_dates.add(d)
        d = _to_date(t.get("exit_date"))
        if d and d in price_dates:
            all_dates.add(d)

    earliest = min(_to_date(t["entry_date"]) for t in group_trades)
    return sorted(d for d in all_dates if earliest <= d <= cutoff)


# ---------------------------------------------------------------------------
# Full recompute
# ---------------------------------------------------------------------------

def run_full(trades: list[dict]) -> None:
    """Wipe systematic_risk_pnl and recompute from the first trade to yesterday."""
    if not trades:
        print("[risk_batch] No trades found.")
        return

    entry_dates = [_to_date(t["entry_date"]) for t in trades]
    earliest = min(d for d in entry_dates if d)
    yesterday = date.today() - timedelta(days=1)

    if earliest > yesterday:
        print(f"[risk_batch] Earliest trade ({earliest}) is after yesterday.")
        return

    # Fetch all prices at once
    symbols = collect_required_symbols(trades)
    print(f"[risk_batch] FULL mode: {earliest} -> {yesterday}")
    print(f"[risk_batch] Fetching prices for {len(symbols)} symbol(s): {sorted(symbols)}")

    daily_closes = fetch_daily_closes(symbols, earliest.isoformat(), yesterday.isoformat(), resolution="1d")
    if not daily_closes:
        print("[risk_batch] No price data from Flux — aborting.")
        return

    print(f"[risk_batch] Got {len(daily_closes)} contract ticker(s): {sorted(daily_closes.keys())}")

    # Wipe collection
    del_result = collection_risk.delete_many({})
    print(f"[risk_batch] Cleared {del_result.deleted_count} existing docs.")

    # Process each (product, strategy) group
    groups = _group_trades(trades)
    total_docs = 0

    for (product, strategy), group_trades in groups.items():
        n = _process_group(product, strategy, group_trades, daily_closes, yesterday, start_cumulative=0.0)
        total_docs += n

    # Portfolio aggregation
    total_docs += _store_portfolio()

    print(f"[risk_batch] FULL done — {total_docs} total docs written.")


# ---------------------------------------------------------------------------
# Incremental (from last stored date to yesterday)
# ---------------------------------------------------------------------------

def run_incremental(trades: list[dict]) -> None:
    """Compute from the last stored date to yesterday for each group."""
    if not trades:
        print("[risk_batch] No trades found.")
        return

    yesterday = date.today() - timedelta(days=1)

    # We need prices from the earliest gap to yesterday.
    # Find the global earliest date we might need.
    groups = _group_trades(trades)
    global_start = yesterday  # will be narrowed below

    group_info: dict[tuple[str, str], tuple[date, float]] = {}
    for (product, strategy), group_trades in groups.items():
        last_doc = collection_risk.find_one(
            {"product": product, "strategy": strategy},
            sort=[("date", -1)],
        )
        if last_doc:
            last_date = _to_date(last_doc["date"])
            start = last_date + timedelta(days=1)
            cumulative = last_doc.get("cumulative_pnl", 0.0)
        else:
            start = min(_to_date(t["entry_date"]) for t in group_trades)
            cumulative = 0.0

        if start > yesterday:
            continue  # already up to date

        group_info[(product, strategy)] = (start, cumulative)
        if start < global_start:
            global_start = start

    if not group_info:
        print("[risk_batch] All groups are up to date.")
        return

    # Fetch prices for the needed range (with a few extra days for prev_close)
    fetch_start = global_start - timedelta(days=5)
    symbols = collect_required_symbols(trades)
    print(f"[risk_batch] INCREMENTAL mode: {global_start} -> {yesterday}")
    print(f"[risk_batch] Fetching prices for {len(symbols)} symbol(s)")

    daily_closes = fetch_daily_closes(symbols, fetch_start.isoformat(), yesterday.isoformat(), resolution="1d")
    if not daily_closes:
        print("[risk_batch] No price data from Flux — aborting.")
        return

    total_docs = 0
    for (product, strategy), (start, cumulative) in group_info.items():
        n = _process_group(
            product, strategy, groups[(product, strategy)],
            daily_closes, yesterday,
            start_cumulative=cumulative, start_from=start,
        )
        total_docs += n

    # Portfolio aggregation
    total_docs += _store_portfolio(start_from=global_start)

    print(f"[risk_batch] INCREMENTAL done — {total_docs} total docs written.")


# ---------------------------------------------------------------------------
# Shared: process one (product, strategy) group
# ---------------------------------------------------------------------------

def _process_group(
    product: str,
    strategy: str,
    group_trades: list[dict],
    daily_closes: dict[str, pd.Series],
    cutoff: date,
    start_cumulative: float = 0.0,
    start_from: date | None = None,
) -> int:
    """Compute daily PnL day-by-day and upsert to MongoDB. Returns doc count."""
    # Filter price data to this group's contracts
    group_tickers: set[str] = set()
    for t in group_trades:
        if t.get("contract"):
            group_tickers.add(contract_to_ticker(t["product"], t["contract"]))

    group_closes = {k: v for k, v in daily_closes.items() if k in group_tickers}

    # Collect dates to iterate
    dates = _collect_dates(group_trades, group_closes, cutoff)
    if start_from:
        dates = [d for d in dates if d >= start_from]

    if not dates:
        return 0

    cumulative_pnl = start_cumulative
    ops: list[UpdateOne] = []

    for i, day in enumerate(dates):
        prev = dates[i - 1] if i > 0 else None
        close_today, close_yesterday = _build_close_maps(group_closes, day, prev)

        daily_pnl, details = compute_daily_pnl(
            group_trades, day, close_today, close_yesterday, product,
        )

        # Skip days with no active trades
        if not details:
            continue

        cumulative_pnl += daily_pnl

        doc = {
            "date": datetime.combine(day, datetime.min.time()),
            "product": product,
            "strategy": strategy,
            "daily_pnl": round(daily_pnl, 2),
            "cumulative_pnl": round(cumulative_pnl, 2),
            "trades": details,
        }

        ops.append(UpdateOne(
            {"product": product, "strategy": strategy, "date": doc["date"]},
            {"$set": doc},
            upsert=True,
        ))

    if not ops:
        return 0

    result = collection_risk.bulk_write(ops)
    n = result.upserted_count + result.modified_count
    print(f"  [{product} / {strategy}] {len(ops)} days, cumulative_pnl={cumulative_pnl:.2f}")
    return n


# ---------------------------------------------------------------------------
# Portfolio aggregation
# ---------------------------------------------------------------------------

def _store_portfolio(start_from: date | None = None) -> int:
    """Aggregate all (product, strategy) docs into Portfolio-level docs.

    Reads existing per-strategy docs, sums daily_pnl per date,
    computes cumulative_pnl, and upserts Portfolio docs.
    """
    query: dict = {"product": {"$ne": "Portfolio"}}
    if start_from:
        query["date"] = {"$gte": datetime.combine(start_from, datetime.min.time())}

    docs = list(collection_risk.find(query).sort("date", 1))
    if not docs:
        return 0

    # Sum daily_pnl per date
    by_date: dict[date, float] = {}
    for doc in docs:
        d = _to_date(doc["date"])
        by_date[d] = by_date.get(d, 0.0) + doc.get("daily_pnl", 0.0)

    dates = sorted(by_date.keys())

    # Get starting cumulative for incremental mode
    if start_from:
        prev_doc = collection_risk.find_one(
            {"product": "Portfolio", "strategy": "All", "date": {"$lt": datetime.combine(start_from, datetime.min.time())}},
            sort=[("date", -1)],
        )
        cumulative = prev_doc.get("cumulative_pnl", 0.0) if prev_doc else 0.0
    else:
        cumulative = 0.0

    ops: list[UpdateOne] = []
    for day in dates:
        daily = round(by_date[day], 2)
        cumulative += daily
        doc_date = datetime.combine(day, datetime.min.time())
        doc = {
            "date": doc_date,
            "product": "Portfolio",
            "strategy": "All",
            "daily_pnl": daily,
            "cumulative_pnl": round(cumulative, 2),
        }
        ops.append(UpdateOne(
            {"product": "Portfolio", "strategy": "All", "date": doc_date},
            {"$set": doc},
            upsert=True,
        ))

    if not ops:
        return 0

    result = collection_risk.bulk_write(ops)
    n = result.upserted_count + result.modified_count
    print(f"  [Portfolio / All] {len(ops)} days, cumulative_pnl={cumulative:.2f}")
    return n


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Risk batch: compute daily strategy PnL and persist to MongoDB.",
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Wipe and recompute full history (default: incremental)",
    )
    args = parser.parse_args()

    trades = _load_all_trades()
    print(f"[risk_batch] Loaded {len(trades)} trades from MongoDB.")

    if args.full:
        run_full(trades)
    else:
        run_incremental(trades)


if __name__ == "__main__":
    main()
