from __future__ import annotations
from functools import lru_cache
from typing import Optional
from pandas.tseries.offsets import MonthEnd
import pandas as pd
from datetime import datetime, timedelta, timezone
from Systematic.backend.sys_utils import get_data, keep_hour_open, add_rolling_mas, compute_delta, collection_systematic_signals
from Helpers.log_helper import Logger
from zoneinfo import ZoneInfo

log = Logger()

def _is_london_bst() -> bool:
    """True when London is observing BST (UTC+1), False for GMT (UTC+0)"""
    return datetime.now(ZoneInfo("Europe/London")).utcoffset().total_seconds() == 3600


@lru_cache(maxsize=64)
def _load_ohlc(product: str, start_str: str, end_str: str, tf: str = "1h") -> pd.DataFrame:
    # Cache data for so get_data is not called multiple times
    df = get_data([product], start_str, end_str, tf).set_index("timestamp")[["open", "close"]].sort_index()
    df.index = pd.to_datetime(df.index, utc=True)
    return df


def _month_overlay_mask(idx: pd.DatetimeIndex) -> pd.Series:
    # Data within 25th and last day of month
    month_end_day = (idx + MonthEnd(0)).day
    return (idx.day >= 25) & (idx.day <= month_end_day)


def build_effective_close(product1: str, start_str: str, end_str: str, product2: Optional[str] = None, *, c3_formula: bool = False) -> pd.Series:
    """
    Returns a 'close' series where:
      - default is product1 close
      - overlay product2 close (or c3 formula close) on 25th..month-end
    """
    p1 = _load_ohlc(product1, start_str, end_str)
    close = p1["close"].copy()
    mask = _month_overlay_mask(close.index)

    if not mask.any():
        return close

    if c3_formula:
        c3 = _load_ohlc("c3lst2", start_str, end_str)[["close"]].rename(columns={"close": "c3_close"})
        wti = _load_ohlc("wti2", start_str, end_str)[["close"]].rename(columns={"close": "wti_close"})

        tmp = close.to_frame("close").join(c3, how="left").join(wti, how="left")
        prem_close = (tmp["c3_close"]/100 - (tmp["wti_close"] / 42.0) * 0.37) * 100.0

        # overlay only where mask is True AND formula is available
        close.loc[mask] = prem_close.loc[mask].combine_first(close.loc[mask])
        return close

    if not product2:
        return close

    p2 = _load_ohlc(product2, start_str, end_str)[["close"]].rename(columns={"close": "close_p2"})
    tmp = close.to_frame("close").join(p2, how="left")

    # overlay product2 only during 25th..month-end
    close.loc[mask] = tmp.loc[mask, "close_p2"].combine_first(close.loc[mask])
    return close


def signal_close_asof(df_hour: pd.DataFrame, now_utc: datetime, signal_hour: int, close_col: str = "signal_close") -> Optional[float]:
    idx = df_hour.index
    if idx.empty:
        return None

    today_start = pd.Timestamp(now_utc).floor("D")  # UTC day start
    target_ts = today_start + pd.Timedelta(hours=signal_hour+1)

    s = df_hour[close_col].dropna()
    if s.empty:
        return None

    if now_utc < target_ts.to_pydatetime():
        # BEFORE today's signal time -> use last available close before today
        prior = s[s.index < today_start]
        if prior.empty:
            return None
        return float(prior.iloc[-1])

    # AT/AFTER today's signal time -> use close at (or just before) target time
    upto_target = s[s.index <= target_ts]
    if upto_target.empty:
        # if today has started but no data up to target yet, fall back to last close before today
        prior = s[s.index < today_start]
        if prior.empty:
            return None
        return float(prior.iloc[-1])

    return float(upto_target.iloc[-1])


def product_signals(product: str, hour: int | None = None):
    # Start and End Dates for Flux format
    end_date = datetime.now() + timedelta(days=1)
    start_date = end_date - timedelta(days=30)
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")

    # Numbers within the [] define the MAs combination used in strategy, while the hours [] identify which "hour-close" price we are looking at
    # example: brtdub hours=[9] : we look at 9am close -> 10am we trade it
    bst = _is_london_bst()
    bst_offset = 1 if bst else 0
    product_config = {
        "brtdub1": {
            "hours": [9],
            "windows_by_hour": {9: [5, 30]},
        },
        "35brgcrk1": {
            "hours": [15],
            "windows_by_hour": {15: [5, 8, 50]},
        },
    }


    if product not in product_config:
        log.error(f"Product not found: {product}")
        return []

    now_utc = datetime.now(timezone.utc)

    # --- load base data (THIS close is the real close and must drive cum_delta) ---
    p1 = _load_ohlc(product, start_str, end_str)

    signal_close = p1["close"]
    hours = product_config[product]["hours"]
    windows_by_hour = product_config[product]["windows_by_hour"]
    if hour is not None:
        hours = [hour]

    results = []

    for h in hours:
        windows = windows_by_hour.get(h)
        if not windows:
            log.error(f"No MA windows configured for product={product}, hour={h}")
            continue

        # --- IMPORTANT: compute cum_delta from REAL close (p1 close), not signal_close ---
        df = keep_hour_open(add_rolling_mas(compute_delta(p1), windows), h - bst_offset)

        # attach signal_close for printing / db output, aligned by timestamp
        df = df.join(signal_close.rename("signal_close"), how="left")

        if len(df) < 2:
            continue

        cd_today = df["cum_delta"].iloc[-1]
        cd_prev  = df["cum_delta"].iloc[-2]
        cum_delta_signal = 1 if cd_today > cd_prev else -1 if cd_today < cd_prev else 0

        latest = df.iloc[-1]
        ma_signals = {}
        for w in windows:
            ma_col = f"ma_{w}"
            if ma_col not in df.columns or pd.isna(latest[ma_col]):
                continue
            ma_signals[w] = 1 if cd_today > latest[ma_col] else -1 if cd_today < latest[ma_col] else 0

        # output should use signal_close (renamed), not real close
        signal_close_out = signal_close_asof(df, now_utc, signal_hour=h - bst_offset, close_col="signal_close")

        results.append({
            "product": product,
            "signal_hour": h + 1,
            "timestamp": df.index[-1] + pd.Timedelta(hours=1),
            "signal_close": signal_close_out,   # <-- renamed field
            "cum_delta_signal": int(cum_delta_signal),
            "ma_signals": ma_signals,
        })

    return results


def upsert_systematic_signal(product: str):

    signals = product_signals(product)
    if not signals:
        return None

    now = datetime.now(timezone.utc)
    day_dt = now.replace(hour=0, minute=0, second=0, microsecond=0)

    collection_systematic_signals.update_one(
        {"date": day_dt},
        {"$setOnInsert": {"date": day_dt, "products": []}},
        upsert=True,
    )

    for signal in signals:
        ts = signal["timestamp"]
        if isinstance(ts, pd.Timestamp):
            ts = ts.to_pydatetime()

        ma_signals_str_keys = {str(k): int(v) for k, v in (signal.get("ma_signals") or {}).items()}

        product_doc = {
            "product": signal["product"],
            "signal_hour": int(signal["signal_hour"]),
            "timestamp": ts,
            "signal_close": signal.get("signal_close", None),
            "cum_delta_signal": int(signal["cum_delta_signal"]),
            "ma_signals": ma_signals_str_keys,
        }

        if product == "brtdub1":
            product_doc["physical-brtdub_signal"] = ""

        updated = collection_systematic_signals.update_one(
            {
                "date": day_dt,
                "products": {"$elemMatch": {"product": product, "signal_hour": int(signal["signal_hour"])}},
            },
            {"$set": {"products.$": product_doc, "last_updated": now}},
        )

        if updated.matched_count == 0:
            collection_systematic_signals.update_one(
                {"date": day_dt},
                {"$push": {"products": product_doc}, "$set": {"last_updated": now}},
            )

    log.debug(f"[END] Refresh '{product}' ACF/MAs signal.")
    return collection_systematic_signals.find_one({"date": day_dt}, {"_id": 0})


def execute_signals():
    _load_ohlc.cache_clear()
    for product in ["brtdub1", "35brgcrk1"]:
        upsert_systematic_signal(product)

# execute_signals()

def derive_position(product_doc: dict) -> int:
    """
    Unanimity rule: cum_delta_signal + all ma_signals must agree.
    Returns 1 (LONG), -1 (SHORT), or 0 (FLAT).
    """
    vals = [product_doc.get("cum_delta_signal", 0)]
    vals.extend(product_doc.get("ma_signals", {}).values())
    if all(v == 1 for v in vals):
        return 1
    if all(v == -1 for v in vals):
        return -1
    return 0