import pandas as pd
from datetime import datetime, timedelta
from Systematic.backend.sys_utils import (collection_systematic_signals, get_data,
    compute_delta,)
from Systematic.backend.dc_signals import (compute_sig_for_product,
    directional_change_events, dc_signal_from_events, generate_exec_signal,)
from Systematic.backend.sys_signals import execute_signals, derive_position
from Systematic.backend.config import DC_CONFIGS, DC_CONFIGS_LIST, ACTIVE_SIGNALS
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],)

from Systematic.backend.blotter_trade import (collection_trades, TradeCreate, TradeUpdate,
    compute_pnl, compute_summary,)
from Systematic.backend.risk_engine import get_risk_data, get_risk_all_curves
from fastapi import BackgroundTasks
from bson import ObjectId


# ─── SIGNAL COMPUTATION HELPERS ─────────────────────────────

def _compute_latest() -> dict:
    """Compute the /latest payload (MA/Windows signals). Calls Flux via execute_signals()."""
    execute_signals()
    doc = collection_systematic_signals.find_one(
        {}, sort=[("date", -1)], projection={"_id": 0}
    )

    if doc is None:
        return {}

    doc["products"] = [
        p for p in doc.get("products", [])
        if (p.get("product"), p.get("signal_hour")) in ACTIVE_SIGNALS]

    prev_doc = collection_systematic_signals.find_one(
        {"date": {"$lt": doc["date"]}},
        sort=[("date", -1)],
        projection={"_id": 0},
    )
    prev_products = prev_doc.get("products", []) if prev_doc else []

    prev_lookup = {
        (p["product"], p["signal_hour"]): p for p in prev_products
    }

    for p in doc.get("products", []):
        p["position"] = derive_position(p)
        prev_match = prev_lookup.get((p["product"], p["signal_hour"]))
        p["prev_position"] = derive_position(prev_match) if prev_match else None

    return doc


def _row_to_payload(sig, row) -> dict:
    # This is for the get_sig_latest
    ts = row.name.isoformat() if hasattr(row, "name") else sig.index[-1].isoformat()
    return {
        "timestamp": ts,
        "open": float(row["open"]) if pd.notna(row.get("open")) else None,
        "close": float(row["close"]) if pd.notna(row.get("close")) else None,
        "cum_delta": float(row["cum_delta"]) if pd.notna(row.get("cum_delta")) else None,
        "event": int(row.get("event", 0)) if pd.notna(row.get("event")) else 0,
        "pos_raw": int(row.get("pos_raw", 0)) if pd.notna(row.get("pos_raw")) else 0,
        "pos_desired": int(row.get("pos_desired", 0)) if pd.notna(row.get("pos_desired")) else 0,
        "stop_triggered": bool(row.get("stop_triggered", False)),
        "extreme": float(row["extreme"]) if pd.notna(row.get("extreme")) else None,
        "price_extreme": float(row["price_extreme"]) if pd.notna(row.get("price_extreme")) else None,
        "stop_level": float(row["stop_level"]) if pd.notna(row.get("stop_level")) else None,
        "close_lookback": float(row["close_lookback"]) if pd.notna(row.get("close_lookback")) else None,
    }

def _last_row_where(sig, mask):
    df = sig.loc[mask]
    return df.iloc[-1] if not df.empty else None


def _signal_status(pos_desired, pos_raw, blocked, blocked_dir, is_in_hours, last_raw_event_dir, trade_hours):
    start_h = trade_hours[0]
    if pos_desired != 0:
        pos_label = "LONG" if pos_desired == 1 else "SHORT"
        opp_label = "SHORT" if pos_desired == 1 else "LONG"
        if not is_in_hours:
            # Stop fired off-hours: pos_desired still shows held (NaN-fill artefact) but blocked in same dir
            if blocked and blocked_dir == pos_desired:
                return ("B", f"⚠ {pos_label} → STOP off-hours — EXIT at {start_h:02d}:00 close")
            if pos_raw == -pos_desired:
                return ("E", f"⚠ {pos_label} → {opp_label} off-hours — FLIP at {start_h:02d}:00 close")
            if pos_raw == 0:
                return ("E", f"⚠ {pos_label} — signal flat off-hours, EXIT at {start_h:02d}:00 close")
            return ("A", f"○ {pos_label} held — off-hours, resumes at {start_h:02d}:00 close")
        return ("A", f"● {pos_label} signal active")
    # pos_desired == 0
    if blocked:
        bd_label = "LONG" if blocked_dir == 1 else "SHORT"
        opp_label = "SHORT" if blocked_dir == 1 else "LONG"
        if is_in_hours:
            if pos_raw == blocked_dir:
                return ("B", f"✗ {bd_label} STOPPED — waiting for {opp_label} signal to re-enter")
            return ("B", f"✗ {bd_label} STOPPED — waiting flat")
        if pos_raw != 0 and pos_raw == -blocked_dir:
            return ("B", f"✗ {bd_label} STOPPED — {opp_label} ready at {start_h:02d}:00 close")
        return ("B", f"✗ {bd_label} STOPPED — off-hours, waiting for {opp_label} signal")
    if not is_in_hours:
        if pos_raw == 1:
            return ("C", f"▷ FLAT → LONG — signal pending, ENTRY at {start_h:02d}:00 close")
        if pos_raw == -1:
            return ("C", f"▷ FLAT → SHORT — signal pending, ENTRY at {start_h:02d}:00 close")
        return ("C", "— FLAT off-hours")
    if last_raw_event_dir != 0 and pos_raw == 0:
        ev_label = "LONG" if last_raw_event_dir == 1 else "SHORT"
        return ("D", f"↑ DC {ev_label} event fired — lookback not yet satisfied")
    return ("C", "— FLAT")


def _compute_status_history(sig_full, n=3):
    """Last n significant state transitions (pos_desired change or stop trigger)."""
    pos_s = sig_full["pos_desired"].astype(int)
    change_mask = (pos_s != pos_s.shift(1)).fillna(False)
    change_mask.iloc[0] = False
    stop_mask = sig_full["stop_triggered"].astype(bool)
    combined = sig_full.loc[change_mask | stop_mask].sort_index().tail(n)
    history = []
    for ts, row in combined.iterrows():
        pos = int(row["pos_desired"])
        was_stop = bool(row.get("stop_triggered", False))
        if was_stop:
            prior = sig_full.loc[sig_full.index < ts, "pos_desired"]
            prev_pos = int(prior.iloc[-1]) if not prior.empty else 0
            prev_label = "LONG" if prev_pos == 1 else "SHORT" if prev_pos == -1 else "FLAT"
            label = f"✗ {prev_label} STOPPED"
        elif pos == 1:
            label = "● LONG signal activated"
        elif pos == -1:
            label = "● SHORT signal activated"
        else:
            label = "— went FLAT"
        history.append({"timestamp": ts.isoformat(), "label": label, "pos_desired": pos})
    return list(reversed(history))


def _compute_sig_latest() -> dict:
    """Compute the /sig-latest payload (DC signals). Calls Flux via compute_sig_for_product()."""
    out = {}

    for cfg in DC_CONFIGS_LIST:
        result = compute_sig_for_product(cfg)
        if result is None:
            continue
        sig, events_between, prev_pos, sig_history = result
        if sig is None or sig.empty:
            continue

        sig = sig.sort_index()

        latest = sig.iloc[-1]
        last_event = sig.iloc[0] if len(sig) > 1 else None
        last_stop  = _last_row_where(sig, sig["stop_triggered"] == True)

        payload = {
            "latest": _row_to_payload(sig, latest),
            "last_event": None if last_event is None else _row_to_payload(sig, last_event),
            "last_stop": None if last_stop is None else _row_to_payload(sig, last_stop),
        }

        # --- dedupe timestamps ---
        ts_latest = payload["latest"]["timestamp"]

        if payload["last_event"] and payload["last_event"]["timestamp"] == ts_latest:
            payload["last_event"] = None

        if payload["last_stop"] and payload["last_stop"]["timestamp"] == ts_latest:
            payload["last_stop"] = None

        if (
            payload["last_event"]
            and payload["last_stop"]
            and payload["last_event"]["timestamp"] == payload["last_stop"]["timestamp"]
        ):
            payload["last_stop"] = None

        payload["threshold"] = cfg.threshold
        payload["stop_loss"] = cfg.stop_loss
        payload["lookback"] = cfg.lookback
        payload["trade_hours"] = list(cfg.trade_hours)

        payload["stop_level"] = payload["latest"]["stop_level"] if payload["latest"] is not None else None

        dist_trigger = None
        if payload["latest"] is not None:
            pos_desired = payload["latest"]["pos_desired"]
            current_close = payload["latest"]["close"]
            extreme = payload["latest"]["extreme"]
            if current_close is not None and extreme is not None:
                if pos_desired == 1:
                    dist_trigger = current_close - (extreme - cfg.threshold)
                elif pos_desired == -1:
                    dist_trigger = (extreme + cfg.threshold) - current_close
        payload["dist_trigger"] = dist_trigger
        payload["prev_pos_desired"] = prev_pos

        # --- is_in_hours ---
        latest_ts = sig.index[-1]
        start_h_cfg, end_h_cfg = cfg.trade_hours
        is_in_hours = bool(start_h_cfg <= latest_ts.hour <= end_h_cfg)
        payload["is_in_hours"] = is_in_hours

        # --- blocked / blocked_dir (final state from simulation loop) ---
        _latest_row = sig.iloc[-1]
        latest_blocked = bool(_latest_row.get("blocked", False))
        latest_blocked_dir = int(_latest_row.get("blocked_dir", 0))
        payload["blocked"] = latest_blocked
        payload["blocked_dir"] = latest_blocked_dir

        # --- last_raw_event_dir ---
        # dc_ffill: event column is forward-filled, so iloc[-1] = current DC regime direction
        # dc_classic / dc_trailing: events are sparse, scan for last non-zero
        if cfg.strategy == "dc_ffill":
            last_raw_event_dir = int(_latest_row.get("event", 0))
        else:
            _ev = sig_history["event"]
            _nonzero = _ev[_ev != 0]
            last_raw_event_dir = int(_nonzero.iloc[-1]) if not _nonzero.empty else 0
        payload["last_raw_event_dir"] = last_raw_event_dir

        # --- signal_status ---
        _pd = payload["latest"]["pos_desired"] if payload["latest"] else 0
        _pr = payload["latest"]["pos_raw"] if payload["latest"] else 0
        _group, _label = _signal_status(
            pos_desired=_pd, pos_raw=_pr,
            blocked=latest_blocked, blocked_dir=latest_blocked_dir,
            is_in_hours=is_in_hours, last_raw_event_dir=last_raw_event_dir,
            trade_hours=cfg.trade_hours,
        )
        payload["signal_status"] = _label
        payload["signal_status_group"] = _group

        # --- status_history (last 3 significant transitions from full signal df) ---
        payload["status_history"] = _compute_status_history(sig_history, n=3)

        eb_list = []
        if not events_between.empty:
            for _, row in events_between.iterrows():
                eb_list.append(_row_to_payload(events_between, row))
        payload["events_between"] = eb_list

        out[cfg.key] = payload

    return out


# ─── SIGNAL ENDPOINTS ─────────────────────────────────────

@app.get("/api/systematic-signals/latest")
def get_latest_systematic_signals():
    return _compute_latest()

@app.get("/api/systematic-signals/sig-latest")
def get_sig_latest():
    return _compute_sig_latest()

# ---------- DEBUG endpoint ----------


@app.get("/api/systematic-signals/debug/{symbol}")

def debug_dc_signal_test1(symbol: str, rows: int = 72):
    """Return last N rows of the full DC signal DataFrame for inspection."""
    cfg = DC_CONFIGS.get(symbol)
    if cfg is None:
        return {"error": f"Unknown symbol: {symbol}", "valid": list(DC_CONFIGS.keys())}

    end_date = datetime.now() + timedelta(days=1)
    start_date = end_date - timedelta(days=40)
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")

    # from Systematic.backend.dc_signals import _load_ohlc
    from Systematic.backend.dc_signals import _load_ohlc, STRATEGY_REGISTRY
    ohlc = _load_ohlc(cfg.symbol, start_str, end_str)
    delta_df = compute_delta(ohlc)

    run = STRATEGY_REGISTRY[cfg.strategy]
    sig, _ = run(delta_df, cfg)

    tail = sig.tail(rows)

    records = []
    for ts, row in tail.iterrows():
        records.append({
            "timestamp": ts.isoformat(),
            "open": round(float(row["open"]), 4) if pd.notna(row.get("open")) else None,
            "close": round(float(row["close"]), 4) if pd.notna(row.get("close")) else None,
            "cum_delta": round(float(row["cum_delta"]), 4) if pd.notna(row.get("cum_delta")) else None,
            "event": int(row["event"]) if pd.notna(row.get("event")) else 0,
            "extreme": round(float(row["extreme"]), 4) if pd.notna(row.get("extreme")) else None,
            "pos_raw": int(row["pos_raw"]),
            "pos_desired": int(row["pos_desired"]),
            "stop_triggered": bool(row["stop_triggered"]),
        })

    # Summary: find last few events and stops
    events = sig.loc[sig["event"] != 0].tail(5)
    stops = sig.loc[sig["stop_triggered"]].tail(5)

    return {
        "symbol": symbol,
        "config": {"threshold": cfg.threshold, "lookback": cfg.lookback, "stop_loss": cfg.stop_loss, "trade_hours": list(cfg.trade_hours)},
        "total_rows": len(sig),
        "last_events": [
            {"timestamp": ts.isoformat(), "event": int(r["event"]), "cum_delta": round(float(r["cum_delta"]), 4), "pos_raw": int(r["pos_raw"]), "pos_desired": int(r["pos_desired"])}
            for ts, r in events.iterrows()
        ],
        "last_stops": [
            {"timestamp": ts.isoformat(), "cum_delta": round(float(r["cum_delta"]), 4), "pos_desired": int(r["pos_desired"])}
            for ts, r in stops.iterrows()
        ],
        "rows": records,
    }



# ─── SLIPPAGE ────────────────────────────────────────────────

from Systematic.backend.slippage import compute_slippage

@app.get("/api/slippage")
def get_slippage():
    return compute_slippage()


# ─── TRADE BLOTTER ───────────────────────────────────────────

@app.get("/api/trades")
def get_trades(status: str = None, product: str = None, skip: int = 0, limit: int = 0):
    query = {}
    if status:
        query["status"] = status
    if product:
        query["product"] = product

    # Pagination only applies when explicitly requested (limit > 0)
    use_pagination = limit > 0
    total = collection_trades.count_documents(query) if use_pagination else None

    cursor = collection_trades.find(query, sort=[("entry_date", -1)])
    if use_pagination:
        cursor = cursor.skip(skip).limit(limit)

    trades = list(cursor)
    for t in trades:
        t["_id"] = str(t["_id"])
        if t.get("status") == "closed" and t.get("pnl") is None:
            net, gross = compute_pnl(t)
            t["pnl"] = net
            t["gross_pnl"] = gross

    if use_pagination:
        return {"trades": trades, "total": total}
    return trades


@app.get("/api/trades/groups")
def get_trade_groups(status: str = None, product: str = None):
    """Return logical trades (one per group_id), aggregating split fills."""
    query = {}
    if status == "open":
        query["status"] = "open"
    elif status == "closed":
        query["status"] = "closed"
    if product:
        query["product"] = product

    # Fetch all matching fills; group in Python (simpler than MongoDB pipeline for this shape)
    fills = list(collection_trades.find(query, sort=[("entry_date", -1)]))
    groups = {}
    for f in fills:
        f["_id"] = str(f["_id"])
        gid = f.get("group_id") or f["_id"]
        groups.setdefault(gid, []).append(f)

    result = []
    for gid, group_fills in groups.items():
        # Status: "open" if any fill is open, else "closed"
        any_open = any(f.get("status") == "open" for f in group_fills)
        group_status = "open" if any_open else "closed"

        # Shared entry fields (same across fills by construction)
        first = group_fills[0]
        total_size = sum(f.get("size") or 0 for f in group_fills)

        # Size-weighted averages across closed fills only
        closed = [f for f in group_fills if f.get("status") == "closed"]
        closed_size = sum(f.get("size") or 0 for f in closed)

        def _weighted(field):
            if not closed or closed_size == 0:
                return None
            num = sum((f.get(field) or 0) * (f.get("size") or 0) for f in closed if f.get(field) is not None)
            denom = sum((f.get("size") or 0) for f in closed if f.get(field) is not None)
            return round(num / denom, 4) if denom > 0 else None

        avg_exit_price = _weighted("exit_price")
        avg_exit_spread = _weighted("exit_spread")
        avg_exit_fees = sum((f.get("exit_fees") or 0) for f in closed)

        total_entry_fees = sum((f.get("entry_fees") or 0) for f in group_fills)

        # Total PnL = sum across closed fills
        total_pnl = 0.0
        total_gross = 0.0
        for f in closed:
            if f.get("pnl") is None:
                net, gross = compute_pnl(f)
                f["pnl"] = net
                f["gross_pnl"] = gross
            total_pnl += (f.get("pnl") or 0)
            total_gross += (f.get("gross_pnl") or 0)

        result.append({
            "group_id": gid,
            "product": first.get("product"),
            "strategy": first.get("strategy"),
            "signal": first.get("signal"),
            "entry_type": first.get("entry_type"),
            "contract": first.get("contract"),
            "entry_date": first.get("entry_date"),
            "entry_price": first.get("entry_price"),
            "entry_spread": first.get("entry_spread"),
            "entry_fees_total": total_entry_fees,
            "total_size": total_size,
            "avg_exit_price": avg_exit_price,
            "avg_exit_spread": avg_exit_spread,
            "exit_fees_total": avg_exit_fees,
            "total_pnl": round(total_pnl, 2) if closed else None,
            "gross_pnl": round(total_gross, 2) if closed else None,
            "status": group_status,
            "n_fills": len(group_fills),
            "fills": group_fills,
        })

    result.sort(key=lambda g: g.get("entry_date") or "", reverse=True)
    return result


@app.post("/api/trades")
def create_trade(trade: TradeCreate):
    doc = trade.model_dump()
    doc["exit_date"] = None
    doc["exit_price"] = None
    doc["exit_type"] = None
    doc["exit_spread"] = None
    doc["exit_fees"] = None
    doc["total_spread"] = None
    doc["status"] = "open"
    doc["created_at"] = datetime.utcnow()
    doc["updated_at"] = datetime.utcnow()

    result = collection_trades.insert_one(doc)
    # If no group_id was supplied (new logical trade), set it to the trade's own _id
    if not doc.get("group_id"):
        collection_trades.update_one({"_id": result.inserted_id}, {"$set": {"group_id": str(result.inserted_id)}})
        doc["group_id"] = str(result.inserted_id)
    doc["_id"] = str(result.inserted_id)
    return doc


@app.put("/api/trades/{trade_id}")
def update_trade(trade_id: str, updates: TradeUpdate):
    fields = updates.model_dump(exclude_none=True)
    if not fields:
        return {"error": "No fields to update"}

    fields["updated_at"] = datetime.utcnow()

    # Auto-close: if both exit_price and exit_date are now set
    existing = collection_trades.find_one({"_id": ObjectId(trade_id)})
    if not existing:
        return {"error": "Trade not found"}

    merged = {**existing, **fields}
    if merged.get("exit_price") is not None and merged.get("exit_date") is not None:
        fields["status"] = "closed"
        entry_spread = merged.get("entry_spread") or 0
        exit_spread = merged.get("exit_spread") or 0
        fields["total_spread"] = entry_spread + exit_spread
        net, gross = compute_pnl(merged)
        fields["pnl"] = net
        fields["gross_pnl"] = gross

    collection_trades.update_one(
        {"_id": ObjectId(trade_id)},
        {"$set": fields},
    )

    updated = collection_trades.find_one({"_id": ObjectId(trade_id)})
    updated["_id"] = str(updated["_id"])
    return updated


@app.delete("/api/trades/{trade_id}")
def delete_trade(trade_id: str):
    result = collection_trades.delete_one({"_id": ObjectId(trade_id)})
    if result.deleted_count == 0:
        return {"error": "Trade not found"}
    return {"deleted": trade_id}


@app.get("/api/trades/analytics/summary")
def get_trades_summary():
    trades = list(collection_trades.find())
    return compute_summary(trades)


# ─── RISK ──────────────────────────────────────────────────

@app.get("/api/risk")
def get_risk(product: str = None, strategy: str = None):
    return get_risk_data(product, strategy)


@app.get("/api/risk/all")
def get_risk_all():
    return get_risk_all_curves()


def _run_risk_batch():
    """Run incremental risk batch in background."""
    from Systematic.backend.risk_batch import run_incremental, _load_all_trades
    trades = _load_all_trades()
    run_incremental(trades)


@app.post("/api/risk/refresh")
def refresh_risk(bg: BackgroundTasks):
    bg.add_task(_run_risk_batch)
    return {"status": "started", "message": "Incremental risk batch running in background"}