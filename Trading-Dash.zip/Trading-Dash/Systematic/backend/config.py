"""
config.py  --  Single source of truth for all backend configuration.
"""
from Systematic.backend.dc_signals import ProductSigConfig


# DC signal configs  (used by /sig-latest and /debug endpoints)
DC_CONFIGS: dict[str, ProductSigConfig] = {
    "brtdub1":   ProductSigConfig(symbol="brtdub1",   threshold=0.14, lookback=14, stop_loss=0.23, trade_hours=(7, 16), strategy="dc_classic"),
    "ebobcrk1":  ProductSigConfig(symbol="ebobcrk1",  threshold=0.7,  lookback=36, stop_loss=1.2,  trade_hours=(8, 16), strategy="dc_classic"),
    "dubspr1":   ProductSigConfig(symbol="dubspr1",   threshold=0.17, lookback=16, stop_loss=0.26, trade_hours=(8, 16), strategy="dc_ffill"),
    "dubspr1:dc_classic": ProductSigConfig(symbol="dubspr1", threshold=0.15, lookback=18, stop_loss=0.26, trade_hours=(8, 16), strategy="dc_classic", key="dubspr1:dc_classic"),
    "sg05crk1":  ProductSigConfig(symbol="sg05crk1",  threshold=0.9,  lookback=8,  stop_loss=0.9,  trade_hours=(7, 14), strategy="dc_classic"),
    "sg380crk1": ProductSigConfig(symbol="sg380crk1", threshold=0.5,  lookback=8,  stop_loss=0.8,  trade_hours=(7, 14), strategy="dc_classic"),
}

# Ordered list for /sig-latest iteration
DC_CONFIGS_LIST: list[ProductSigConfig] = list(DC_CONFIGS.values())


# MA / Windows signal filter  (used by /latest)
ACTIVE_SIGNALS: set[tuple[str, int]] = {
    ("brtdub1", 10),
    ("35brgcrk1", 16),
}

# PnL scaling factors  (used by blotter_trade.py and risk_engine.py)
PNL_SCALE: dict[str, float] = {
    "c3lst1": 0.42,
    # everything else defaults to 1.0
}
