"""
risk_pnl.py  --  Pure daily-strategy P&L computation.
Zero I/O: no database, no HTTP.  Receives trades + prices, returns results.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional


# ---------------------------------------------------------------------------
# Config  --  imported from single source of truth
# ---------------------------------------------------------------------------

from Systematic.backend.config import PNL_SCALE  # noqa: F401


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _to_date(dt) -> Optional[date]:
    """datetime / Timestamp / date / None -> date | None."""
    if dt is None:
        return None
    if isinstance(dt, datetime):
        return dt.date()
    if isinstance(dt, date):
        return dt
    import pandas as pd
    return pd.Timestamp(dt).date()


def contract_to_ticker(product: str, contract: str) -> str:
    """
    Build a Flux ticker from a product and stored contract code.

    Examples
    --------
    >>> contract_to_ticker("ebobcrk1", "H26")
    'ebobcrkh26'
    >>> contract_to_ticker("dubspr1", "H26J26")
    'dubsprh26j26'
    """
    base = product[:-1]  # ebobcrk1 -> ebobcrk
    return f"{base}{contract.lower()}"


def _group_trades(trades: list[dict]) -> dict[tuple[str, str], list[dict]]:
    """Group trade dicts into {(product, strategy): [trade, ...]} buckets."""
    groups: dict[tuple[str, str], list[dict]] = {}
    for t in trades:
        key = (t["product"], t["strategy"])
        groups.setdefault(key, []).append(t)
    return groups


def collect_required_symbols(trades: list[dict]) -> set[str]:
    """Return generic Flux symbols to fetch (both '1' and '2' variants)."""
    products: set[str] = set()
    for t in trades:
        products.add(t["product"])
    symbols: set[str] = set()
    for p in products:
        symbols.add(p)              # e.g. ebobcrk1
        symbols.add(p[:-1] + "2")   # e.g. ebobcrk2
    return symbols


# ---------------------------------------------------------------------------
# Core: per-trade daily PnL
# ---------------------------------------------------------------------------

def compute_trade_daily_pnl(
    trade: dict,
    target_date: date,
    close_map_today: dict[str, float],
    close_map_yesterday: dict[str, float],
    product: str,
) -> Optional[dict]:
    """
    Single trade's daily PnL contribution on target_date.

    Formulas:
      entry day   : (Close_t - Entry_Price) × Size × Dir × 1000 × Scale - entry_fees
      hold day    : (Close_t - Close_{t-1}) × Size × Dir × 1000 × Scale
      exit day    : (Exit_Price - Close_{t-1}) × Size × Dir × 1000 × Scale - exit_fees
      entry+exit  : (Exit_Price - Entry_Price) × Size × Dir × 1000 × Scale - entry_fees - exit_fees

    Returns None if trade is not active on this date or required prices are missing.
    """
    entry_dt = _to_date(trade["entry_date"])
    exit_dt = _to_date(trade.get("exit_date"))

    # Not yet started
    if entry_dt > target_date:
        return None
    # Already closed before today
    if exit_dt is not None and exit_dt < target_date:
        return None

    direction = 1 if trade["signal"] == "long" else -1
    scale = PNL_SCALE.get(product, 1.0)
    size = trade["size"]
    multiplier = size * 1000 * scale

    contract = trade.get("contract", "")
    ticker = contract_to_ticker(product, contract)

    opened_today = entry_dt == target_date
    closed_today = exit_dt is not None and exit_dt == target_date

    entry_fees = 0.0
    exit_fees = 0.0

    # --- Determine event, ref_price, close_price ---
    if opened_today and closed_today:
        event = "entry+exit"
        ref_price = trade["entry_price"]
        close_price = trade["exit_price"]
        entry_fees = trade.get("entry_fees") or 0.0
        exit_fees = trade.get("exit_fees") or 0.0

    elif opened_today:
        event = "entry"
        close_price = close_map_today.get(ticker)
        if close_price is None:
            return None
        ref_price = trade["entry_price"]
        entry_fees = trade.get("entry_fees") or 0.0

    elif closed_today:
        event = "exit"
        ref_price = close_map_yesterday.get(ticker)
        if ref_price is None:
            return None
        close_price = trade["exit_price"]
        exit_fees = trade.get("exit_fees") or 0.0

    else:
        event = "hold"
        ref_price = close_map_yesterday.get(ticker)
        close_price = close_map_today.get(ticker)
        if ref_price is None or close_price is None:
            return None

    trade_pnl = direction * (close_price - ref_price) * multiplier - entry_fees - exit_fees

    return {
        "trade_id": str(trade.get("_id", "")),
        "signal": trade["signal"],
        "size": size,
        "contract": contract,
        "event": event,
        "ref_price": round(ref_price, 6),
        "close_price": round(close_price, 6),
        "entry_fees": entry_fees,
        "exit_fees": exit_fees,
        "trade_pnl": round(trade_pnl, 2),
    }


# ---------------------------------------------------------------------------
# Core: daily PnL for one (product, strategy)
# ---------------------------------------------------------------------------

def compute_daily_pnl(
    trades: list[dict],
    target_date: date,
    close_map_today: dict[str, float],
    close_map_yesterday: dict[str, float],
    product: str,
) -> tuple[float, list[dict]]:
    """
    Daily PnL on *target_date* for one (product, strategy).

    Iterates all trades, computes each active trade's contribution,
    sums them up.

    Parameters
    ----------
    trades              : dicts for ONE (product, strategy).
    target_date         : the business day to evaluate.
    close_map_today     : {contract_ticker: close} for target_date.
    close_map_yesterday : {contract_ticker: close} for the prior business day.
    product             : look-up key for PNL_SCALE.

    Returns
    -------
    (daily_pnl, trade_details)
    """
    details: list[dict] = []
    for t in trades:
        result = compute_trade_daily_pnl(
            t, target_date, close_map_today, close_map_yesterday, product,
        )
        if result is not None:
            details.append(result)

    daily_pnl = sum(d["trade_pnl"] for d in details) if details else 0.0
    return round(daily_pnl, 2), details
