import sys, datetime

class Logger:
    def _timestamp(self):
        return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def debug(self, message):
        print("[DEBUG] - " + str(self._timestamp()) + " :::  " + str(message))

    def error(self, message):
        print("[ERROR] - " + str(self._timestamp()) + " :::  " + str(message), file=sys.stderr)