import os
from pymongo import MongoClient
from dotenv import load_dotenv
from pathlib import Path

dotenv_path = Path(__file__).resolve().parent.parent / "Helpers" / "db.env"
load_dotenv(dotenv_path)

# Connect to MongoDB
client = MongoClient(os.getenv("CLIENT"))
db_streamlit = client[os.getenv("DB_RISK")]

collection_users = db_streamlit[os.getenv("COLLECTION_USERS")]
collection_daily_risk = db_streamlit[os.getenv("COLLECTION_DAILY_RISK")]
collection_personal_summaries = db_streamlit[os.getenv("COLLECTION_PERSONAL_SUMMARIES")]